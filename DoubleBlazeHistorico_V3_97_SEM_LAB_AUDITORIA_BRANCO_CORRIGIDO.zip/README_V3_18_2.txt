V3.18.2 — BANCA CORRETA POR OPERAÇÃO

Correção:
O backend salva a banca de cada operação no campo JSON "banca".
A V3.18.1 lia somente "bank", então usava a banca atual como fallback
e exibia o mesmo saldo em todas as operações.

Agora o app lê:
bank -> banca -> banca atual (fallback)

Assim cada WIN / LOSS_TENTATIVA / STOP mostra o snapshot da banca
registrado pelo servidor naquele exato momento.
Também aceita "motivo" do backend para mensagens de STOP.
