V3.10
GERADOR AUTOMÁTICO:
- Gale selecionável G0-G11.
- Modo Gale Tradicional.
- Modo Gale no Próximo Sinal.
- Quantidade de estratégias combinadas 1-30.
- O modo escolhido participa da simulação e da classificação das estratégias geradas.
- Estratégia gerada salva preserva o modo de Gale.
