V3.22 - HEARTBEAT DEMO 24H

Servidor atualizado para V54.2.
- endpoint publico GET /heartbeat
- heartbeat automatico a cada 300 segundos (5 min)
- usa HEARTBEAT_URL; se ausente, tenta RENDER_EXTERNAL_URL
- HEARTBEAT_ATIVO=0 desativa
- HEARTBEAT_INTERVALO_SEGUNDOS altera intervalo (minimo 60s)
- diagnostico do ultimo heartbeat no proprio /heartbeat

No Render, se RENDER_EXTERNAL_URL nao estiver disponivel automaticamente,
configure HEARTBEAT_URL com a URL publica do seu servico, sem / no final.
Exemplo: https://SEU-SERVICO.onrender.com
