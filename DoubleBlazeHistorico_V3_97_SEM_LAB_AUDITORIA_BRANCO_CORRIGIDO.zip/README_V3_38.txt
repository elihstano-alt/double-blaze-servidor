V3.38 — CONSENSO CONFIGURÁVEL NO OTIMIZADOR

- Adiciona consenso automático ou fixo: maioria simples, 60%, 70%, 80%, 90% e 100%.
- Só contam estratégias que geraram sinal naquela rodada.
- Empate entre vermelho e preto = sem entrada.
- Uma combinação continua gerando UMA única aposta por rodada.
- O consenso salvo passa a fazer parte da estratégia e é respeitado no simulador e na Demo local.
- Otimizador pode buscar o consenso mais lucrativo dentro dos demais filtros.
