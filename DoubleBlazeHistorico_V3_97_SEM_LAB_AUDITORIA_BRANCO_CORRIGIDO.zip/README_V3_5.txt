V3.5 — CORREÇÃO DEFINITIVA DE ROLAGEM MOBILE

- ScrollContainer separado para HISTÓRICO, SIMULADOR e SALVAS.
- Captura global de InputEventScreenDrag.
- O arraste funciona mesmo quando começa sobre botão, campo, seletor ou card.
- Sensibilidade de arraste 1.25x.
- Roda do mouse preservada para testes no PC/editor.
- Até 30 estratégias e G0-G11 preservados.
