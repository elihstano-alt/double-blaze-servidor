V3.89 + V58.20 — PRÓXIMA MELHOR NÃO SALVA

Regra:
1. Otimizador encontra a melhor configuração.
2. Se ela já existe em SALVAS, o servidor pula.
3. Procura a segunda melhor.
4. Se também está salva, pula para a terceira, quarta, quinta... até achar
   a melhor configuração ainda não salva.
5. Ao EXCLUIR uma estratégia de SALVAS, ela automaticamente volta a ser elegível.

Importante:
- A lista SALVAS é enviada como exclusão para o servidor em cada busca.
- O histórico/PostgreSQL/Demo não são apagados nem reconstruídos por esta alteração.
