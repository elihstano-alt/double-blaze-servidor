DOUBLE BLAZE V3.52 — OTIMIZADOR 120.000

Correção: o otimizador não troca mais automaticamente a opção “MELHOR QUANTIDADE AUTOMATICAMENTE” pela quantidade vencedora ao terminar.

Com Gale fixo + modo automático + consenso automático + quantidade automática, a busca exata volta a avaliar até 120.000 configurações (1.000 quantidades × 20 modos × 6 consensos).

Aposta contrária e demais funções da V3.51 foram preservadas. Nenhuma alteração no servidor/PY é necessária.
