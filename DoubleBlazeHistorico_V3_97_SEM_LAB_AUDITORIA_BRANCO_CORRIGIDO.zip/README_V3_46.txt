DOUBLE BLAZE HISTÓRICO V3.46 — LAYOUT RESPONSIVO MOBILE

Correções:
- Corrigido corte lateral da tela em celulares.
- OptionButtons longos não aumentam mais a largura da página.
- OTIMIZADOR e EQUILÍBRIO permanecem com scroll vertical touch.
- Campos de acerto/drawdown e pesos agora empilham verticalmente para caber em telas estreitas.
- Barra inferior usa layout com quebra automática de linha, sem sair da tela.
- Título superior também se adapta à largura.
- Mantidas todas as funções da V3.45.
- Servidor Python/Render NÃO alterado.
