V3.36 — OTIMIZADOR SEPARADO DO SIMULADOR

- Nova aba OTIMIZADOR separada da aba SIMULADOR.
- SIMULADOR ficou apenas para criar/testar/salvar uma estratégia manual.
- OTIMIZADOR agora aceita filtros claros:
  * Melhor geral ou melhor usando G0...G11 específico.
  * Melhor modo automático ou modo fixo (tradicional, próximo sinal, pular 1-9 rodadas, pular 1-9 sinais).
  * Melhor quantidade automática ou exatamente 1...30 estratégias combinadas.
  * Limite opcional de drawdown.
- O vencedor é sempre o maior lucro histórico dentro dos filtros escolhidos; empate usa menor drawdown.
- Stop Win permanece removido.
- Não exige alteração no servidor: esta mudança é de interface/otimização local; as estratégias salvas continuam compatíveis com o servidor 24h atual.
