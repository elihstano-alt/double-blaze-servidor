V3.12.1 — OTIMIZADOR RESPONSIVO

Correção do travamento durante OTIMIZAR TUDO AUTOMATICAMENTE.

Mudanças:
- processamento dividido em vários frames;
- interface continua recebendo toque e redesenhando;
- progresso aparece em tempo real;
- mostra Gale, modo, quantidade de estratégias e número de configurações testadas;
- botão fica bloqueado durante a execução para impedir otimizações duplicadas;
- biblioteca de candidatas também é processada em lotes;
- preserva busca G0-G11, Tradicional/Próximo Sinal e 1-30 estratégias;
- preserva banca, entrada e Gestão de Risco.

A busca continua completa dentro do espaço configurado, mas sem bloquear a interface por todo o cálculo.
