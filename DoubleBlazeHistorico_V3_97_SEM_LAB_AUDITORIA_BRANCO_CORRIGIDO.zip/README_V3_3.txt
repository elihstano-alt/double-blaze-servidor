V3.3 — GERADOR MULTI-ESTRATÉGIA

Na mesma janela do gerador automático:
- escolhe Gale: G0/sem Gale até G11
- escolhe quantas estratégias combinar: 1 até 11
- botão GERAR ESTRATÉGIA MAIS LUCRATIVA
- botão separado SALVAR ESTRATÉGIA GERADA

Quando usa 2 ou mais estratégias:
- o sistema seleciona candidatas pelo desempenho histórico
- em cada oportunidade, as estratégias compatíveis votam VERMELHO ou PRETO
- maioria define a entrada
- empate gera SEM ENTRADA
- o Gale escolhido é aplicado ao ciclo combinado

A estratégia combinada pode ser salva e simulada novamente com o histórico atualizado.

Observação: otimização no histórico pode sofrer overfitting e não garante desempenho futuro.
