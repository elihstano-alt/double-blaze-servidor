DOUBLE BLAZE HISTÓRICO V3.40 — DRAWDOWN + SCROLL TOUCH

Correções:
- SALVAS agora mostra Drawdown Máximo em R$ e %.
- Estratégias de branco também mostram Drawdown Máximo.
- Corrigido bug em que o OTIMIZADOR não estava incluído no roteador de rolagem touch.
- OTIMIZADOR agora usa mouse_filter PASS, follow_focus=false e scroll_deadzone.
- Processamento de input explicitamente ativado para reforçar scroll mobile.
- SIMULADOR mantém o ScrollContainer e usa o mesmo sistema global de drag.

Base: V3.39 Otimizador Ultra Exato.
Servidor/Render: nenhuma alteração necessária.
