DOUBLE BLAZE HISTÓRICO V3.39 — OTIMIZADOR ULTRA EXATO

- Baseada na V3.38.
- Mantém consenso configurável e busca completa.
- Pré-calcula os sinais de cada estratégia uma única vez por bloco.
- Combina votos por prefixo sem reexecutar todos os padrões a cada configuração.
- Reaproveita simulações quando consensos diferentes geram exatamente o mesmo vetor de sinais.
- Atualiza a interface a cada 500 testes em vez de 100 para reduzir custo visual.
- NÃO reduz o espaço de busca: as configurações selecionadas continuam sendo contabilizadas/testadas.
- Não altera servidor/Render.
