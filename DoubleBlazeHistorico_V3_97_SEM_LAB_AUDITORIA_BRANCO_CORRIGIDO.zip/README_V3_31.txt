V3.31 - SIMULADOR LIMPO + GALE COM ESPERA

- Interface do simulador simplificada nos textos principais.
- Novos modos de Gale:
  * Tradicional: Gale na rodada imediatamente seguinte.
  * Próximo sinal: Gale apenas no próximo sinal válido da estratégia.
  * Pular 1, 2, 3, 4, 5 ou 6 rodadas: após uma tentativa perdida, ignora a quantidade escolhida e só então executa o próximo Gale.
- A mesma regra é preservada ao salvar a estratégia e usar nas 7 contas DEMO 24h.
- Estratégias de branco mantêm sua lógica própria de tentativas fixas.
