DOUBLE BLAZE HISTÓRICO V3.48 — EXATO / RÁPIDO

Novo modo de processamento no OTIMIZADOR e EQUILÍBRIO:

EXATO (PADRÃO)
- Testa todas as quantidades permitidas.
- Não usa pré-filtro aproximado.
- Não corta possibilidades.
- Usa cache e reaproveitamento para evitar cálculos repetidos.
- Interface atualiza com menos frequência para ganhar velocidade.

RÁPIDO (OPCIONAL)
- Testa uma grade de quantidades representativas até 1000.
- Muito mais rápido.
- É aproximado e pode deixar passar uma boa configuração.

Servidor Python/Render NÃO alterado.
