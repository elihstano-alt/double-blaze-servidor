V3.12 — OTIMIZADOR TOTAL

Novo botão/opção:
OTIMIZAR TUDO AUTOMATICAMENTE

Quando ligado, o gerador escolhe sozinho:
- quantidade de estratégias: 1 a 30
- Gale: G0 a G11
- tipo de Gale: tradicional ou próximo sinal

Também respeita:
- valor da entrada
- banca configurada
- Trailing Stop se ativado
- Proteção de Capital se ativada
- Stop por Desempenho se ativado

Critério:
1. maior lucro simulado
2. em empate, menor drawdown

O resultado mostra a configuração vencedora e pode ser salvo normalmente.
Otimização retrospectiva não garante resultado futuro.
