V3.84 — CORREÇÃO DO DROPDOWN DA ESTRATÉGIA NA DEMO

Problema:
A aba Demo atualiza o status do servidor a cada 2 segundos. Cada atualização
recriava o OptionButton e selecionava novamente a estratégia atualmente
aplicada no servidor. Por isso, ao escolher outra estratégia no dropdown,
ela voltava sozinha para a primeira/atual antes de o usuário conseguir aplicar.

Correção:
- A escolha manual fica preservada durante o polling.
- O dropdown não volta sozinho para a estratégia antiga.
- Ao clicar APLICAR/TROCAR, a seleção fica travada até o servidor confirmar.
- Ao trocar de conta Demo, a seleção pendente é limpa.
- Não altera servidor, PostgreSQL, histórico, banca, WIN/LOSS ou lógica de sinais.
