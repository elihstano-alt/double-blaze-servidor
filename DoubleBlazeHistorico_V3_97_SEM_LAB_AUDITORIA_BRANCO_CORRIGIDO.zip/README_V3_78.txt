V3.78 — ACERTO MÍNIMO/MÁXIMO corrigido

Correção principal:
- Estratégias com ZERO entradas não podem mais ser escolhidas.
- No modo ACERTO MÁXIMO, estratégias reais negativas continuam concorrendo.
- Ex.: máximo 20% => somente estratégias com pelo menos 1 entrada e taxa <= 20%.
- Entre as válidas, vence a de maior lucro; empate = menor drawdown.
- O modo ACERTO MÍNIMO permanece igual.
- Demais configurações preservadas.

Backend correspondente: V58.2.
