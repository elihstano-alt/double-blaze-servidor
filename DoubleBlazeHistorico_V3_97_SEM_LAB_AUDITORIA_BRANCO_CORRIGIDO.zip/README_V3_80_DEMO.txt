V3.80 — DEMO 24H / SINAL CONTRÁRIO AUDITADO

Correções:
- Demo mostra última rodada processada e última rodada disponível no servidor.
- Mostra quantas rodadas estão pendentes e quando a sincronização está OK.
- Histórico de operações mostra:
  Sinal original -> sinal executado -> contrário SIM/NÃO.
- Botão Sinal Contrário aplica R<->P em TODA aposta enquanto estiver ligado,
  inclusive G0/G1/G2...
- Fallback local também respeita a inversão.

Backend correspondente: V58.4.
