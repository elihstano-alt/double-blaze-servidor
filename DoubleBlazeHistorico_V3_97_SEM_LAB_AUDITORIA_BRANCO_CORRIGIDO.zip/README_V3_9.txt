V3.9
- BANCA editável ao lado do valor de entrada.
- Gale Tradicional ou Gale no Próximo Sinal.
- Próximo Sinal: após uma perda, não aposta automaticamente na rodada seguinte; espera novo sinal válido e só então executa G1/G2/etc.
- Banca inicial passa a ser usada em lucro, drawdown, capacidade de Gale e quebra.
