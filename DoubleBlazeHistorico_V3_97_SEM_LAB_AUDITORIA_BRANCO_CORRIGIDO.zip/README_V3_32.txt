V3.32 — BRANCO COM TENTATIVAS CONFIGURÁVEIS NA DEMO

- Aposta do branco continua FIXA em todas as tentativas.
- Cada conta DEMO 1..7 tem controle próprio "TENTATIVAS DO BRANCO".
- Faixa configurável: 1 a 20 tentativas.
- O valor pode ser aplicado antes de iniciar ou alterado durante a Demo.
- Ao alterar durante um ciclo branco pendente, o ciclo atual é cancelado sem WIN/LOSS e o novo limite passa a valer na próxima entrada.
- Exemplo: R$10 e 8 tentativas => no máximo 8 apostas de R$10; se nenhuma acertar, 1 LOSS de R$80.
- As demais regras de Gale (tradicional, próximo sinal e pular 1..6) permanecem para estratégias normais.
