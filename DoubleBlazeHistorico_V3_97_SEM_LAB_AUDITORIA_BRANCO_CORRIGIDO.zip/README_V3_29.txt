V3.29 — SEQUÊNCIA REAL / ZERO PREENCHIMENTO

- Lacunas nunca são preenchidas automaticamente.
- Se houver uma quebra, o trecho anterior fica isolado.
- Backtests, Gerar Melhor e estratégias usam apenas o bloco contínuo real mais recente.
- O histórico bruto pode permanecer para auditoria, mas não é emendado ao bloco válido.
- Bootstrap inicial continua protegido pelo marcador persistente da V54.8.
- Janela máxima: 5000 rodadas.
