V3.16 — CONTINUIDADE DA CONTA DEMO

A sessão Demo salva a última rodada processada.
Quando o app é aberto novamente:
- baixa o histórico do servidor;
- localiza a última rodada processada;
- reproduz todas as rodadas que aconteceram enquanto o app estava fechado;
- atualiza banca, Gales, WIN/LOSS, Stop Win e gestão de risco;
- informa quantas rodadas pendentes foram sincronizadas.

IMPORTANTE:
Isso produz continuidade por sincronização ao reabrir.
O cálculo não está executando fisicamente dentro do Android enquanto ele está fechado.
Se a rodada-base sair da janela de histórico do servidor, o app informa LACUNA em vez de inventar resultados.

Para execução verdadeiramente residente 24h no servidor Render, o backend precisa receber
as rotas de sessão Demo e persistência no próprio servidor.
