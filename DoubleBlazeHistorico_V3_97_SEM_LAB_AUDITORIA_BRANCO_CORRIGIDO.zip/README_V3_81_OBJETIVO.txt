V3.81 — OBJETIVO LUCRO / PREJUÍZO

Novo campo no Otimizador:
- MAIOR LUCRO: comportamento tradicional.
- MAIOR PREJUÍZO: procura a configuração com o resultado financeiro mais negativo.

Os filtros de:
- acerto mínimo/máximo
- Gale
- modo do Gale
- quantidade de estratégias
- consenso
- drawdown
continuam sendo respeitados.

O resultado mostra WIN, LOSS, taxa de acerto e o prejuízo financeiro real.
Backend correspondente: V58.9.
