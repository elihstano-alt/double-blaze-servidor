V3.85 + V58.18 — MODO ESPELHO A/B
A = sinal original.
B = sinal contrário R<->P.
Os dois usam exatamente as mesmas rodadas e a mesma entrada em G0.
Branco faz os dois lados perderem simultaneamente.
O experimento não altera a banca principal da Demo.
Ao ligar, começa daquele momento e persiste no PostgreSQL junto com a Demo.
