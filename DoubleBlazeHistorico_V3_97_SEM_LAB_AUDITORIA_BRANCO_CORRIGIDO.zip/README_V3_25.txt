V3.25 — BASE INICIAL 1500 CONTÍNUA + JANELA DESLIZANTE 5000

- No deploy, o servidor tenta importar as 1500 rodadas públicas MAIS RECENTES.
- Consulta hoje e dias imediatamente anteriores para obter uma sequência que encaixe com o LIVE atual.
- NÃO substitui a base se detectar lacuna: exige segmento contínuo de pelo menos 1500 rodadas.
- Validação de bootstrap usa gap máximo de 45 segundos para detectar inclusive uma rodada faltante.
- Só depois de validar faz a troca atômica da base.
- A tela começa em 1500 / 5000 quando o bootstrap concluir.
- Cada nova rodada LIVE entra na sequência: 1501/5000, 1502/5000 ... até 5000/5000.
- Depois de 5000, a janela desliza: entra a mais nova e sai a mais antiga.
- As estratégias/backtests continuam usando apenas o histórico validado.
- Rota GET /bootstrap-1500-status mostra o estado da importação.
- Rota POST /bootstrap-1500 força uma nova tentativa manual.

IMPORTANTE:
O bootstrap só é aceito se a última rodada da sequência estiver próxima do LIVE (até 120 s), evitando emendar um histórico antigo nas novas rodadas.
