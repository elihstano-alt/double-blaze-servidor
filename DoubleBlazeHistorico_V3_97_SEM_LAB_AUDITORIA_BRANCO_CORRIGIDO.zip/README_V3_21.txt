DOUBLE BLAZE HISTÓRICO V3.21

- Adicionado botão SALVAR ESTRATÉGIA DE BRANCO na aba BRANCO.
- Estratégias de branco salvas aparecem em SALVAS e no seletor da DEMO com ícone ⚪.
- A DEMO identifica estratégia type=white.
- Branco usa tentativas consecutivas com valor FIXO por tentativa (sem dobrar Gale).
- WIN do branco usa o retorno salvo (padrão 14x).
- LOSS é registrada apenas após esgotar todas as tentativas.
- Ex.: 6 tentativas de R$10 sem branco = 1 LOSS de R$60.

ATENÇÃO: para a DEMO 24H no servidor executar essa lógica, publique também o servidor V54.1 BRANCO DEMO incluído separadamente.
