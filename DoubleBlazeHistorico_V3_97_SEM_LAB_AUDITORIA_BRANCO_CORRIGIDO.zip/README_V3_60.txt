DOUBLE BLAZE V3.60 — OTIMIZADOR NO PYTHON/RENDER

- O cálculo pesado do OTIMIZADOR foi movido para o servidor Python.
- Godot envia filtros e acompanha o progresso 1x por segundo.
- O celular não executa mais a varredura pesada quando usa o Otimizador.
- Servidor faz busca exata e mantém cache por histórico+filtros.
- Ao repetir os mesmos filtros no mesmo histórico, pode devolver o cache imediatamente.
- Mantidas as funções locais como fallback/referência.

IMPORTANTE: esta versão REQUER servidor V56.0.
