V3.19 — BUSCADOR DE BRANCO

Nova aba BRANCO:
- retorno padrão 14x, editável;
- banca e entrada configuráveis;
- leitura de todos os brancos do histórico;
- intervalo médio/mínimo/máximo entre brancos;
- taxa de equilíbrio teórica;
- 3 leituras automáticas de intervalo;
- GERAR MELHOR:
  testa intervalos desde o último branco e padrões R/B de 0 a 4 cores;
- backtest com entradas, WIN, LOSS, acerto, banca, lucro e drawdown;
- sinal atual: ENTRAR NO BRANCO ou AGUARDAR;
- usa o histórico já carregado do nosso servidor.

Observação:
A busca otimiza desempenho retrospectivo e não garante resultado futuro.
