V3.97 + V58.27 — APP LIMPO + PROTEÇÃO BRANCO CORRIGIDA

REMOVIDO:
- LAB
- AUDITORIA

MATEMÁTICA ÚNICA DA PROTEÇÃO:
Exemplo principal R$10 + proteção R$1:
- WIN normal: +R$9 líquido
- LOSS normal: -R$11 líquido
- BRANCO: -R$11 + R$14 de retorno total = +R$3 líquido

MODO ESPELHO:
- Cada lado possui sua própria banca e sua própria proteção.
- Se sair BRANCO com proteção ativa:
  A conta WIN na contagem W/L.
  B conta WIN na contagem W/L.
- O crédito do branco NÃO é duplicado dentro da mesma banca.
  Cada banca recebe somente o retorno correspondente à sua própria proteção.
- Operações do espelho expõem o líquido individual de A e B.

O servidor continua usando PostgreSQL/persistência existente.
Nenhuma rotina de reset ou reconstrução do histórico foi adicionada.
