DOUBLE BLAZE HISTÓRICO V3.47 — ATÉ 1000 ESTRATÉGIAS COMBINADAS

Alterações:
- OTIMIZADOR: quantidade combinada aumentada de 30 para até 1000 estratégias.
- EQUILÍBRIO: também passa a aceitar até 1000 estratégias combinadas.
- Opção automática pode testar de 1 até 1000, limitada pela quantidade real de candidatas disponíveis.
- Mantidas todas as funções da V3.46.
- Servidor Python/Render NÃO alterado.

ATENÇÃO:
Quanto maior a quantidade escolhida, maior o custo de processamento. O modo automático 1..1000 pode ficar muito pesado no celular.
