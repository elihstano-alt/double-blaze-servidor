DOUBLE BLAZE HISTÓRICO V3.58 — RESPONSIVIDADE ANDROID

Motivo:
Na V3.57 a busca exata podia ficar tempo demais na thread principal entre
atualizações. Pela captura, ela parou visualmente em 80/1000 e 474/120000.

Mudanças:
- yield da varredura de combinações: a cada 2 quantidades (antes 10);
- yield da preparação de cache: a cada 10 componentes (antes 50);
- yield durante configurações testadas: a cada 50 (antes 250);
- busca EXATA preservada;
- nenhuma configuração é descartada;
- total de 120.000 continua sendo percorrido;
- PY/Render não alterado.

Observação:
Mais yields podem acrescentar algum overhead, mas evitam que a interface
Android pareça congelada durante blocos grandes de cálculo.
