DOUBLE BLAZE HISTÓRICO V3.55 — BASE REAL EXPANDIDA + PROGRESSO

CORREÇÃO PRINCIPAL
- A biblioteca automática antes usava padrões V/P de tamanho 1 a 4:
  apenas 60 estratégias-base possíveis.
- Agora usa padrões V/P de tamanho 1 a 9:
  2044 estratégias-base possíveis antes dos filtros.
- Portanto o seletor de até 1000 estratégias agora pode trabalhar com uma
  biblioteca real grande o suficiente, em vez de pedir 1000 sobre uma base de 60.

INÍCIO DO PROCESSAMENTO
- A tela mostra imediatamente PREPARANDO ESTRATÉGIAS.
- Mostra progresso 0/2044 até 2044/2044 e quantas candidatas válidas existem.
- Depois inicia a varredura EXATA das configurações.
- Não usa amostragem no modo EXATO.

Mantidas as demais funções da V3.53.
Servidor Python/Render NÃO alterado.

Observação: expandir a base para 2044 estratégias aumenta muito o trabalho real.
A preparação agora é visível, mas ainda pode levar tempo porque cada candidata
é avaliada sobre o histórico antes da combinação.
