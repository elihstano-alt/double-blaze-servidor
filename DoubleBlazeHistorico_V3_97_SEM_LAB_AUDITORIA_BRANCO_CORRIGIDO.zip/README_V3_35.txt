V3.35 — GALE POR RODADAS OU POR SINAIS

- Gale tradicional: próxima rodada.
- Gale no próximo sinal: próximo sinal válido da estratégia.
- Pular 1 a 9 rodadas: ignora rodadas reais e faz o Gale depois.
- Pular 1 a 9 sinais: ignora sinais válidos da estratégia e faz o Gale no sinal seguinte.
- Stop Win removido da interface e da execução.
- Estratégias de branco continuam com aposta fixa e tentativas definidas na estratégia.
- Demo continua processada 24h no servidor.
