DOUBLE BLAZE HISTÓRICO V3.41 — ACERTO CONFIGURÁVEL

Novo no OTIMIZADOR:
- Opção EXIGIR PORCENTAGEM DE ACERTO.
- Campo ACERTO MÍNIMO % de 0 a 100, passo 0,5%.
- Exemplo: 80% significa que apenas configurações com taxa histórica >= 80% concorrem.
- Entre as configurações que passam no filtro, continua vencendo a de MAIOR LUCRO.
- Em empate de lucro, continua vencendo a de MENOR DRAWDOWN.
- O filtro escolhido fica registrado na estratégia gerada.
- Mantém V3.40: drawdown nas estratégias salvas + scroll touch corrigido.
- Mantém V3.39: Otimizador Ultra Exato e caches.
- Não requer alteração no servidor/Render.
