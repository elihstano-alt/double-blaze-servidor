DOUBLE BLAZE HISTÓRICO V3.57 — SEM TRAVAR / PROGRESSO CONTÍNUO

Correções:
- Corrigidos campos stake e initial_bank nas estratégias pré-geradas.
- Após 2044/2044 a tela não fica mais aparentemente congelada.
- Mostra PREPARANDO CACHE DE SINAIS 0..N.
- Durante a soma do histórico mostra VARREDURA EXATA EM ANDAMENTO.
- Atualiza o progresso a cada 10 quantidades e a cada 250 configurações.
- Continua avaliando todas as configurações do modo EXATO; não foi adicionada amostragem.
- As 2044 estratégias continuam pré-geradas no projeto.
- Servidor Python/Render NÃO alterado.
