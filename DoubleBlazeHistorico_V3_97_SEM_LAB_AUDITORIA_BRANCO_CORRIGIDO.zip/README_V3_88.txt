V3.88 — SEM ESTRATÉGIA INTELIGENTE + SEM CONFIGURAÇÃO DUPLICADA

- Removido o bloco Estratégia Inteligente / META da interface, voltando à base V3.85.
- Uma configuração que continua em SALVAS não pode ser gerada/salva novamente.
- A identidade considera a lógica: padrão/componentes, entrada, Gale, modo,
  consenso e inversão.
- Ao EXCLUIR a estratégia em SALVAS, ela automaticamente volta a ser elegível.
- Gerador local e Equilíbrio pulam configurações já salvas.
- Resultado remoto repetido é recusado e não cria nova cópia.
- Não altera histórico, PostgreSQL, Demo ou servidor.
