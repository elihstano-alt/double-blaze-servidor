DOUBLE BLAZE HISTÓRICO V3.53 — EXATO TOTAL

- OTIMIZADOR obrigatoriamente EXATO.
- Nenhuma quantidade válida é amostrada ou pulada.
- Se o espaço selecionado tiver 120.000, 1.000.000 ou mais configurações finitas,
  percorre todas as configurações válidas desse espaço.
- Durante o processamento mostra MELHOR ATÉ AGORA.
- Só após terminar mostra OTIMIZAÇÃO CONCLUÍDA.
- Cache reaproveita somente cálculos idênticos, sem retirar configurações da varredura.
- Menos atualizações visuais para melhorar velocidade no Android.
- EQUILÍBRIO também fica exato.
- Mantida APOSTA CONTRÁRIA e demais funções.
- Servidor Python/Render NÃO alterado.

Um conjunto literalmente infinito não pode ser concluído; o app percorre 100% do
conjunto finito definido pelas opções selecionadas.
