V3.91 + V58.22 — GERADOR COM PROTEÇÃO NO BRANCO

No OTIMIZADOR existe agora:
- USAR PROTEÇÃO NO BRANCO EM TODAS AS ENTRADAS
- VALOR NO BRANCO R$

A busca remota exata inclui no saldo:
- custo da proteção em TODA aposta R/P, inclusive Gales;
- retorno 14x quando sai branco;
- lucro/prejuízo líquido já depois da proteção;
- drawdown/banca considerando o dinheiro realmente colocado.

Exemplo:
principal R$10 + proteção R$1.
Acerto R/P = +R$9 líquido.
Branco = -10 -1 +14 = +R$3 líquido.

O resultado salvo leva white_protection_enabled/stake/payout junto da estratégia.
Histórico/PostgreSQL não são apagados nem reconstruídos.
