V3.90 + V58.21 — PROTEÇÃO NO BRANCO

Na Demo:
- opção PROTEGER BRANCO EM TODA ENTRADA;
- valor configurável, ex. R$1;
- proteção simultânea em cada aposta R/P, inclusive Gales;
- pagamento do branco considerado como 14x;
- estado persiste no PostgreSQL.

Exemplo: principal R$10 + branco R$1.
Acerto R/P: +R$10 - R$1 = +R$9 líquido.
Branco: -R$10 -R$1 +R$14 = +R$3 líquido.

Histórico não é apagado nem reconstruído por esta alteração.
