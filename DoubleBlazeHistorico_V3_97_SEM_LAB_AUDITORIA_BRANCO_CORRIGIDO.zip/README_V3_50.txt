DOUBLE BLAZE HISTÓRICO V3.50 — APOSTA CONTRÁRIA

- SIMULADOR: opção APOSTA CONTRÁRIA para inverter VERMELHO ↔ PRETO.
- Exemplo: V,V,V → PRETO passa a apostar VERMELHO.
- OTIMIZADOR: pode procurar resultados usando o sinal contrário.
- EQUILÍBRIO: também possui APOSTA CONTRÁRIA.
- BRANCO não é invertido.
- Estratégias salvas ficam marcadas como CONTRÁRIA.
- Estratégias combinadas têm os componentes invertidos, então a DEMO 24h entende a aposta sem mudança no backend.
- Cache de sinais também é invertido durante o backtest para o resultado exibido ser o resultado da aposta contrária.
- Servidor Python/Render NÃO alterado.
