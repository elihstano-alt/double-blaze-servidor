V3.8 — CONTEXTO COMPLETO DO DRAWDOWN

O simulador agora diferencia corretamente:
- banca inicial
- maior banca atingida
- menor banca
- pico imediatamente antes do maior drawdown
- banca no fundo do maior drawdown
- drawdown em R$
- drawdown em % daquele pico
- quebra/banca insuficiente

Exemplo:
Banca inicial R$1.000.
A estratégia cresce até R$8.000.
Depois cai para R$5.000.
Drawdown = R$3.000, embora seja maior que a banca inicial.
Isso NÃO significa quebra, pois ainda havia R$5.000.

A checagem de cada Gale continua usando a banca corrente naquele momento.
