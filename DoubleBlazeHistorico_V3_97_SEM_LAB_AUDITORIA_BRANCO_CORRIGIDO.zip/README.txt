DOUBLE BLAZE HISTÓRICO — V1

NOVO APP MINIMALISTA

Finalidade:
- Exibir somente o histórico vindo do nosso servidor.
- Sem sinais.
- Sem estratégias.
- Sem filtros.
- Sem conta Demo/Real.
- Sem painéis antigos.

Fonte:
https://double-blaze-servidor.onrender.com

Rotas usadas:
- /historico?limite=5000
- /status

Tela:
- Status do servidor/captura.
- Base estatística X / 5000.
- Última atualização.
- Lista vertical deslizante por toque.
- Mais recentes primeiro.
- Cores e números destacados.
- Carregamento inicial de 250 linhas.
- Botão CARREGAR MAIS adiciona 250 por vez.
- Atualização automática a cada 10 segundos.

Essa versão é uma nova base limpa para evoluirmos depois.
