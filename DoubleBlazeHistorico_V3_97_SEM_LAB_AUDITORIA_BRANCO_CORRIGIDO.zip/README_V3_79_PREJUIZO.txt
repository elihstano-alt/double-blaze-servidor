V3.79 — RESULTADO NEGATIVO COMPLETO

- Estratégias com prejuízo continuam válidas quando passam pelo filtro de acerto.
- Exibe sempre:
  ENTRADAS TOTAIS
  WIN
  LOSS
  WIN + LOSS
  ACERTO
  LUCRO ou PREJUÍZO
  RESULTADO FINANCEIRO LÍQUIDO
  BANCA FINAL
  DRAWDOWN
- Valores negativos são exibidos de verdade, sem virar zero.
- ACERTO MÁXIMO 20% continua significando taxa <= 20%.
- Zero entradas continua inválido.
- Demais configurações preservadas.
- Compatível com servidor V58.2 atual; não precisa trocar o Python para este ajuste visual.
