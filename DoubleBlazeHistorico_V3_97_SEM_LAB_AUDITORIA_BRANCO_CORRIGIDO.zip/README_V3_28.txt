V3.28 - Bootstrap unico persistente

- Adiciona marcador permanente no PostgreSQL (double_meta).
- Bootstrap de 1500 roda apenas uma vez por banco.
- Deploys/restarts futuros nao podem reduzir a base para 1500.
- Bases existentes com >=1500 rodadas sao migradas automaticamente e marcadas como inicializadas.
- A janela continua crescendo ate 5000 e depois desliza.
