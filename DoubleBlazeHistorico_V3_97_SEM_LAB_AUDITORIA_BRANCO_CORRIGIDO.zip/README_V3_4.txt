V3.4 — MULTI ESTRATÉGIAS ATÉ 30 + ROLAGEM

- Estratégias combináveis: 1 até 30.
- Gale: G0/sem Gale até G11.
- Aba SIMULADOR com rolagem vertical.
- Aba SALVAS com rolagem vertical.
- Melhor suporte a toque/arraste no celular.
- Barra de rolagem aparece automaticamente quando necessário.
- Combinação continua por votação; empate = sem entrada.
