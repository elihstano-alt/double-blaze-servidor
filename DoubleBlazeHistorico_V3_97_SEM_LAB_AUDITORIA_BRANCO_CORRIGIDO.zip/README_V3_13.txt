V3.13
- Na opção PROCURAR A MELHOR, pode escolher:
  * Automático: testar G0 até G11
  * Gale fixo: G0, G1, G2... G11
- Drawdown máximo configurável em R$ com ativar/desativar
- Configurações que ultrapassam o DD escolhido são descartadas
- Mantém 1-30 estratégias, dois tipos de Gale e otimização responsiva
