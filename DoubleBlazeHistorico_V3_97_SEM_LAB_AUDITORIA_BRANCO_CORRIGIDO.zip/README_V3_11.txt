V3.11 — GESTÃO DE RISCO
Cada proteção possui ATIVAR/DESATIVAR:
1. Trailing Stop: encerra novas entradas quando a queda desde o pico atinge a porcentagem escolhida.
2. Proteção de Capital: encerra quando a banca atinge o piso protegido.
3. Stop por Desempenho: analisa as últimas X entradas concluídas e encerra se a taxa de acerto ficar abaixo do mínimo escolhido.
O resultado informa se um stop foi acionado e o motivo.
