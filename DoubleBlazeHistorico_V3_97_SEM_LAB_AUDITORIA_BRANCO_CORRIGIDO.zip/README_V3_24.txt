DOUBLE BLAZE HISTÓRICO V3.24 — HISTÓRICO VALIDADO

- O app agora consome /historico-validado.
- Backtests, Gerar Melhor e análise do branco usam apenas o segmento contínuo mais recente.
- O servidor detecta lacunas maiores que 75 s (configurável por LIMITE_LACUNA_HISTORICO_SEGUNDOS).
- Trechos antigos com lacunas não são juntados como se fossem uma sequência contínua.
- O painel mostra quantidade VALIDADA, quantidade BRUTA e número de lacunas isoladas.
- Nova rota /continuidade-historico para diagnóstico.
- Ao subir, o servidor tenta uma recuperação pública automática se detectar lacunas.
- Nova rota POST /reparar-historico permite repetir a tentativa de recuperação.
- A base bruta não é apagada; continua disponível para auditoria.

IMPORTANTE: faça novo deploy do servidor V54.4 no Render antes de usar esta versão do app.
