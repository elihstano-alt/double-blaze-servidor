V3.18.1 — CORREÇÃO DO HISTÓRICO DA DEMO

Corrigido:
- placeholders literais %s, %d e %.2f no histórico;
- WIN/LOSS/STOP agora exibem os valores reais;
- entrada, Gale, stake, resultado e banca são formatados corretamente;
- rolagem da aba Demo permanece intacta.
