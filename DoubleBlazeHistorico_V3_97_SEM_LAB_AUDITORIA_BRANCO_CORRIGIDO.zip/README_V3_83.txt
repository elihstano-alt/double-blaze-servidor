V3.83 — PREJUÍZO COM MUITOS SINAIS

Novos filtros:
- MÍNIMO DE ENTRADAS
- FREQUÊNCIA MÍNIMA DE SINAIS %

Uso recomendado para procurar uma estratégia ruim mas ativa:
- Objetivo: MAIOR PREJUÍZO
- Gale: G0
- Mínimo de entradas: 300
- Frequência mínima: 20%
- Acerto máximo: 40%
- Contrária no otimizador: desligada

Persistência:
- V58.15 desativa bootstrap/reconstrução automática em deploy.
- Histórico e Demo só sobrevivem a deploy de forma real quando DATABASE_URL/PostgreSQL está configurado no Railway.
