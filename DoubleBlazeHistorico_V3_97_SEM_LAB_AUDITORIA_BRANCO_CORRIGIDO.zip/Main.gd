extends Control

const PREGENERATED_STRATEGIES_PATH := "res://data/strategies_base_16380.json"
var _pregenerated_base_strategies: Array = []


const SERVER_BASE := "https://web-production-25658.up.railway.app"
const HISTORY_URL := SERVER_BASE + "/historico?limite=30000"
const STATUS_URL := SERVER_BASE + "/status"
const STRATEGY_FILE := "user://estrategias_v2.json"
const DEMO_FILE := "user://conta_demo_v314.json"
const REFRESH_SECONDS := 10.0
const PAGE_SIZE := 250

var http_history: HTTPRequest
var http_status: HTTPRequest
var http_demo_status: HTTPRequest
var http_demo_command: HTTPRequest
var http_optimizer_start: HTTPRequest
var http_optimizer_status: HTTPRequest
var optimizer_poll_timer: Timer
var optimizer_remote_job_id: String = ""
var demo_command_busy: bool = false
var refresh_timer: Timer
var demo_refresh_timer: Timer

var pages: Dictionary = {}
var current_page := "history"

var status_label: Label
var count_label: Label
var updated_label: Label
var list_box: VBoxContainer
var history_scroll: ScrollContainer
var simulator_scroll: ScrollContainer
var optimizer_scroll: ScrollContainer
var balance_scroll: ScrollContainer
var saved_scroll: ScrollContainer
var touch_scrolling := false
var load_more_button: Button

var nav_history: Button
var nav_sim: Button
var nav_optimizer: Button
var nav_balance: Button
var nav_saved: Button
var nav_demo: Button
var nav_white: Button

var strategy_name: LineEdit
var strategy_pattern: LineEdit
var strategy_entry: OptionButton
var strategy_contrarian: CheckButton
var strategy_gale: OptionButton
var auto_gale: OptionButton
var auto_gale_mode: OptionButton
var auto_strategy_count: OptionButton
var auto_consensus: OptionButton
var auto_contrarian: CheckButton
var auto_optimize_all: CheckButton
var auto_search_gale: OptionButton
var auto_dd_limit_enabled: CheckButton
var auto_dd_limit: SpinBox
var auto_min_rate_enabled: CheckButton
var auto_rate_mode: OptionButton
var auto_objective_mode: OptionButton
var auto_min_entries_enabled: CheckButton
var auto_min_entries: SpinBox
var auto_min_signal_pct_enabled: CheckButton
var auto_min_signal_pct: SpinBox
var auto_white_protection_enabled: CheckButton
var auto_white_protection_stake: SpinBox
var auto_min_rate: SpinBox
var auto_generate_button: Button
var auto_speed_mode: OptionButton
var auto_optimizing: bool = false
var generated_strategy: Dictionary = {}
var strategy_stake: SpinBox
var strategy_white_protection_enabled: CheckButton
var strategy_white_protection_stake: SpinBox
var strategy_bank: SpinBox
var risk_trailing_enabled: CheckButton
var risk_trailing_pct: SpinBox
var risk_capital_enabled: CheckButton
var risk_capital_floor: SpinBox
var risk_performance_enabled: CheckButton
var risk_performance_window: SpinBox
var risk_performance_min_rate: SpinBox
var strategy_gale_mode: OptionButton
var sim_result: Label
var optimizer_result: Label

var balance_profit_weight: SpinBox
var balance_dd_weight: SpinBox
var balance_rate_weight: SpinBox
var balance_gale_select: OptionButton
var balance_gale_mode_select: OptionButton
var balance_contrarian: CheckButton
var balance_result: Label
var balance_generate_button: Button
var balance_speed_mode: OptionButton
var balance_generated_strategy: Dictionary = {}

var saved_list: VBoxContainer
var saved_summary: Label
var saved_show_blocked: bool = false
var saved_active_tab: Button
var saved_blocked_tab: Button

var demo_scroll: ScrollContainer
var demo_strategy_select: OptionButton
var demo_account_select: OptionButton
var demo_current_id: String = "demo1"
var demo_white_enabled_toggle: CheckButton
var demo_contrary_signal_toggle: CheckButton
var demo_mirror_toggle: CheckButton
var demo_mirror_label: Label
var demo_initial_bank_input: SpinBox
var demo_entry_input: SpinBox
var demo_white_protection_toggle: CheckButton
var demo_white_protection_stake: SpinBox
var demo_white_attempts_input: SpinBox
var demo_status_label: Label
var demo_signal_label: Label
var demo_stats_label: Label
var demo_history_label: Label
var demo_profit_label: Label
var demo_rounds_label: Label
var demo_current_operation_label: Label
var demo_audit_label: Label
var demo_server_info_label: Label
var demo_active: bool = false
var demo_strategy: Dictionary = {}
# V3.84: mantém a estratégia que o usuário acabou de selecionar no dropdown.
# O polling de 2s da Demo não pode forçar de volta a estratégia já aplicada.
var demo_pending_strategy_id: String = ""
var demo_bank: float = 1000.0
var demo_initial_bank: float = 1000.0
var demo_entry_value: float = 10.0
var demo_peak_bank: float = 1000.0
var demo_min_bank: float = 1000.0
var demo_max_dd: float = 0.0
var demo_wins: int = 0
var demo_losses: int = 0
var demo_gale_wins: Array = []
var demo_current_gale: int = 0
var demo_cycle_active: bool = false
var demo_cycle_target: String = ""
var demo_last_round_key: String = ""
var demo_operations: Array = []
var demo_recent_results: Array = []
var demo_stop_reason: String = ""
var demo_last_sync_count: int = 0
var demo_last_sync_text: String = "-"
var demo_started_at: String = ""
var demo_processed_rounds: int = 0
var demo_server_updated_at: String = "-"
var demo_server_last_round: String = "-"
var demo_server_last_round_time: String = "-"
var demo_server_latest_round_id: String = "-"
var demo_server_latest_round_time: String = "-"
var demo_pending_rounds: int = 0
var demo_server_synced: bool = false

var white_scroll: ScrollContainer
var white_stake_input: SpinBox
var white_bank_input: SpinBox
var white_payout_input: SpinBox
var white_attempts_input: SpinBox
var white_signal_label: Label
var white_strategy_label: Label
var white_stats_label: Label
var white_presets_label: Label
var white_best_strategy: Dictionary = {}

var history: Array = []
var history_raw_total: int = 0
var history_gap_count: int = 0
var continuity_label: Label
var history_validation_mode: String = ""
var visible_count := PAGE_SIZE
var history_busy := false
var status_busy := false
var strategies: Array = []

var bg := Color("#070B11")
var surface := Color("#0E1622")
var surface_2 := Color("#121D2B")
var border := Color("#24364F")
var text := Color("#F2F5FA")
var muted := Color("#95A2B5")
var green := Color("#57D6A0")
var red := Color("#FF6077")
var black_color := Color("#B4BFCE")
var white_color := Color("#F3F5F7")
var purple := Color("#B490FF")


func _ready() -> void:
	set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	set_process_input(true)
	_load_strategies()
	_load_demo_state()
	_build_ui()
	_build_network()
	_show_page("history")
	_request_all()


func _build_ui() -> void:
	var background := ColorRect.new()
	background.color = bg
	background.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	add_child(background)

	var safe := MarginContainer.new()
	safe.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	safe.add_theme_constant_override("margin_left", 16)
	safe.add_theme_constant_override("margin_right", 16)
	safe.add_theme_constant_override("margin_top", 20)
	safe.add_theme_constant_override("margin_bottom", 14)
	add_child(safe)

	var root := VBoxContainer.new()
	root.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	root.add_theme_constant_override("separation", 10)
	safe.add_child(root)

	var header := PanelContainer.new()
	header.add_theme_stylebox_override("panel", _panel_style(surface, border, 18))
	root.add_child(header)

	var hm := MarginContainer.new()
	hm.add_theme_constant_override("margin_left", 18)
	hm.add_theme_constant_override("margin_right", 18)
	hm.add_theme_constant_override("margin_top", 14)
	hm.add_theme_constant_override("margin_bottom", 14)
	header.add_child(hm)

	var hb := VBoxContainer.new()
	hb.add_theme_constant_override("separation", 4)
	hm.add_child(hb)

	var title := Label.new()
	title.text = "DOUBLE • HISTÓRICO + SIMULADOR"
	title.add_theme_font_size_override("font_size", 27)
	title.add_theme_color_override("font_color", text)
	title.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	title.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	hb.add_child(title)

	status_label = Label.new()
	status_label.text = "CONECTANDO AO NOSSO SERVIDOR..."
	status_label.add_theme_font_size_override("font_size", 18)
	status_label.add_theme_color_override("font_color", muted)
	hb.add_child(status_label)

	var page_host := Control.new()
	page_host.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	page_host.size_flags_vertical = Control.SIZE_EXPAND_FILL
	root.add_child(page_host)

	_build_history_page(page_host)
	_build_simulator_page(page_host)
	_build_optimizer_page(page_host)
	_build_balance_page(page_host)
	_build_saved_page(page_host)
	_build_demo_page(page_host)
	_build_white_page(page_host)

	var nav_panel := PanelContainer.new()
	nav_panel.add_theme_stylebox_override("panel", _panel_style(surface, border, 15))
	root.add_child(nav_panel)

	var nav_margin := MarginContainer.new()
	nav_margin.add_theme_constant_override("margin_left", 7)
	nav_margin.add_theme_constant_override("margin_right", 7)
	nav_margin.add_theme_constant_override("margin_top", 7)
	nav_margin.add_theme_constant_override("margin_bottom", 7)
	nav_panel.add_child(nav_margin)

	var nav_row := HFlowContainer.new()
	nav_row.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	nav_row.alignment = FlowContainer.ALIGNMENT_CENTER
	nav_row.add_theme_constant_override("h_separation", 6)
	nav_row.add_theme_constant_override("v_separation", 6)
	nav_margin.add_child(nav_row)

	nav_history = _nav_button("HISTÓRICO")
	nav_history.pressed.connect(func(): _show_page("history"))
	nav_row.add_child(nav_history)

	nav_sim = _nav_button("SIMULADOR")
	nav_sim.pressed.connect(func(): _show_page("simulator"))
	nav_row.add_child(nav_sim)

	nav_optimizer = _nav_button("OTIMIZADOR")
	nav_optimizer.pressed.connect(func(): _show_page("optimizer"))
	nav_row.add_child(nav_optimizer)

	nav_balance = _nav_button("EQUILÍBRIO")
	nav_balance.pressed.connect(func(): _show_page("balance"))
	nav_row.add_child(nav_balance)

	nav_saved = _nav_button("SALVAS")
	nav_saved.pressed.connect(func(): _show_page("saved"))
	nav_row.add_child(nav_saved)

	nav_demo = _nav_button("DEMO")
	nav_demo.pressed.connect(func(): _show_page("demo"))
	nav_row.add_child(nav_demo)

	nav_white = _nav_button("BRANCO")
	nav_white.pressed.connect(func(): _show_page("white"))
	nav_row.add_child(nav_white)


func _build_history_page(host: Control) -> void:
	var page := _new_page(host, "history")
	var box := page.get_child(0) as VBoxContainer

	var info_row := HBoxContainer.new()
	info_row.add_theme_constant_override("separation", 10)
	box.add_child(info_row)

	var count_card := _mini_card(info_row, "BASE ESTATÍSTICA")
	count_label = Label.new()
	count_label.text = "0 / 30000"
	count_label.add_theme_font_size_override("font_size", 27)
	count_label.add_theme_color_override("font_color", green)
	count_card.add_child(count_label)

	var update_card := _mini_card(info_row, "ATUALIZAÇÃO")
	updated_label = Label.new()
	updated_label.text = "-"
	updated_label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	updated_label.add_theme_font_size_override("font_size", 17)
	updated_label.add_theme_color_override("font_color", text)
	update_card.add_child(updated_label)

	var refresh := _button("ATUALIZAR AGORA")
	refresh.pressed.connect(_request_all)
	box.add_child(refresh)

	var validation_note := _label(
		"SEGURANÇA: somente sequência real. Lacunas nunca são preenchidas. Backtests e estratégias usam apenas o bloco contínuo mais recente.",
		14, false
	)
	validation_note.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	validation_note.add_theme_color_override("font_color", muted)
	box.add_child(validation_note)

	continuity_label = Label.new()
	continuity_label.text = "AUDITORIA: aguardando dados..."
	continuity_label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	continuity_label.add_theme_font_size_override("font_size", 15)
	continuity_label.add_theme_color_override("font_color", muted)
	box.add_child(continuity_label)

	var label := Label.new()
	label.text = "RODADAS • MAIS RECENTES PRIMEIRO"
	label.add_theme_font_size_override("font_size", 16)
	label.add_theme_color_override("font_color", muted)
	box.add_child(label)

	history_scroll = ScrollContainer.new()
	history_scroll.size_flags_vertical = Control.SIZE_EXPAND_FILL
	history_scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	history_scroll.vertical_scroll_mode = ScrollContainer.SCROLL_MODE_AUTO
	history_scroll.mouse_filter = Control.MOUSE_FILTER_PASS
	history_scroll.follow_focus = false
	history_scroll.scroll_deadzone = 4
	box.add_child(history_scroll)

	list_box = VBoxContainer.new()
	list_box.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	list_box.add_theme_constant_override("separation", 7)
	history_scroll.add_child(list_box)

	load_more_button = _button("CARREGAR MAIS")
	load_more_button.pressed.connect(_load_more)
	box.add_child(load_more_button)


func _build_simulator_page(host: Control) -> void:
	var page := _new_page(host, "simulator")
	var outer := page.get_child(0) as VBoxContainer

	simulator_scroll = ScrollContainer.new()
	simulator_scroll.size_flags_vertical = Control.SIZE_EXPAND_FILL
	simulator_scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	simulator_scroll.vertical_scroll_mode = ScrollContainer.SCROLL_MODE_AUTO
	simulator_scroll.mouse_filter = Control.MOUSE_FILTER_PASS
	simulator_scroll.follow_focus = false
	simulator_scroll.scroll_deadzone = 4
	outer.add_child(simulator_scroll)

	var box := VBoxContainer.new()
	box.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	box.custom_minimum_size.x = 1
	box.add_theme_constant_override("separation", 10)
	simulator_scroll.add_child(box)

	var intro := _card(box, "SIMULAÇÃO RÁPIDA", green)
	var note := _label(
		"Padrão → entrada → Gale. Ex.: V,P,V",
		17,
		false
	)
	note.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	intro.add_child(note)

	strategy_name = LineEdit.new()
	strategy_name.placeholder_text = "Nome da estratégia"
	strategy_name.custom_minimum_size.y = 58
	strategy_name.add_theme_font_size_override("font_size", 20)
	intro.add_child(strategy_name)

	strategy_pattern = LineEdit.new()
	strategy_pattern.placeholder_text = "Padrão: V,P,V"
	strategy_pattern.custom_minimum_size.y = 58
	strategy_pattern.add_theme_font_size_override("font_size", 20)
	intro.add_child(strategy_pattern)

	var entry_row := HBoxContainer.new()
	entry_row.add_theme_constant_override("separation", 8)
	intro.add_child(entry_row)

	strategy_entry = OptionButton.new()
	strategy_entry.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	strategy_entry.custom_minimum_size.y = 58
	strategy_entry.add_item("ENTRAR VERMELHO", 0)
	strategy_entry.add_item("ENTRAR PRETO", 1)
	strategy_entry.add_item("ENTRAR BRANCO", 2)
	entry_row.add_child(strategy_entry)

	strategy_contrarian = CheckButton.new()
	strategy_contrarian.text = "APOSTA CONTRÁRIA • INVERTER VERMELHO ↔ PRETO"
	strategy_contrarian.button_pressed = false
	intro.add_child(strategy_contrarian)

	var contrary_note := _label(
		"Ex.: V,V,V → PRETO. Com APOSTA CONTRÁRIA ligada, a entrada vira VERMELHO.",
		14, false
	)
	contrary_note.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	intro.add_child(contrary_note)

	strategy_gale = OptionButton.new()
	strategy_gale.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	strategy_gale.custom_minimum_size.y = 58
	strategy_gale.add_item("SEM GALE", 0)
	for g in range(1, 12):
		strategy_gale.add_item("MÁXIMO G%d" % g, g)
	entry_row.add_child(strategy_gale)

	strategy_gale_mode = OptionButton.new()
	strategy_gale_mode.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	strategy_gale_mode.custom_minimum_size.y = 58
	strategy_gale_mode.add_item("GALE TRADICIONAL • PRÓXIMA RODADA", 0)
	strategy_gale_mode.add_item("GALE NO PRÓXIMO SINAL", 1)
	for skip in range(1, 10):
		strategy_gale_mode.add_item("GALE • PULAR %d RODADA%s" % [skip, "" if skip == 1 else "S"], skip + 1)
	for skip_signal in range(1, 10):
		strategy_gale_mode.add_item("GALE • PULAR %d SINAL%s" % [skip_signal, "" if skip_signal == 1 else "IS"], skip_signal + 10)
	entry_row.add_child(strategy_gale_mode)

	var stake_row := HBoxContainer.new()
	stake_row.add_theme_constant_override("separation", 8)
	intro.add_child(stake_row)

	var stake_text := _label("ENTRADA R$", 18, true)
	stake_text.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	stake_row.add_child(stake_text)

	strategy_stake = SpinBox.new()
	strategy_stake.min_value = 1.0
	strategy_stake.max_value = 10000.0
	strategy_stake.step = 1.0
	strategy_stake.value = 10.0
	strategy_stake.custom_minimum_size = Vector2(220, 58)
	stake_styling(strategy_stake)
	stake_row.add_child(strategy_stake)

	strategy_white_protection_enabled = CheckButton.new()
	strategy_white_protection_enabled.text = "PROTEGER BRANCO EM TODA ENTRADA"
	intro.add_child(strategy_white_protection_enabled)

	var wp_row := HBoxContainer.new()
	intro.add_child(wp_row)
	wp_row.add_child(_label("PROTEÇÃO NO BRANCO R$", 16, true))
	strategy_white_protection_stake = SpinBox.new()
	strategy_white_protection_stake.min_value = 0.10
	strategy_white_protection_stake.max_value = 10000.0
	strategy_white_protection_stake.step = 0.10
	strategy_white_protection_stake.value = 1.0
	strategy_white_protection_stake.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	wp_row.add_child(strategy_white_protection_stake)

	var wp_note := _label(
		"Ex.: entrada R$10 + R$1 no branco. Acertando V/P: +R$9 líquido. Saindo branco: -R$10 -R$1 +R$14 = +R$3.",
		14, false
	)
	wp_note.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	intro.add_child(wp_note)

	var bank_text := _label("BANCA R$", 18, true)
	bank_text.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	stake_row.add_child(bank_text)

	strategy_bank = SpinBox.new()
	strategy_bank.min_value = 1.0
	strategy_bank.max_value = 100000000.0
	strategy_bank.step = 10.0
	strategy_bank.value = 1000.0
	strategy_bank.custom_minimum_size = Vector2(220, 58)
	stake_styling(strategy_bank)
	stake_row.add_child(strategy_bank)

	var risk_card := _card(box, "GESTÃO DE RISCO", purple)
	var risk_box := risk_card
	var risk_note := _label("Cada proteção pode ser ativada ou desativada separadamente. A primeira condição atingida encerra novas entradas.", 15, false)
	risk_note.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	risk_box.add_child(risk_note)

	risk_trailing_enabled = CheckButton.new()
	risk_trailing_enabled.text = "ATIVAR TRAILING STOP"
	risk_box.add_child(risk_trailing_enabled)
	var trailing_row := HBoxContainer.new()
	risk_box.add_child(trailing_row)
	trailing_row.add_child(_label("QUEDA DO PICO (%)", 16, true))
	risk_trailing_pct = SpinBox.new()
	risk_trailing_pct.min_value = 0.1
	risk_trailing_pct.max_value = 100.0
	risk_trailing_pct.step = 0.1
	risk_trailing_pct.value = 15.0
	risk_trailing_pct.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	trailing_row.add_child(risk_trailing_pct)

	risk_capital_enabled = CheckButton.new()
	risk_capital_enabled.text = "ATIVAR PROTEÇÃO DE CAPITAL"
	risk_box.add_child(risk_capital_enabled)
	var capital_row := HBoxContainer.new()
	risk_box.add_child(capital_row)
	capital_row.add_child(_label("BANCA MÍNIMA PROTEGIDA R$", 16, true))
	risk_capital_floor = SpinBox.new()
	risk_capital_floor.min_value = 0.0
	risk_capital_floor.max_value = 100000000.0
	risk_capital_floor.step = 10.0
	risk_capital_floor.value = 1000.0
	risk_capital_floor.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	capital_row.add_child(risk_capital_floor)

	risk_performance_enabled = CheckButton.new()
	risk_performance_enabled.text = "ATIVAR STOP POR DESEMPENHO"
	risk_box.add_child(risk_performance_enabled)
	var perf_row := HBoxContainer.new()
	risk_box.add_child(perf_row)
	perf_row.add_child(_label("ÚLTIMAS ENTRADAS", 16, true))
	risk_performance_window = SpinBox.new()
	risk_performance_window.min_value = 1
	risk_performance_window.max_value = 500
	risk_performance_window.step = 1
	risk_performance_window.value = 20
	risk_performance_window.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	perf_row.add_child(risk_performance_window)
	perf_row.add_child(_label("ACERTO MÍN. %", 16, true))
	risk_performance_min_rate = SpinBox.new()
	risk_performance_min_rate.min_value = 0.0
	risk_performance_min_rate.max_value = 100.0
	risk_performance_min_rate.step = 0.5
	risk_performance_min_rate.value = 50.0
	risk_performance_min_rate.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	perf_row.add_child(risk_performance_min_rate)

	var sim := _button("SIMULAR NO HISTÓRICO")
	sim.pressed.connect(_simulate_current)
	intro.add_child(sim)

	var save := _button("SALVAR ESTRATÉGIA")
	save.pressed.connect(_save_current_strategy)
	intro.add_child(save)


	var result_card := _card(box, "RESULTADO DA SIMULAÇÃO", purple)
	sim_result = _label("Crie uma estratégia e toque em SIMULAR.", 20, false)
	sim_result.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	sim_result.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	result_card.add_child(sim_result)


func _build_optimizer_page(host: Control) -> void:
	var page := _new_page(host, "optimizer")
	var outer := page.get_child(0) as VBoxContainer

	optimizer_scroll = ScrollContainer.new()
	optimizer_scroll.size_flags_vertical = Control.SIZE_EXPAND_FILL
	optimizer_scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	optimizer_scroll.vertical_scroll_mode = ScrollContainer.SCROLL_MODE_AUTO
	optimizer_scroll.mouse_filter = Control.MOUSE_FILTER_PASS
	optimizer_scroll.follow_focus = false
	optimizer_scroll.scroll_deadzone = 4
	outer.add_child(optimizer_scroll)

	var box := VBoxContainer.new()
	box.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	box.custom_minimum_size.x = 1
	box.add_theme_constant_override("separation", 10)
	optimizer_scroll.add_child(box)

	var head := _card(box, "OTIMIZADOR", green)
	var note := _label("Escolha o que deve ficar fixo. Você pode buscar MAIOR LUCRO ou MAIOR PREJUÍZO. Todos os filtros continuam valendo; no modo prejuízo vence o resultado financeiro mais negativo dentro dos filtros.", 16, false)
	note.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	head.add_child(note)

	var gale_title := _label("GALE QUE EU QUERO", 16, true)
	head.add_child(gale_title)
	auto_search_gale = OptionButton.new()
	auto_search_gale.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	auto_search_gale.fit_to_longest_item = false
	auto_search_gale.custom_minimum_size.x = 1
	auto_search_gale.add_item("MELHOR GERAL • TESTAR G0 ATÉ G11")
	for g in range(0, 12):
		auto_search_gale.add_item("QUERO A MELHOR USANDO G%d" % g)
	head.add_child(auto_search_gale)

	var mode_title := _label("MODO DO GALE", 16, true)
	head.add_child(mode_title)
	auto_gale_mode = OptionButton.new()
	auto_gale_mode.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	auto_gale_mode.fit_to_longest_item = false
	auto_gale_mode.custom_minimum_size.x = 1
	auto_gale_mode.add_item("MELHOR MODO AUTOMATICAMENTE", -1)
	auto_gale_mode.add_item("TRADICIONAL • PRÓXIMA RODADA", 0)
	auto_gale_mode.add_item("PRÓXIMO SINAL", 1)
	for skip in range(1, 10):
		auto_gale_mode.add_item("PULAR %d RODADA%s" % [skip, "" if skip == 1 else "S"], skip + 1)
	for skip_signal in range(1, 10):
		auto_gale_mode.add_item("PULAR %d SINAL%s" % [skip_signal, "" if skip_signal == 1 else "IS"], skip_signal + 10)
	head.add_child(auto_gale_mode)

	var count_title := _label("QUANTAS ESTRATÉGIAS COMBINAR", 16, true)
	head.add_child(count_title)
	auto_strategy_count = OptionButton.new()
	auto_strategy_count.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	auto_strategy_count.fit_to_longest_item = false
	auto_strategy_count.custom_minimum_size.x = 1
	auto_strategy_count.add_item("MELHOR QUANTIDADE AUTOMATICAMENTE", -1)
	for n in range(1, 1001):
		auto_strategy_count.add_item("ATÉ %d ESTRATÉGIA%s" % [n, "" if n == 1 else "S"], n)
	for n in [1500, 2000, 2500, 3000]:
		auto_strategy_count.add_item("ATÉ %d ESTRATÉGIAS" % n, n)
	head.add_child(auto_strategy_count)

	var consensus_title := _label("CONSENSO ENTRE AS ESTRATÉGIAS", 16, true)
	head.add_child(consensus_title)
	auto_consensus = OptionButton.new()
	auto_consensus.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	auto_consensus.fit_to_longest_item = false
	auto_consensus.custom_minimum_size.x = 1
	auto_consensus.add_item("MELHOR CONSENSO AUTOMATICAMENTE", -1)
	auto_consensus.add_item("MAIORIA SIMPLES • >50%", 50)
	auto_consensus.add_item("MÍNIMO 60%", 60)
	auto_consensus.add_item("MÍNIMO 70%", 70)
	auto_consensus.add_item("MÍNIMO 80%", 80)
	auto_consensus.add_item("MÍNIMO 90%", 90)
	auto_consensus.add_item("UNANIMIDADE • 100%", 100)
	auto_consensus.select(1)
	head.add_child(auto_consensus)
	var consensus_note := _label("Só conta estratégia que realmente gerou sinal naquela rodada. Empate = sem entrada.", 14, false)
	consensus_note.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	head.add_child(consensus_note)

	auto_contrarian = CheckButton.new()
	auto_contrarian.text = "APOSTA CONTRÁRIA • INVERTER SINAL FINAL V ↔ P"
	auto_contrarian.button_pressed = false
	head.add_child(auto_contrarian)

	head.add_child(_label("OBJETIVO DO OTIMIZADOR", 16, true))
	auto_objective_mode = OptionButton.new()
	auto_objective_mode.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	auto_objective_mode.fit_to_longest_item = false
	auto_objective_mode.add_item("MAIOR LUCRO • GERAR A MELHOR POSITIVA", 0)
	auto_objective_mode.add_item("MAIOR PREJUÍZO • GERAR A PIOR FINANCEIRAMENTE", 1)
	auto_objective_mode.select(0)
	head.add_child(auto_objective_mode)

	var objective_note := _label(
		"MAIOR PREJUÍZO procura, entre as configurações que passam pelos filtros, a que teve o resultado financeiro MAIS NEGATIVO no histórico. WIN, LOSS, acerto e valor do prejuízo continuam sendo exibidos.",
		14, false
	)
	objective_note.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	head.add_child(objective_note)

	var wp_title := _label("PROTEÇÃO NO BRANCO", 18, true)
	head.add_child(wp_title)

	auto_white_protection_enabled = CheckButton.new()
	auto_white_protection_enabled.text = "USAR PROTEÇÃO NO BRANCO EM TODAS AS ENTRADAS"
	auto_white_protection_enabled.button_pressed = false
	head.add_child(auto_white_protection_enabled)

	var wp_gen_row := HBoxContainer.new()
	wp_gen_row.add_theme_constant_override("separation", 8)
	head.add_child(wp_gen_row)
	wp_gen_row.add_child(_label("VALOR NO BRANCO R$", 16, true))
	auto_white_protection_stake = SpinBox.new()
	auto_white_protection_stake.min_value = 0.10
	auto_white_protection_stake.max_value = 10000.0
	auto_white_protection_stake.step = 0.10
	auto_white_protection_stake.value = 1.0
	auto_white_protection_stake.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	wp_gen_row.add_child(auto_white_protection_stake)

	var wp_gen_note := _label(
		"O GERADOR calcula tudo já com a proteção: custo do branco em TODA entrada e retorno total 14x quando sair BRANCO. Ex.: R$10 + R$1 => WIN +R$9 | LOSS -R$11 | BRANCO +R$3.",
		14, false
	)
	wp_gen_note.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	head.add_child(wp_gen_note)

	auto_min_entries_enabled = CheckButton.new()
	auto_min_entries_enabled.text = "EXIGIR MÍNIMO DE ENTRADAS"
	head.add_child(auto_min_entries_enabled)

	head.add_child(_label("MÍNIMO DE ENTRADAS", 16, true))
	auto_min_entries = SpinBox.new()
	auto_min_entries.min_value = 0
	auto_min_entries.max_value = 30000
	auto_min_entries.step = 10
	auto_min_entries.value = 300
	auto_min_entries.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	head.add_child(auto_min_entries)

	auto_min_signal_pct_enabled = CheckButton.new()
	auto_min_signal_pct_enabled.text = "EXIGIR FREQUÊNCIA MÍNIMA DE SINAIS"
	head.add_child(auto_min_signal_pct_enabled)

	head.add_child(_label("FREQUÊNCIA MÍNIMA DE SINAIS %", 16, true))
	auto_min_signal_pct = SpinBox.new()
	auto_min_signal_pct.min_value = 0.0
	auto_min_signal_pct.max_value = 100.0
	auto_min_signal_pct.step = 1.0
	auto_min_signal_pct.value = 20.0
	auto_min_signal_pct.suffix = "%"
	auto_min_signal_pct.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	head.add_child(auto_min_signal_pct)

	var freq_note := _label(
		"Use junto com MAIOR PREJUÍZO para evitar estratégias raras. Ex.: 300 entradas + 20% de frequência = procura uma estratégia ruim que também gere muitos sinais.",
		14, false
	)
	freq_note.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	head.add_child(freq_note)

	auto_min_rate_enabled = CheckButton.new()
	auto_min_rate_enabled.text = "EXIGIR PORCENTAGEM DE ACERTO"
	head.add_child(auto_min_rate_enabled)

	head.add_child(_label("MODO DA PORCENTAGEM", 16, true))
	auto_rate_mode = OptionButton.new()
	auto_rate_mode.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	auto_rate_mode.fit_to_longest_item = false
	auto_rate_mode.add_item("ACERTO MÍNIMO • ACEITAR % OU MAIS", 0)
	auto_rate_mode.add_item("ACERTO MÁXIMO • ACEITAR ATÉ %", 1)
	auto_rate_mode.select(0)
	head.add_child(auto_rate_mode)

	var rate_row := VBoxContainer.new()
	rate_row.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	head.add_child(rate_row)
	rate_row.add_child(_label("PORCENTAGEM DE ACERTO %", 16, true))

	auto_min_rate = SpinBox.new()
	auto_min_rate.min_value = 0.0
	auto_min_rate.max_value = 100.0
	auto_min_rate.step = 0.5
	auto_min_rate.value = 70.0
	auto_min_rate.suffix = "%"
	auto_min_rate.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	auto_min_rate.custom_minimum_size.x = 90
	rate_row.add_child(auto_min_rate)

	var rate_note := _label(
		"MÍNIMO: ex. 80% = só concorrem estratégias com 80% ou mais.\\nMÁXIMO: ex. 20% = só concorrem estratégias com até 20%, mesmo com prejuízo. Entre as válidas, vence o maior lucro; empate = menor drawdown.",
		14, false
	)
	rate_note.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	head.add_child(rate_note)

	auto_dd_limit_enabled = CheckButton.new()
	auto_dd_limit_enabled.text = "LIMITAR DRAWDOWN"
	head.add_child(auto_dd_limit_enabled)
	var dd_row := VBoxContainer.new()
	dd_row.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	head.add_child(dd_row)
	dd_row.add_child(_label("DRAWDOWN MÁXIMO R$", 16, true))
	auto_dd_limit = SpinBox.new()
	auto_dd_limit.min_value = 0.0
	auto_dd_limit.max_value = 100000000.0
	auto_dd_limit.step = 10.0
	auto_dd_limit.value = 500.0
	auto_dd_limit.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	auto_dd_limit.custom_minimum_size.x = 90
	dd_row.add_child(auto_dd_limit)

	auto_optimize_all = CheckButton.new()
	auto_optimize_all.button_pressed = true
	auto_optimize_all.visible = false
	auto_gale = OptionButton.new()
	auto_gale.visible = false

	var speed_title := _label("MODO DE PROCESSAMENTO", 16, true)
	head.add_child(speed_title)
	auto_speed_mode = OptionButton.new()
	auto_speed_mode.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	auto_speed_mode.fit_to_longest_item = false
	auto_speed_mode.custom_minimum_size.x = 1
	auto_speed_mode.add_item("EXATO NO SERVIDOR • TESTAR TODAS AS OPÇÕES", 0)
	auto_speed_mode.add_item("RÁPIDO • DESATIVADO (EXATO OBRIGATÓRIO)", 1)
	auto_speed_mode.select(0)
	head.add_child(auto_speed_mode)

	auto_generate_button = _button("ENCONTRAR A MELHOR")
	auto_generate_button.pressed.connect(_generate_best_strategy)
	head.add_child(auto_generate_button)
	var save_generated := _button("SALVAR MELHOR ESTRATÉGIA")
	save_generated.pressed.connect(_save_generated_strategy)
	head.add_child(save_generated)

	var result_card := _card(box, "MELHOR RESULTADO ENCONTRADO", purple)
	optimizer_result = _label("Configure o filtro e toque em ENCONTRAR A MELHOR.", 19, false)
	optimizer_result.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	optimizer_result.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	result_card.add_child(optimizer_result)



func _build_balance_page(host: Control) -> void:
	var page := _new_page(host, "balance")
	var outer := page.get_child(0) as VBoxContainer

	balance_scroll = ScrollContainer.new()
	balance_scroll.size_flags_vertical = Control.SIZE_EXPAND_FILL
	balance_scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	balance_scroll.vertical_scroll_mode = ScrollContainer.SCROLL_MODE_AUTO
	balance_scroll.mouse_filter = Control.MOUSE_FILTER_PASS
	balance_scroll.follow_focus = false
	balance_scroll.scroll_deadzone = 4
	outer.add_child(balance_scroll)

	var box := VBoxContainer.new()
	box.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	box.custom_minimum_size.x = 1
	box.add_theme_constant_override("separation", 12)
	balance_scroll.add_child(box)

	var head := _card(box, "EQUILÍBRIO • LUCRO × DRAWDOWN × EFETIVIDADE", green)
	var note := _label(
		"Esta aba NÃO procura apenas o maior lucro. Ela dá uma nota para cada configuração usando lucro, drawdown e taxa de acerto. Quanto maior o peso, mais importante aquele fator fica na escolha.",
		15, false
	)
	note.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	head.add_child(note)

	var gale_title := _label("GALE", 16, true)
	head.add_child(gale_title)
	balance_gale_select = OptionButton.new()
	balance_gale_select.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	balance_gale_select.fit_to_longest_item = false
	balance_gale_select.custom_minimum_size.x = 1
	balance_gale_select.add_item("MELHOR GERAL • TESTAR G0 ATÉ G11", -1)
	for g in range(0, 12):
		balance_gale_select.add_item("USAR EXATAMENTE G%d" % g, g)
	head.add_child(balance_gale_select)

	var mode_title := _label("MODO DO GALE", 16, true)
	head.add_child(mode_title)
	balance_gale_mode_select = OptionButton.new()
	balance_gale_mode_select.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	balance_gale_mode_select.fit_to_longest_item = false
	balance_gale_mode_select.custom_minimum_size.x = 1
	balance_gale_mode_select.add_item("MELHOR MODO AUTOMATICAMENTE", -1)
	balance_gale_mode_select.add_item("TRADICIONAL • PRÓXIMA RODADA", 0)
	balance_gale_mode_select.add_item("PRÓXIMO SINAL", 1)
	for skip in range(1, 10):
		balance_gale_mode_select.add_item("PULAR %d RODADA%s" % [skip, "" if skip == 1 else "S"], skip + 1)
	for skip_signal in range(1, 10):
		balance_gale_mode_select.add_item("PULAR %d SINAL%s" % [skip_signal, "" if skip_signal == 1 else "IS"], skip_signal + 10)
	head.add_child(balance_gale_mode_select)

	balance_contrarian = CheckButton.new()
	balance_contrarian.text = "APOSTA CONTRÁRIA • INVERTER SINAL FINAL V ↔ P"
	balance_contrarian.button_pressed = false
	head.add_child(balance_contrarian)

	var p_row := VBoxContainer.new()
	p_row.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	head.add_child(p_row)
	p_row.add_child(_label("PESO DO LUCRO", 16, true))
	balance_profit_weight = SpinBox.new()
	balance_profit_weight.min_value = 0
	balance_profit_weight.max_value = 100
	balance_profit_weight.step = 5
	balance_profit_weight.value = 45
	balance_profit_weight.suffix = "%"
	balance_profit_weight.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	balance_profit_weight.custom_minimum_size.x = 90
	p_row.add_child(balance_profit_weight)

	var d_row := VBoxContainer.new()
	d_row.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	head.add_child(d_row)
	d_row.add_child(_label("PESO DO DRAWDOWN", 16, true))
	balance_dd_weight = SpinBox.new()
	balance_dd_weight.min_value = 0
	balance_dd_weight.max_value = 100
	balance_dd_weight.step = 5
	balance_dd_weight.value = 35
	balance_dd_weight.suffix = "%"
	balance_dd_weight.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	balance_dd_weight.custom_minimum_size.x = 90
	d_row.add_child(balance_dd_weight)

	var r_row := VBoxContainer.new()
	r_row.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	head.add_child(r_row)
	r_row.add_child(_label("PESO DA EFETIVIDADE", 16, true))
	balance_rate_weight = SpinBox.new()
	balance_rate_weight.min_value = 0
	balance_rate_weight.max_value = 100
	balance_rate_weight.step = 5
	balance_rate_weight.value = 20
	balance_rate_weight.suffix = "%"
	balance_rate_weight.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	balance_rate_weight.custom_minimum_size.x = 90
	r_row.add_child(balance_rate_weight)

	var examples := _label(
		"PADRÃO: 45% lucro • 35% drawdown • 20% acerto.\n"
		+ "Mais segurança: aumente DRAWDOWN/EFETIVIDADE.\n"
		+ "Mais agressivo: aumente LUCRO.",
		14, false
	)
	examples.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	examples.add_theme_color_override("font_color", muted)
	head.add_child(examples)

	var balance_speed_title := _label("MODO DE PROCESSAMENTO", 16, true)
	head.add_child(balance_speed_title)
	balance_speed_mode = OptionButton.new()
	balance_speed_mode.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	balance_speed_mode.fit_to_longest_item = false
	balance_speed_mode.custom_minimum_size.x = 1
	balance_speed_mode.add_item("EXATO NO SERVIDOR • TESTAR TODAS AS OPÇÕES", 0)
	balance_speed_mode.add_item("RÁPIDO • DESATIVADO (EXATO OBRIGATÓRIO)", 1)
	balance_speed_mode.select(0)
	head.add_child(balance_speed_mode)

	balance_generate_button = _button("ENCONTRAR MELHOR EQUILÍBRIO")
	balance_generate_button.pressed.connect(_generate_balance_optimization)
	head.add_child(balance_generate_button)

	var save_balance := _button("SALVAR ESTRATÉGIA DE EQUILÍBRIO")
	save_balance.pressed.connect(_save_balance_strategy)
	head.add_child(save_balance)

	var result_card := _card(box, "MELHOR EQUILÍBRIO ENCONTRADO", purple)
	balance_result = _label("Configure os pesos e toque em ENCONTRAR MELHOR EQUILÍBRIO.", 19, false)
	balance_result.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	balance_result.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	result_card.add_child(balance_result)


func _balance_score(result: Dictionary, strategy: Dictionary, w_profit: float, w_dd: float, w_rate: float) -> float:
	var initial_bank: float = maxf(1.0, float(strategy.get("initial_bank", 1000.0)))
	var profit_pct: float = 100.0 * float(result.get("profit", 0.0)) / initial_bank
	var dd_pct: float = float(result.get("max_dd_pct", -1.0))
	if dd_pct < 0.0:
		dd_pct = 100.0 * float(result.get("max_dd", 0.0)) / initial_bank
	var rate: float = float(result.get("rate", 0.0))
	var total_weight: float = maxf(1.0, w_profit + w_dd + w_rate)
	return (
		profit_pct * (w_profit / total_weight)
		+ rate * (w_rate / total_weight)
		- dd_pct * (w_dd / total_weight)
	)


func _generate_balance_optimization() -> void:
	if auto_optimizing:
		if balance_result != null:
			balance_result.text = "O OTIMIZADOR JÁ ESTÁ PROCESSANDO. Aguarde terminar."
		return

	auto_optimizing = true
	if balance_generate_button != null:
		balance_generate_button.disabled = true
		balance_generate_button.text = "ANALISANDO EQUILÍBRIO..."

	var w_profit: float = float(balance_profit_weight.value) if balance_profit_weight != null else 45.0
	var w_dd: float = float(balance_dd_weight.value) if balance_dd_weight != null else 35.0
	var w_rate: float = float(balance_rate_weight.value) if balance_rate_weight != null else 20.0

	var best_score: float = -INF
	var best_strategy: Dictionary = {}
	var best_result: Dictionary = {}
	var tested: int = 0
	var fast_mode: bool = false # V3.53: equilíbrio também percorre todas as quantidades

	var gale_values: Array[int] = []
	if balance_gale_select != null and balance_gale_select.get_item_id(balance_gale_select.selected) >= 0:
		gale_values.append(balance_gale_select.get_item_id(balance_gale_select.selected))
	else:
		for g in range(0, 12):
			gale_values.append(g)

	var gale_mode_values: Array[int] = []
	if balance_gale_mode_select != null and balance_gale_mode_select.get_item_id(balance_gale_mode_select.selected) >= 0:
		gale_mode_values.append(balance_gale_mode_select.get_item_id(balance_gale_mode_select.selected))
	else:
		for m in range(0, 20):
			gale_mode_values.append(m)

	var total_configs: int = gale_values.size() * gale_mode_values.size() * 3000 * 6

	balance_result.text = (
		"ANALISANDO EQUILÍBRIO...\n\n"
		+ "PESOS: lucro %.0f • drawdown %.0f • efetividade %.0f\n"
		% [w_profit, w_dd, w_rate]
		+ "GALE: %s\n" % (
			"MELHOR G0-G11" if gale_values.size() > 1 else "G%d" % gale_values[0]
		)
		+ "MODO: %s\n" % (
			"MELHOR AUTOMATICAMENTE" if gale_mode_values.size() > 1 else _gale_mode_name(gale_mode_values[0])
		)
		+ "MODO: EXATO TOTAL • SEM AMOSTRAGEM • SEM CORTAR POSSIBILIDADES\n"
		+ "Busca completa dentro das opções escolhidas."
	)
	await get_tree().process_frame

	for gale in gale_values:
		for gale_mode in gale_mode_values:
			if not is_instance_valid(self):
				return

			var candidates: Array = await _base_candidate_library_async(gale, gale_mode)
			if candidates.is_empty():
				continue

			var max_count: int = mini(3000, candidates.size())
			var component_signal_caches: Array[PackedByteArray] = []
			var cache_prepared: int = 0
			for candidate in candidates.slice(0, max_count):
				if candidate is Dictionary:
					var cd: Dictionary = candidate
					var cached_signal = cd.get("_signal_cache", null)
					if cached_signal is PackedByteArray:
						component_signal_caches.append(cached_signal)
					else:
						component_signal_caches.append(_optimizer_component_signal_cache(cd))
				else:
					var empty_cache := PackedByteArray()
					empty_cache.resize(history.size())
					component_signal_caches.append(empty_cache)
				cache_prepared += 1
				if cache_prepared % 10 == 0 or cache_prepared == max_count:
					optimizer_result.text = (
						"PREPARANDO CACHE DE SINAIS\n\n"
						+ "%d / %d componentes\n" % [cache_prepared, max_count]
						+ "GALE: %s • MODO: %s\n" % [
							"G0" if gale == 0 else "G%d" % gale,
							_gale_mode_name(gale_mode)
						]
						+ "CONFIGURAÇÕES TESTADAS: %d / %d" % [tested, total_configs]
					)
					await get_tree().process_frame

			var votes_r := PackedByteArray()
			var votes_b := PackedByteArray()
			votes_r.resize(history.size())
			votes_b.resize(history.size())

			var balance_counts: Array[int] = _optimizer_count_values(max_count, 1, 3001, fast_mode)
			var balance_count_lookup: Dictionary = {}
			for n in balance_counts:
				balance_count_lookup[int(n)] = true

			var balance_exact_result_cache: Dictionary = {}

			for count in range(1, max_count + 1):
				var comp_cache: PackedByteArray = component_signal_caches[count - 1]
				for hi in range(history.size()):
					var code: int = int(comp_cache[hi])
					if code == 1:
						votes_r[hi] = mini(255, int(votes_r[hi]) + 1)
					elif code == 2:
						votes_b[hi] = mini(255, int(votes_b[hi]) + 1)

				if not balance_count_lookup.has(count):
					continue

				for consensus_pct in [50, 60, 70, 80, 90, 100]:
					var strategy: Dictionary = _build_ensemble_from_ranked(
						candidates, count, gale, gale_mode, consensus_pct
					)
					if strategy.is_empty():
						continue
					var contrary_enabled: bool = balance_contrarian != null and balance_contrarian.button_pressed
					strategy = _materialize_contrarian_strategy(strategy, contrary_enabled)
					if _strategy_is_blocked_for_generation(strategy):
						tested += 1
						continue

					var signal_cache: PackedByteArray = _optimizer_signal_from_votes(
						votes_r, votes_b, consensus_pct
					)
					if contrary_enabled:
						signal_cache = _invert_signal_cache_rb(signal_cache)
					strategy["_optimizer_signal_cache"] = signal_cache

					var cache_key: String = "%d:%d" % [
						_optimizer_signal_hash(signal_cache),
						signal_cache.size()
					]
					var result: Dictionary
					if balance_exact_result_cache.has(cache_key):
						result = (balance_exact_result_cache[cache_key] as Dictionary).duplicate(true)
					else:
						result = _simulate_strategy(strategy)
						balance_exact_result_cache[cache_key] = result.duplicate(true)

					tested += 1
					var score: float = _balance_score(result, strategy, w_profit, w_dd, w_rate)
					if score > best_score:
						best_score = score
						best_strategy = strategy.duplicate(true)
						best_strategy.erase("_optimizer_signal_cache")
						best_result = result.duplicate(true)
					elif is_equal_approx(score, best_score) and not best_strategy.is_empty():
						# Desempate: menor drawdown, depois maior lucro.
						var dd_now: float = float(result.get("max_dd", INF))
						var dd_best: float = float(best_result.get("max_dd", INF))
						if dd_now < dd_best or (
							is_equal_approx(dd_now, dd_best)
							and float(result.get("profit", -INF)) > float(best_result.get("profit", -INF))
						):
							best_strategy = strategy.duplicate(true)
							best_strategy.erase("_optimizer_signal_cache")
							best_result = result.duplicate(true)

					if tested % _optimizer_yield_every(fast_mode) == 0:
						balance_result.text = (
							"ANALISANDO EQUILÍBRIO...\n\n"
							+ "TESTADAS: %d / %d\n" % [tested, total_configs]
							+ "MELHOR NOTA ATÉ AGORA: %.3f\n" % best_score
							+ "LUCRO: R$ %+.2f • DD: R$ %.2f • ACERTO: %.1f%%"
							% [
								float(best_result.get("profit", 0.0)),
								float(best_result.get("max_dd", 0.0)),
								float(best_result.get("rate", 0.0))
							]
						)
						await get_tree().process_frame

	auto_optimizing = false
	if balance_generate_button != null:
		balance_generate_button.disabled = false
		balance_generate_button.text = "ENCONTRAR MELHOR EQUILÍBRIO"

	if best_strategy.is_empty():
		balance_generated_strategy.clear()
		balance_result.text = "Nenhuma configuração válida foi encontrada."
		return

	balance_generated_strategy = best_strategy.duplicate(true)
	balance_generated_strategy["balance_score"] = best_score
	balance_generated_strategy["balance_profit_weight"] = w_profit
	balance_generated_strategy["balance_dd_weight"] = w_dd
	balance_generated_strategy["balance_rate_weight"] = w_rate
	balance_generated_strategy["balance_requested_gale"] = (
		balance_gale_select.get_item_id(balance_gale_select.selected) if balance_gale_select != null else -1
	)
	balance_generated_strategy["balance_requested_gale_mode"] = (
		balance_gale_mode_select.get_item_id(balance_gale_mode_select.selected) if balance_gale_mode_select != null else -1
	)
	balance_generated_strategy["name"] = "EQUILÍBRIO • " + str(balance_generated_strategy.get("name", "ESTRATÉGIA"))

	balance_result.text = (
		"EQUILÍBRIO ENCONTRADO\n\n"
		+ "NOTA: %.3f\n" % best_score
		+ "PESOS: lucro %.0f%% • drawdown %.0f%% • efetividade %.0f%%\n"
		% [w_profit, w_dd, w_rate]
		+ "GALE ESCOLHIDO: G%d\n" % int(balance_generated_strategy.get("gale", 0))
		+ "MODO ESCOLHIDO: %s\n\n" % _gale_mode_name(int(balance_generated_strategy.get("gale_mode", 0)))
		+ _result_text(balance_generated_strategy, best_result)
	)


func _save_balance_strategy() -> void:
	if balance_generated_strategy.is_empty():
		if balance_result != null:
			balance_result.text = "Encontre uma estratégia de equilíbrio antes de salvar."
		return

	if _strategy_already_saved(balance_generated_strategy):
		if balance_result != null:
			balance_result.text = (
				"ESSA CONFIGURAÇÃO JÁ EXISTE EM SALVAS.\n\n"
				+ "Ela só volta a ser elegível depois que você EXCLUIR a existente."
			)
		return

	var copy: Dictionary = balance_generated_strategy.duplicate(true)
	copy["id"] = "balance_%d_%d" % [Time.get_unix_time_from_system(), randi_range(1000, 9999)]
	copy["created_at"] = Time.get_datetime_string_from_system()
	copy["blocked"] = false
	strategies.append(copy)
	_save_strategies()
	_render_saved_strategies()
	if balance_result != null:
		var result: Dictionary = _simulate_strategy(copy)
		balance_result.text = "ESTRATÉGIA DE EQUILÍBRIO SALVA\n\n" + _result_text(copy, result)



func _build_saved_page(host: Control) -> void:
	var page := _new_page(host, "saved")
	var outer := page.get_child(0) as VBoxContainer

	var summary := _card(outer, "MINHAS ESTRATÉGIAS", purple)
	saved_summary = _label("0 estratégias salvas.", 20, true)
	summary.add_child(saved_summary)

	var tabs := HBoxContainer.new()
	tabs.add_theme_constant_override("separation", 8)
	summary.add_child(tabs)

	saved_active_tab = _button("ATIVAS")
	saved_active_tab.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	saved_active_tab.pressed.connect(func():
		saved_show_blocked = false
		_render_saved_strategies()
	)
	tabs.add_child(saved_active_tab)

	saved_blocked_tab = _button("BLOQUEADAS")
	saved_blocked_tab.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	saved_blocked_tab.pressed.connect(func():
		saved_show_blocked = true
		_render_saved_strategies()
	)
	tabs.add_child(saved_blocked_tab)

	saved_scroll = ScrollContainer.new()
	saved_scroll.size_flags_vertical = Control.SIZE_EXPAND_FILL
	saved_scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	saved_scroll.vertical_scroll_mode = ScrollContainer.SCROLL_MODE_AUTO
	saved_scroll.mouse_filter = Control.MOUSE_FILTER_PASS
	saved_scroll.follow_focus = false
	saved_scroll.scroll_deadzone = 4
	outer.add_child(saved_scroll)

	saved_list = VBoxContainer.new()
	saved_list.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	saved_list.custom_minimum_size.x = 1
	saved_list.add_theme_constant_override("separation", 9)
	saved_scroll.add_child(saved_list)

	_render_saved_strategies()


func _build_demo_page(host: Control) -> void:
	var page := _new_page(host, "demo")
	var outer := page.get_child(0) as VBoxContainer

	demo_scroll = ScrollContainer.new()
	demo_scroll.size_flags_vertical = Control.SIZE_EXPAND_FILL
	demo_scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	demo_scroll.vertical_scroll_mode = ScrollContainer.SCROLL_MODE_AUTO
	demo_scroll.mouse_filter = Control.MOUSE_FILTER_PASS
	demo_scroll.follow_focus = false
	demo_scroll.scroll_deadzone = 4
	outer.add_child(demo_scroll)

	var box := VBoxContainer.new()
	box.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	box.custom_minimum_size.x = 1
	box.add_theme_constant_override("separation", 10)
	demo_scroll.add_child(box)

	# Painel principal 24h
	var hero := _card(box, "7 CONTAS DEMO • SERVIDOR 24H", green)
	var hero_note := _label(
		"A sessão é executada no servidor. Você pode fechar o app e voltar depois: banca, Gale, WIN/LOSS e histórico continuam sendo processados.",
		16, false
	)
	hero_note.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	hero.add_child(hero_note)

	demo_profit_label = _label("R$ 0,00", 31, true)
	demo_profit_label.add_theme_color_override("font_color", green)
	hero.add_child(demo_profit_label)

	demo_server_info_label = _label("SERVIDOR: aguardando sincronização...", 15, false)
	demo_server_info_label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	hero.add_child(demo_server_info_label)

	# Configuração
	var setup := _card(box, "CONFIGURAÇÃO DA SESSÃO", purple)

	setup.add_child(_label("CONTA DEMO", 16, true))
	demo_account_select = OptionButton.new()
	demo_account_select.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	demo_account_select.custom_minimum_size.y = 58
	for i in range(1, 8):
		demo_account_select.add_item("DEMO %d" % i)
	demo_account_select.select(0)
	demo_account_select.item_selected.connect(_demo_account_changed)
	setup.add_child(demo_account_select)

	setup.add_child(_label("ESTRATÉGIA", 16, true))
	demo_strategy_select = OptionButton.new()
	demo_strategy_select.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	demo_strategy_select.custom_minimum_size.y = 58
	demo_strategy_select.item_selected.connect(_demo_strategy_option_selected)
	setup.add_child(demo_strategy_select)

	var change_strategy := _button("APLICAR / TROCAR ESTRATÉGIA")
	change_strategy.pressed.connect(_demo_change_strategy)
	setup.add_child(change_strategy)

	demo_white_enabled_toggle = CheckButton.new()
	demo_white_enabled_toggle.text = "ESTRATÉGIA DO BRANCO ATIVADA"
	demo_white_enabled_toggle.button_pressed = false
	demo_white_enabled_toggle.toggled.connect(_demo_toggle_white)
	setup.add_child(demo_white_enabled_toggle)

	demo_contrary_signal_toggle = CheckButton.new()
	demo_contrary_signal_toggle.text = "SINAL CONTRÁRIO • INVERTE G0/G1/G2... • VERMELHO ↔ PRETO"
	demo_contrary_signal_toggle.button_pressed = false
	demo_contrary_signal_toggle.toggled.connect(_demo_toggle_contrary_signal)
	setup.add_child(demo_contrary_signal_toggle)

	demo_mirror_toggle = CheckButton.new()
	demo_mirror_toggle.text = "MODO ESPELHO A/B • ORIGINAL VS CONTRÁRIO • MESMAS RODADAS • G0"
	# V3.97: no espelho, BRANCO protegido conta WIN para A e B no placar W/L; o crédito financeiro não é duplicado.
	demo_mirror_toggle.button_pressed = false
	demo_mirror_toggle.toggled.connect(_demo_toggle_mirror)
	setup.add_child(demo_mirror_toggle)

	demo_mirror_label = _label("ESPELHO DESLIGADO\nA = sinal original • B = sinal contrário", 16, true)
	demo_mirror_label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	setup.add_child(demo_mirror_label)

	var bank_row := HBoxContainer.new()
	bank_row.add_theme_constant_override("separation", 8)
	setup.add_child(bank_row)

	var bank_box := VBoxContainer.new()
	bank_box.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	bank_box.add_child(_label("BANCA DEMO R$", 15, true))
	demo_initial_bank_input = SpinBox.new()
	demo_initial_bank_input.min_value = 1.0
	demo_initial_bank_input.max_value = 100000000.0
	demo_initial_bank_input.step = 10.0
	demo_initial_bank_input.value = demo_initial_bank
	demo_initial_bank_input.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	demo_initial_bank_input.custom_minimum_size.y = 58
	bank_box.add_child(demo_initial_bank_input)
	bank_row.add_child(bank_box)

	var entry_box := VBoxContainer.new()
	entry_box.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	entry_box.add_child(_label("ENTRADA R$", 15, true))
	demo_entry_input = SpinBox.new()
	demo_entry_input.min_value = 0.10
	demo_entry_input.max_value = 100000000.0
	demo_entry_input.step = 0.10
	demo_entry_input.value = demo_entry_value
	demo_entry_input.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	demo_entry_input.custom_minimum_size.y = 58
	entry_box.add_child(demo_entry_input)
	bank_row.add_child(entry_box)

	demo_white_protection_toggle = CheckButton.new()
	demo_white_protection_toggle.text = "PROTEGER BRANCO EM TODA ENTRADA"
	demo_white_protection_toggle.toggled.connect(_demo_white_protection_changed)
	setup.add_child(demo_white_protection_toggle)

	var demo_wp_row := HBoxContainer.new()
	setup.add_child(demo_wp_row)
	demo_wp_row.add_child(_label("PROTEÇÃO NO BRANCO R$", 15, true))
	demo_white_protection_stake = SpinBox.new()
	demo_white_protection_stake.min_value = 0.10
	demo_white_protection_stake.max_value = 1000000.0
	demo_white_protection_stake.step = 0.10
	demo_white_protection_stake.value = 1.0
	demo_white_protection_stake.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	demo_white_protection_stake.value_changed.connect(func(_v):
		_demo_white_protection_changed(
			demo_white_protection_toggle != null and demo_white_protection_toggle.button_pressed
		)
	)
	demo_wp_row.add_child(demo_white_protection_stake)

	var buttons := HBoxContainer.new()
	buttons.add_theme_constant_override("separation", 8)
	setup.add_child(buttons)

	var start := _button("▶ INICIAR")
	start.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	start.pressed.connect(_demo_start)
	buttons.add_child(start)

	var stop := _button("■ PARAR")
	stop.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	stop.pressed.connect(_demo_stop)
	buttons.add_child(stop)

	var reset := _button("↻ RESETAR")
	reset.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	reset.pressed.connect(_demo_reset)
	buttons.add_child(reset)

	var sync := _button("ATUALIZAR PAINEL AGORA")
	sync.pressed.connect(_request_demo_status)
	setup.add_child(sync)

	# Operação ao vivo
	var live := _card(box, "OPERAÇÃO ATUAL", purple)
	demo_status_label = _label("-", 18, true)
	demo_status_label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	live.add_child(demo_status_label)

	demo_signal_label = _label("AGUARDANDO SINAL", 25, true)
	demo_signal_label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	live.add_child(demo_signal_label)

	demo_current_operation_label = _label("Nenhuma operação em andamento.", 16, false)
	demo_current_operation_label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	live.add_child(demo_current_operation_label)

	demo_audit_label = _label("AUDITORIA DO SINAL\nAguardando a próxima aposta...", 16, true)
	demo_audit_label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	live.add_child(demo_audit_label)

	# Placar
	var stats := _card(box, "PLACAR 24H", green)
	demo_stats_label = _label("-", 19, false)
	demo_stats_label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	stats.add_child(demo_stats_label)

	demo_rounds_label = _label("RODADAS PROCESSADAS: 0", 17, true)
	demo_rounds_label.add_theme_color_override("font_color", muted)
	stats.add_child(demo_rounds_label)

	# Histórico
	var hist_card := _card(box, "ÚLTIMAS OPERAÇÕES", purple)
	var hist_note := _label(
		"Mostra as operações registradas pelo servidor, inclusive as executadas enquanto o app estava fechado.",
		14, false
	)
	hist_note.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	hist_card.add_child(hist_note)

	demo_history_label = _label("Nenhuma operação.", 16, false)
	demo_history_label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	hist_card.add_child(demo_history_label)

	_refresh_demo_strategy_select()
	_refresh_demo_ui()


func _build_white_page(host: Control) -> void:
	var page := _new_page(host, "white")
	var outer := page.get_child(0) as VBoxContainer

	white_scroll = ScrollContainer.new()
	white_scroll.size_flags_vertical = Control.SIZE_EXPAND_FILL
	white_scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	white_scroll.vertical_scroll_mode = ScrollContainer.SCROLL_MODE_AUTO
	white_scroll.mouse_filter = Control.MOUSE_FILTER_PASS
	white_scroll.follow_focus = false
	white_scroll.scroll_deadzone = 4
	outer.add_child(white_scroll)

	var box := VBoxContainer.new()
	box.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	box.custom_minimum_size.x = 1
	box.add_theme_constant_override("separation", 10)
	white_scroll.add_child(box)

	var hero := _card(box, "BUSCADOR DE BRANCO • 14X", white_color)
	var note := _label(
		"Analisa o histórico do nosso servidor procurando condições que antecederam BRANCO. O retorno padrão está configurado em 14x. Não há garantia de repetição futura.",
		15, false
	)
	note.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	hero.add_child(note)

	white_signal_label = _label("AGUARDANDO ANÁLISE", 27, true)
	white_signal_label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	hero.add_child(white_signal_label)

	var config := _card(box, "CONFIGURAÇÃO", purple)

	var money_row := HBoxContainer.new()
	money_row.add_theme_constant_override("separation", 8)
	config.add_child(money_row)

	var stake_box := VBoxContainer.new()
	stake_box.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	stake_box.add_child(_label("ENTRADA R$", 14, true))
	white_stake_input = SpinBox.new()
	white_stake_input.min_value = 0.10
	white_stake_input.max_value = 100000000.0
	white_stake_input.step = 0.10
	white_stake_input.value = 10.0
	white_stake_input.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	stake_box.add_child(white_stake_input)
	money_row.add_child(stake_box)

	var bank_box := VBoxContainer.new()
	bank_box.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	bank_box.add_child(_label("BANCA R$", 14, true))
	white_bank_input = SpinBox.new()
	white_bank_input.min_value = 1.0
	white_bank_input.max_value = 100000000.0
	white_bank_input.step = 10.0
	white_bank_input.value = 1000.0
	white_bank_input.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	bank_box.add_child(white_bank_input)
	money_row.add_child(bank_box)

	var payout_box := VBoxContainer.new()
	payout_box.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	payout_box.add_child(_label("RETORNO X", 14, true))
	white_payout_input = SpinBox.new()
	white_payout_input.min_value = 1.0
	white_payout_input.max_value = 100.0
	white_payout_input.step = 0.1
	white_payout_input.value = 14.0
	white_payout_input.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	payout_box.add_child(white_payout_input)
	money_row.add_child(payout_box)

	var attempts_box := VBoxContainer.new()
	attempts_box.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	attempts_box.add_child(_label("TENTATIVAS", 14, true))
	white_attempts_input = SpinBox.new()
	white_attempts_input.min_value = 1.0
	white_attempts_input.max_value = 20.0
	white_attempts_input.step = 1.0
	white_attempts_input.value = 6.0
	white_attempts_input.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	attempts_box.add_child(white_attempts_input)
	money_row.add_child(attempts_box)

	var attempts_note := _label("As TENTATIVAS escolhidas aqui fazem parte da estratégia gerada e salva. Na DEMO, esse número não é alterado.", 13, false)
	attempts_note.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	config.add_child(attempts_note)

	var actions := HBoxContainer.new()
	actions.add_theme_constant_override("separation", 8)
	config.add_child(actions)

	var analyze := _button("ANALISAR AGORA")
	analyze.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	analyze.pressed.connect(_refresh_white_page)
	actions.add_child(analyze)

	var generate := _button("GERAR MELHOR")
	generate.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	generate.pressed.connect(_generate_best_white_strategy)
	actions.add_child(generate)

	var save_white := _button("SALVAR ESTRATÉGIA DE BRANCO")
	save_white.pressed.connect(_save_white_strategy)
	config.add_child(save_white)

	var strategy_card := _card(box, "ESTRATÉGIA ATUAL", white_color)
	white_strategy_label = _label("Nenhuma estratégia gerada.", 17, false)
	white_strategy_label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	strategy_card.add_child(white_strategy_label)

	var stats_card := _card(box, "BACKTEST DO BRANCO", green)
	white_stats_label = _label("-", 17, false)
	white_stats_label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	stats_card.add_child(white_stats_label)

	var presets := _card(box, "3 LEITURAS AUTOMÁTICAS", purple)
	white_presets_label = _label("-", 15, false)
	white_presets_label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	presets.add_child(white_presets_label)


func _white_gap_before(index: int) -> int:
	if index <= 0:
		return -1
	var gap: int = 0
	for i in range(index - 1, -1, -1):
		if _round_color(history[i]) == "W":
			return gap
		gap += 1
	return -1


func _white_pattern_before(index: int, length: int) -> Array:
	if index < length or length <= 0:
		return []
	var out: Array = []
	for i in range(index - length, index):
		var c := _round_color(history[i])
		if c not in ["R", "B"]:
			return []
		out.append(c)
	return out


func _white_match(index: int, strategy: Dictionary) -> bool:
	var plen: int = int(strategy.get("pattern_len", 0))
	var pattern_value = strategy.get("pattern", [])
	if plen > 0:
		if not (pattern_value is Array):
			return false
		var got := _white_pattern_before(index, plen)
		if got.size() != plen or got != pattern_value:
			return false

	var gap := _white_gap_before(index)
	var min_gap: int = int(strategy.get("min_gap", 0))
	var max_gap: int = int(strategy.get("max_gap", 999999))
	if gap < 0 or gap < min_gap or gap > max_gap:
		return false

	return true


func _white_backtest(strategy: Dictionary) -> Dictionary:
	var stake: float = float(white_stake_input.value) if white_stake_input != null else 10.0
	var initial_bank: float = float(white_bank_input.value) if white_bank_input != null else 1000.0
	var payout: float = float(white_payout_input.value) if white_payout_input != null else 14.0
	var max_attempts: int = int(white_attempts_input.value) if white_attempts_input != null else 6
	max_attempts = maxi(1, max_attempts)

	var bank: float = initial_bank
	var peak: float = bank
	var min_bank: float = bank
	var max_dd: float = 0.0
	var entries: int = 0
	var wins: int = 0
	var losses: int = 0
	var bets: int = 0
	var total_staked: float = 0.0
	var wins_by_attempt: Array[int] = []
	for _a in range(max_attempts):
		wins_by_attempt.append(0)

	# Uma entrada pode ter várias tentativas consecutivas.
	# WIN/LOSS é contado uma única vez por entrada completa.
	var i: int = 0
	while i < history.size():
		if not _white_match(i, strategy):
			i += 1
			continue

		# Só considera uma entrada fechada no backtest se existirem
		# rodadas suficientes e banca para financiar todas as tentativas.
		if i + max_attempts > history.size():
			break
		if bank < stake * float(max_attempts):
			break

		entries += 1
		var won: bool = false
		var attempts_used: int = 0

		for attempt in range(max_attempts):
			var round_index: int = i + attempt
			# A janela e a banca já foram validadas antes de abrir a entrada.

			bank -= stake
			bets += 1
			total_staked += stake
			attempts_used += 1
			min_bank = minf(min_bank, bank)
			max_dd = maxf(max_dd, peak - bank)

			if _round_color(history[round_index]) == "W":
				wins += 1
				wins_by_attempt[attempt] += 1
				bank += stake * payout
				peak = maxf(peak, bank)
				min_bank = minf(min_bank, bank)
				won = true
				break

		if not won:
			losses += 1

		# Evita abrir outra entrada por cima das rodadas já usadas neste ciclo.
		# Com 6 tentativas perdidas e stake R$10, uma LOSS custa R$60.
		i += maxi(1, attempts_used)

	var rate: float = 100.0 * float(wins) / float(entries) if entries > 0 else 0.0
	return {
		"entries": entries,
		"wins": wins,
		"losses": losses,
		"rate": rate,
		"profit": bank - initial_bank,
		"bank": bank,
		"peak": peak,
		"min_bank": min_bank,
		"max_dd": max_dd,
		"bets": bets,
		"total_staked": total_staked,
		"max_attempts": max_attempts,
		"wins_by_attempt": wins_by_attempt
	}


func _white_backtest_with_config(strategy: Dictionary) -> Dictionary:
	var stake: float = float(strategy.get("stake", 10.0))
	var initial_bank: float = float(strategy.get("initial_bank", 1000.0))
	var payout: float = float(strategy.get("payout", 14.0))
	var max_attempts: int = maxi(1, int(strategy.get("attempts", 6)))

	var bank: float = initial_bank
	var peak: float = bank
	var min_bank: float = bank
	var max_dd: float = 0.0
	var entries: int = 0
	var wins: int = 0
	var losses: int = 0
	var wins_by_attempt: Array[int] = []
	for _a in range(max_attempts):
		wins_by_attempt.append(0)

	var i := 0
	while i < history.size():
		if not _white_match(i, strategy):
			i += 1
			continue
		if i + max_attempts > history.size() or bank < stake * float(max_attempts):
			break
		entries += 1
		var won := false
		var attempts_used := 0
		for attempt in range(max_attempts):
			bank -= stake
			attempts_used += 1
			min_bank = minf(min_bank, bank)
			max_dd = maxf(max_dd, peak - bank)
			if _round_color(history[i + attempt]) == "W":
				wins += 1
				wins_by_attempt[attempt] += 1
				bank += stake * payout
				peak = maxf(peak, bank)
				won = true
				break
		if not won:
			losses += 1
		i += maxi(1, attempts_used)

	return {
		"entries": entries, "wins": wins, "losses": losses,
		"rate": 100.0 * float(wins) / float(entries) if entries > 0 else 0.0,
		"profit": bank - initial_bank, "bank": bank, "peak": peak,
		"min_bank": min_bank, "max_dd": max_dd, "max_attempts": max_attempts,
		"wins_by_attempt": wins_by_attempt
	}


func _white_strategy_score(result: Dictionary) -> float:
	var entries: int = int(result.get("entries", 0))
	if entries < 8:
		return -INF
	var profit: float = float(result.get("profit", -INF))
	var dd: float = float(result.get("max_dd", 0.0))
	# Lucro é o critério principal, mas penaliza drawdown exagerado e amostra minúscula.
	return profit - (0.20 * dd) + minf(100.0, float(entries))


func _generate_best_white_strategy() -> void:
	if history.size() < 100:
		white_strategy_label.text = "Histórico insuficiente. Aguarde pelo menos 100 rodadas."
		return

	var best: Dictionary = {}
	var best_result: Dictionary = {}
	var best_score: float = -INF

	# Janelas de distância desde o último branco.
	var gap_ranges: Array = [
		[0, 6], [7, 12], [13, 18], [19, 24], [25, 30],
		[31, 40], [41, 55], [56, 75], [0, 999999]
	]

	# Sem padrão e padrões R/B de 1 a 4 cores.
	for gap_range in gap_ranges:
		for plen in range(0, 5):
			var pattern_count: int = 1 if plen == 0 else int(pow(2, plen))
			for mask in range(pattern_count):
				var pattern: Array = []
				if plen > 0:
					for pos in range(plen):
						pattern.append("B" if ((mask >> pos) & 1) == 1 else "R")

				var candidate := {
					"pattern_len": plen,
					"pattern": pattern,
					"min_gap": int(gap_range[0]),
					"max_gap": int(gap_range[1])
				}
				var result := _white_backtest(candidate)
				var score := _white_strategy_score(result)
				if score > best_score:
					best_score = score
					best = candidate
					best_result = result

	# A estratégia de branco guarda a configuração usada NO MOMENTO DA GERAÇÃO.
	# A Demo apenas executa o que foi salvo; não altera o número de tentativas.
	best["attempts"] = maxi(1, int(white_attempts_input.value) if white_attempts_input != null else 6)
	best["stake"] = float(white_stake_input.value) if white_stake_input != null else 10.0
	best["initial_bank"] = float(white_bank_input.value) if white_bank_input != null else 1000.0
	best["payout"] = float(white_payout_input.value) if white_payout_input != null else 14.0
	white_best_strategy = best.duplicate(true)
	_render_white_strategy(best, best_result)


func _save_white_strategy() -> void:
	if white_best_strategy.is_empty():
		_generate_best_white_strategy()
	if white_best_strategy.is_empty():
		if white_strategy_label != null:
			white_strategy_label.text = "Não foi possível gerar uma estratégia de branco para salvar."
		return

	if _strategy_already_saved(white_best_strategy):
		if white_signal_label != null:
			white_signal_label.text = (
				"ESSA CONFIGURAÇÃO DE BRANCO JÁ ESTÁ SALVA. "
				+ "Exclua a existente para permitir que seja salva/gerada novamente."
			)
		return

	var saved := white_best_strategy.duplicate(true)
	saved["id"] = "white_%d" % int(Time.get_unix_time_from_system())
	saved["type"] = "white"
	saved["name"] = "⚪ BRANCO • %d-%d • %d tentativas" % [
		int(saved.get("min_gap", 0)),
		int(saved.get("max_gap", 999999)),
		int(saved.get("attempts", 6))
	]
	saved["entry"] = "W"
	saved["stake"] = float(saved.get("stake", 10.0))
	saved["initial_bank"] = float(saved.get("initial_bank", 1000.0))
	saved["payout"] = float(saved.get("payout", 14.0))
	saved["attempts"] = maxi(1, int(saved.get("attempts", 6)))
	# Compatibilidade visual com o placar da Demo: tentativa 1 = índice 0.
	saved["gale"] = int(saved["attempts"]) - 1
	saved["gale_mode"] = 0

	strategies.append(saved)
	_save_strategies()
	_render_saved_strategies()
	_refresh_demo_strategy_select()

	var result := _white_backtest(saved)
	_render_white_strategy(saved, result)
	if white_signal_label != null:
		white_signal_label.text = "✅ ESTRATÉGIA DE BRANCO SALVA • disponível na DEMO"
		white_signal_label.add_theme_color_override("font_color", green)


func _white_pattern_text(strategy: Dictionary) -> String:
	var pv = strategy.get("pattern", [])
	if not (pv is Array) or pv.is_empty():
		return "SEM PADRÃO DE COR"
	var names := PackedStringArray()
	for c in pv:
		names.append(_color_name(str(c)))
	return " → ".join(names)


func _render_white_strategy(strategy: Dictionary, result: Dictionary) -> void:
	if strategy.is_empty():
		white_strategy_label.text = "Nenhuma estratégia válida."
		return

	var min_gap := int(strategy.get("min_gap", 0))
	var max_gap := int(strategy.get("max_gap", 999999))
	var gap_text := "%d a %d rodadas desde o último branco" % [min_gap, max_gap]
	if max_gap >= 999999:
		gap_text = "qualquer distância desde o último branco"

	white_strategy_label.text = (
		"CONDIÇÃO PARA ENTRAR NO BRANCO\n"
		+ "Padrão anterior: %s\n"
		+ "Intervalo: %s\n"
		+ "Entradas históricas: %d • WIN: %d • LOSS: %d\n"
		+ "Até %d tentativas por entrada • LOSS cheia: R$ %.2f\n"
		+ "Acerto: %.2f%% • Lucro simulado: R$ %+.2f"
	) % [
		_white_pattern_text(strategy),
		gap_text,
		int(result.get("entries", 0)),
		int(result.get("wins", 0)),
		int(result.get("losses", 0)),
		int(result.get("max_attempts", 6)),
		(float(white_stake_input.value) if white_stake_input != null else 10.0) * float(result.get("max_attempts", 6)),
		float(result.get("rate", 0.0)),
		float(result.get("profit", 0.0))
	]


func _white_current_signal() -> String:
	if white_best_strategy.is_empty() or history.is_empty():
		return "SEM ESTRATÉGIA • toque em GERAR MELHOR"
	# Próxima rodada = index history.size(); usa o histórico anterior como contexto.
	var fake_index := history.size()
	if _white_match(fake_index, white_best_strategy):
		return "⚪ ENTRAR NO BRANCO NA PRÓXIMA RODADA"
	return "AGUARDAR • condição do branco ainda não apareceu"


func _white_gap_stats() -> Dictionary:
	var gaps: Array[int] = []
	var last_w := -1
	var whites := 0
	for i in range(history.size()):
		if _round_color(history[i]) == "W":
			whites += 1
			if last_w >= 0:
				gaps.append(i - last_w - 1)
			last_w = i
	if gaps.is_empty():
		return {"whites": whites, "avg": 0.0, "min": 0, "max": 0}
	var total := 0
	var mn := gaps[0]
	var mx := gaps[0]
	for g in gaps:
		total += g
		mn = mini(mn, g)
		mx = maxi(mx, g)
	return {
		"whites": whites,
		"avg": float(total) / float(gaps.size()),
		"min": mn,
		"max": mx
	}


func _white_preset_result(min_gap: int, max_gap: int) -> String:
	var s := {"pattern_len": 0, "pattern": [], "min_gap": min_gap, "max_gap": max_gap}
	var r := _white_backtest(s)
	return "%d-%d após branco • %d entradas • %.2f%% • R$ %+.2f" % [
		min_gap, max_gap,
		int(r.get("entries", 0)),
		float(r.get("rate", 0.0)),
		float(r.get("profit", 0.0))
	]


func _refresh_white_page() -> void:
	if white_signal_label == null:
		return

	var gap_stats := _white_gap_stats()
	var payout: float = float(white_payout_input.value) if white_payout_input != null else 14.0
	var break_even: float = 100.0 / payout if payout > 0.0 else 0.0

	white_signal_label.text = _white_current_signal()
	white_signal_label.add_theme_color_override(
		"font_color",
		white_color if white_signal_label.text.begins_with("⚪") else muted
	)

	var current_result: Dictionary = {}
	if not white_best_strategy.is_empty():
		current_result = _white_backtest(white_best_strategy)
		_render_white_strategy(white_best_strategy, current_result)

	white_stats_label.text = (
		"BRANCOS NA BASE: %d\n"
		+ "Intervalo médio entre brancos: %.2f rodadas\n"
		+ "Menor intervalo: %d • Maior intervalo: %d\n"
		+ "Retorno configurado: %.2fx • Tentativas: %d\n"
		+ "LOSS completa: R$ %.2f\n"
		+ "Taxa de equilíbrio teórica (1 tentativa): %.2f%%\n\n"
		+ "MELHOR ATUAL\n"
		+ "Entradas: %d • WIN %d • LOSS %d\n"
		+ "Acerto: %.2f%%\n"
		+ "Banca final: R$ %.2f\n"
		+ "Lucro/prejuízo: R$ %+.2f\n"
		+ "Drawdown máximo: R$ %.2f"
	) % [
		int(gap_stats.get("whites", 0)),
		float(gap_stats.get("avg", 0.0)),
		int(gap_stats.get("min", 0)),
		int(gap_stats.get("max", 0)),
		payout,
		int(white_attempts_input.value) if white_attempts_input != null else 6,
		(float(white_stake_input.value) if white_stake_input != null else 10.0) * float(int(white_attempts_input.value) if white_attempts_input != null else 6),
		break_even,
		int(current_result.get("entries", 0)),
		int(current_result.get("wins", 0)),
		int(current_result.get("losses", 0)),
		float(current_result.get("rate", 0.0)),
		float(current_result.get("bank", float(white_bank_input.value) if white_bank_input != null else 1000.0)),
		float(current_result.get("profit", 0.0)),
		float(current_result.get("max_dd", 0.0))
	]

	white_presets_label.text = (
		"CURTO: %s\n\n"
		+ "MÉDIO: %s\n\n"
		+ "LONGO: %s"
	) % [
		_white_preset_result(7, 15),
		_white_preset_result(16, 30),
		_white_preset_result(31, 60)
	]


func _new_page(host: Control, key: String) -> Control:
	var page := MarginContainer.new()
	page.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	page.add_theme_constant_override("margin_top", 2)
	host.add_child(page)
	pages[key] = page

	var box := VBoxContainer.new()
	box.add_theme_constant_override("separation", 10)
	page.add_child(box)
	return page


func _show_page(key: String) -> void:
	current_page = key
	for k in pages.keys():
		(pages[k] as Control).visible = str(k) == key
	_refresh_nav()
	if key == "saved":
		_render_saved_strategies()
	if key == "demo":
		_refresh_demo_strategy_select()
		_refresh_demo_ui()
		_request_demo_status()
	if key == "white":
		_refresh_white_page()


func _refresh_nav() -> void:
	_set_nav(nav_history, current_page == "history")
	_set_nav(nav_sim, current_page == "simulator")
	_set_nav(nav_optimizer, current_page == "optimizer")
	_set_nav(nav_balance, current_page == "balance")
	_set_nav(nav_saved, current_page == "saved")
	_set_nav(nav_demo, current_page == "demo")
	_set_nav(nav_white, current_page == "white")


func _nav_button(caption: String) -> Button:
	var b := _button(caption)
	b.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	b.custom_minimum_size.x = 92
	b.add_theme_font_size_override("font_size", 14)
	return b


func _set_nav(b: Button, active: bool) -> void:
	if b == null:
		return
	b.add_theme_color_override("font_color", green if active else muted)
	b.add_theme_stylebox_override(
		"normal",
		_button_style(Color("#10251F") if active else surface_2, green if active else border)
	)


func _input(event: InputEvent) -> void:
	# Rolagem mobile robusta: funciona mesmo quando o dedo começa em cima de
	# botões, LineEdit, OptionButton ou cards.
	if event is InputEventScreenTouch:
		var touch := event as InputEventScreenTouch
		touch_scrolling = touch.pressed
		return

	if event is InputEventScreenDrag:
		var drag := event as InputEventScreenDrag
		var target := _active_scroll_container()
		if target != null:
			var amount: int = int(-drag.relative.y * 1.25)
			target.scroll_vertical = maxi(0, target.scroll_vertical + amount)
			get_viewport().set_input_as_handled()
		return

	# Também mantém roda do mouse funcionando no editor/PC.
	if event is InputEventMouseButton:
		var mouse := event as InputEventMouseButton
		if mouse.pressed:
			var target := _active_scroll_container()
			if target != null:
				if mouse.button_index == MOUSE_BUTTON_WHEEL_DOWN:
					target.scroll_vertical += 85
					get_viewport().set_input_as_handled()
				elif mouse.button_index == MOUSE_BUTTON_WHEEL_UP:
					target.scroll_vertical = maxi(0, target.scroll_vertical - 85)
					get_viewport().set_input_as_handled()


func _active_scroll_container() -> ScrollContainer:
	match current_page:
		"history":
			return history_scroll
		"simulator":
			return simulator_scroll
		"optimizer":
			return optimizer_scroll
		"balance":
			return balance_scroll
		"saved":
			return saved_scroll
		"demo":
			return demo_scroll
		"white":
			return white_scroll
	return null


func _build_network() -> void:
	http_history = HTTPRequest.new()
	http_history.timeout = 15.0
	http_history.request_completed.connect(_on_history_completed)
	add_child(http_history)

	http_status = HTTPRequest.new()
	http_status.timeout = 15.0
	http_status.request_completed.connect(_on_status_completed)
	add_child(http_status)

	http_demo_status = HTTPRequest.new()
	http_demo_status.timeout = 15.0
	http_demo_status.request_completed.connect(_on_demo_status_completed)
	add_child(http_demo_status)

	http_demo_command = HTTPRequest.new()
	http_demo_command.timeout = 15.0
	http_demo_command.request_completed.connect(_on_demo_command_completed)
	add_child(http_demo_command)

	http_optimizer_start = HTTPRequest.new()
	add_child(http_optimizer_start)
	http_optimizer_start.timeout = 30.0
	http_optimizer_start.request_completed.connect(_on_optimizer_remote_start_completed)

	http_optimizer_status = HTTPRequest.new()
	add_child(http_optimizer_status)
	http_optimizer_status.timeout = 30.0
	http_optimizer_status.request_completed.connect(_on_optimizer_remote_status_completed)

	optimizer_poll_timer = Timer.new()
	optimizer_poll_timer.wait_time = 0.5
	optimizer_poll_timer.one_shot = false
	optimizer_poll_timer.timeout.connect(_poll_optimizer_remote)
	add_child(optimizer_poll_timer)

	refresh_timer = Timer.new()
	refresh_timer.wait_time = REFRESH_SECONDS
	refresh_timer.one_shot = false
	refresh_timer.timeout.connect(_request_all)
	add_child(refresh_timer)
	refresh_timer.start()

	demo_refresh_timer = Timer.new()
	demo_refresh_timer.wait_time = 2.0
	demo_refresh_timer.one_shot = false
	demo_refresh_timer.timeout.connect(func():
		if current_page == "demo":
			_request_demo_status()
	)
	add_child(demo_refresh_timer)
	demo_refresh_timer.start()


func _request_all() -> void:
	if not history_busy:
		history_busy = true
		var err := http_history.request(HISTORY_URL)
		if err != OK:
			history_busy = false
			_set_offline("Falha ao iniciar histórico")

	if not status_busy:
		status_busy = true
		var err2 := http_status.request(STATUS_URL)
		if err2 != OK:
			status_busy = false

	if current_page == "demo":
		_request_demo_status()


func _on_history_completed(result: int, response_code: int, _headers: PackedStringArray, body: PackedByteArray) -> void:
	history_busy = false
	if result != HTTPRequest.RESULT_SUCCESS or response_code < 200 or response_code >= 300:
		_set_offline("Histórico indisponível")
		return

	var parsed = JSON.parse_string(body.get_string_from_utf8())
	if not (parsed is Dictionary):
		_set_offline("Resposta inválida")
		return

	var d: Dictionary = parsed
	var rows = d.get("rodadas", [])
	if not (rows is Array):
		_set_offline("Histórico inválido")
		return

	history = rows.duplicate(true)
	history_raw_total = int(d.get("quantidade", history.size()))
	history_gap_count = 0
	history_validation_mode = "historico_servidor_atual"
	visible_count = mini(maxi(visible_count, PAGE_SIZE), history.size())
	updated_label.text = str(d.get("ultima_atualizacao", "-"))
	count_label.text = "%d / 30000" % history.size()
	if continuity_label != null:
		continuity_label.text = "HISTÓRICO DO SERVIDOR • " + str(history.size()) + "/30000"
		continuity_label.add_theme_color_override("font_color", green)
	status_label.text = "ONLINE • HISTÓRICO CARREGADO"
	status_label.add_theme_color_override("font_color", green)
	if current_page == "demo":
		_request_demo_status()
	if current_page == "white":
		_refresh_white_page()
	_render_history()


func _on_status_completed(result: int, response_code: int, _headers: PackedStringArray, body: PackedByteArray) -> void:
	status_busy = false
	if result != HTTPRequest.RESULT_SUCCESS or response_code < 200 or response_code >= 300:
		return

	var parsed = JSON.parse_string(body.get_string_from_utf8())
	if not (parsed is Dictionary):
		return

	var d: Dictionary = parsed
	var total := int(d.get("rodadas", history.size()))
	count_label.text = "%d / 30000" % history.size()
	if history.size() > 0:
		if history_gap_count > 0:
			status_label.text = "ONLINE • HISTÓRICO VALIDADO • %d LACUNAS ISOLADAS" % history_gap_count
			status_label.add_theme_color_override("font_color", purple)
		else:
			status_label.text = "ONLINE • HISTÓRICO CONTÍNUO"
			status_label.add_theme_color_override("font_color", green)
	elif bool(d.get("fonte_online", false)):
		status_label.text = "ONLINE • CAPTURA ATIVA"
		status_label.add_theme_color_override("font_color", green)
	else:
		status_label.text = "SERVIDOR ONLINE • FONTE VERIFICANDO"
		status_label.add_theme_color_override("font_color", muted)


func _apply_current_risk_to_strategy(strategy: Dictionary) -> void:
	strategy["risk_trailing_enabled"] = risk_trailing_enabled.button_pressed
	strategy["risk_trailing_pct"] = float(risk_trailing_pct.value)
	strategy["risk_capital_enabled"] = risk_capital_enabled.button_pressed
	strategy["risk_capital_floor"] = float(risk_capital_floor.value)
	strategy["risk_performance_enabled"] = risk_performance_enabled.button_pressed
	strategy["risk_performance_window"] = int(risk_performance_window.value)
	strategy["risk_performance_min_rate"] = float(risk_performance_min_rate.value)
	strategy["white_protection_enabled"] = (
		strategy_white_protection_enabled != null
		and strategy_white_protection_enabled.button_pressed
	)
	strategy["white_protection_stake"] = (
		float(strategy_white_protection_stake.value)
		if strategy_white_protection_stake != null else 1.0
	)
	strategy["white_protection_payout"] = 14.0


func _base_candidate_library(gale: int, gale_mode: int) -> Array:
	var candidates: Array = []
	var symbols: Array[String] = ["R", "B"]

	for plen in range(1, 13):
		var total_patterns: int = int(pow(2, plen))
		for mask in range(total_patterns):
			var pattern: Array = []
			for pos in range(plen):
				pattern.append(symbols[(mask >> pos) & 1])

			for target in symbols:
				var candidate: Dictionary = {
					"type": "single",
					"name": "AUTO • %s → %s" % [",".join(pattern), target],
					"pattern": pattern.duplicate(),
					"entry": target,
					"gale": gale,
					"gale_mode": gale_mode,
					"stake": float(strategy_stake.value),
					"initial_bank": float(strategy_bank.value)
				}
				_apply_current_risk_to_strategy(candidate)
				if _strategy_is_blocked_for_generation(candidate):
					continue
				var result: Dictionary = _simulate_strategy(candidate)
				var entries: int = int(result.get("entries", 0))
				if entries < 5:
					continue
				candidate["_profit"] = float(result.get("profit", -INF))
				candidate["_rate"] = float(result.get("rate", 0.0))
				candidate["_entries"] = entries
				candidates.append(candidate)

	candidates.sort_custom(func(a: Dictionary, b: Dictionary) -> bool:
		var pa: float = float(a.get("_profit", -INF))
		var pb: float = float(b.get("_profit", -INF))
		if is_equal_approx(pa, pb):
			return float(a.get("_rate", 0.0)) > float(b.get("_rate", 0.0))
		return pa > pb
	)
	return candidates


func _load_pregenerated_base_strategies() -> Array:
	if not _pregenerated_base_strategies.is_empty():
		return _pregenerated_base_strategies

	if not FileAccess.file_exists(PREGENERATED_STRATEGIES_PATH):
		return []

	var f := FileAccess.open(PREGENERATED_STRATEGIES_PATH, FileAccess.READ)
	if f == null:
		return []

	var parsed = JSON.parse_string(f.get_as_text())
	if not (parsed is Dictionary):
		return []

	var raw = parsed.get("strategies", [])
	if not (raw is Array):
		return []

	_pregenerated_base_strategies = raw
	return _pregenerated_base_strategies


func _base_candidate_library_async(gale: int, gale_mode: int) -> Array:
	var candidates: Array = []
	var base: Array = _load_pregenerated_base_strategies()
	var preparation_total: int = base.size()

	optimizer_result.text = (
		"BASE PRÉ-GERADA CARREGADA\n"
		+ "%d estratégias prontas no armazenamento.\n" % preparation_total
		+ "AVALIANDO NO HISTÓRICO ATUAL: 0 / %d\n" % preparation_total
		+ "GALE: %s • MODO: %s" % [
			"SEM GALE" if gale == 0 else "G%d" % gale,
			_gale_mode_name(gale_mode)
		]
	)
	await get_tree().process_frame

	if preparation_total == 0:
		optimizer_result.text = "ERRO: base pré-gerada não encontrada."
		return candidates

	var processed: int = 0
	for raw in base:
		if not (raw is Dictionary):
			continue
		var definition: Dictionary = raw
		var candidate := {
			"type": "single",
			"name": "AUTO %s → %s" % [
				",".join(definition.get("pattern", [])),
				str(definition.get("entry", ""))
			],
			"pattern": definition.get("pattern", []).duplicate(),
			"entry": str(definition.get("entry", "")),
			"gale": gale,
			"gale_mode": gale_mode,
			"stake": float(strategy_stake.value),
			"initial_bank": float(strategy_bank.value)
		}
		_apply_current_risk_to_strategy(candidate)

		if not _strategy_is_blocked_for_generation(candidate):
			var result: Dictionary = _simulate_strategy(candidate)
			var entries: int = int(result.get("entries", 0))
			if entries >= 5:
				candidate["_profit"] = float(result.get("profit", -INF))
				candidate["_rate"] = float(result.get("rate", 0.0))
				candidate["_entries"] = entries
				candidate["_signal_cache"] = _optimizer_component_signal_cache(candidate)
				candidates.append(candidate)

		processed += 1
		if processed % 20 == 0 or processed == preparation_total:
			optimizer_result.text = (
				"BASE PRÉ-GERADA: %d estratégias prontas\n" % preparation_total
				+ "AVALIANDO NO HISTÓRICO ATUAL: %d / %d\n" % [processed, preparation_total]
				+ "VÁLIDAS ATÉ AGORA: %d\n" % candidates.size()
				+ "As estratégias não estão sendo geradas agora; apenas avaliadas nas rodadas atuais."
			)
			await get_tree().process_frame

	# V3.59: o congelamento em 2044/2044 acontecia justamente na ordenação
	# síncrona imediatamente depois da última atualização da tela.
	# Faz a MESMA ordenação exata por merge sort incremental, cedendo frames
	# ao Android entre os blocos. Nenhuma estratégia é removida.
	optimizer_result.text = (
		"BASE AVALIADA: %d / %d\n" % [processed, preparation_total]
		+ "VÁLIDAS: %d\n" % candidates.size()
		+ "ORDENANDO ESTRATÉGIAS: 0%%"
	)
	await get_tree().process_frame

	var width: int = 1
	var n_candidates: int = candidates.size()
	while width < n_candidates:
		var merged: Array = []
		merged.resize(n_candidates)
		var left: int = 0
		while left < n_candidates:
			var mid: int = mini(left + width, n_candidates)
			var right: int = mini(left + width * 2, n_candidates)
			var i: int = left
			var j: int = mid
			var k: int = left
			while i < mid and j < right:
				var a: Dictionary = candidates[i]
				var b: Dictionary = candidates[j]
				var pa: float = float(a.get("_profit", -INF))
				var pb: float = float(b.get("_profit", -INF))
				var a_first: bool = pa > pb
				if is_equal_approx(pa, pb):
					a_first = float(a.get("_rate", 0.0)) >= float(b.get("_rate", 0.0))
				if a_first:
					merged[k] = a
					i += 1
				else:
					merged[k] = b
					j += 1
				k += 1
			while i < mid:
				merged[k] = candidates[i]
				i += 1
				k += 1
			while j < right:
				merged[k] = candidates[j]
				j += 1
				k += 1
			left += width * 2
		candidates = merged
		width *= 2
		var pct: int = mini(99, int(100.0 * float(width) / float(maxi(1, n_candidates))))
		optimizer_result.text = (
			"BASE AVALIADA: %d / %d\n" % [processed, preparation_total]
			+ "VÁLIDAS: %d\n" % candidates.size()
			+ "ORDENANDO ESTRATÉGIAS: %d%%\n" % pct
			+ "Busca exata preservada."
		)
		await get_tree().process_frame

	optimizer_result.text = (
		"BASE AVALIADA: %d / %d\n" % [processed, preparation_total]
		+ "VÁLIDAS: %d\n" % candidates.size()
		+ "ORDENANDO ESTRATÉGIAS: 100%%\n"
		+ "INICIANDO VARREDURA DAS CONFIGURAÇÕES..."
	)
	await get_tree().process_frame
	return candidates

func _build_ensemble_from_ranked(candidates: Array, count: int, gale: int, gale_mode: int, consensus_pct: int = 50) -> Dictionary:
	var take: int = mini(count, candidates.size())
	if take <= 0:
		return {}

	var selected: Array = []
	for i in range(take):
		var clean: Dictionary = (candidates[i] as Dictionary).duplicate(true)
		clean.erase("_profit")
		clean.erase("_rate")
		clean.erase("_entries")
		clean.erase("_signal_cache")
		selected.append(clean)

	if take == 1:
		var single: Dictionary = (selected[0] as Dictionary).duplicate(true)
		single["name"] = "AUTO • 1 ESTRATÉGIA • %s • %s" % [
			"SEM GALE" if gale == 0 else "G%d" % gale,
			_gale_mode_name(gale_mode)
		]
		return single

	var ensemble: Dictionary = {
		"type": "ensemble",
		"name": "AUTO • %d ESTRATÉGIAS • %s • %s" % [
			take,
			"SEM GALE" if gale == 0 else "G%d" % gale,
			_gale_mode_name(gale_mode)
		],
		"components": selected,
		"gale": gale,
		"gale_mode": gale_mode,
		"consensus_pct": consensus_pct,
		"stake": float(strategy_stake.value),
		"initial_bank": float(strategy_bank.value)
	}
	_apply_current_risk_to_strategy(ensemble)
	return ensemble


func _opposite_rb(code: String) -> String:
	if code == "R":
		return "B"
	if code == "B":
		return "R"
	return code


func _invert_signal_cache_rb(source: PackedByteArray) -> PackedByteArray:
	var out := source.duplicate()
	for i in range(out.size()):
		if int(out[i]) == 1:
			out[i] = 2
		elif int(out[i]) == 2:
			out[i] = 1
	return out


func _materialize_contrarian_strategy(strategy: Dictionary, enabled: bool) -> Dictionary:
	var out: Dictionary = strategy.duplicate(true)
	if not enabled:
		out["contrarian"] = false
		return out

	out["contrarian"] = true
	var stype: String = str(out.get("type", "single"))

	if stype == "ensemble":
		var comps = out.get("components", [])
		if comps is Array:
			var inverted: Array = []
			for item in comps:
				if item is Dictionary:
					var c: Dictionary = (item as Dictionary).duplicate(true)
					var e: String = str(c.get("entry", ""))
					if e == "R" or e == "B":
						c["source_entry"] = e
						c["entry"] = _opposite_rb(e)
					c["contrarian_component"] = true
					inverted.append(c)
			out["components"] = inverted
	else:
		var current_entry: String = str(out.get("entry", ""))
		if current_entry == "R" or current_entry == "B":
			out["source_entry"] = current_entry
			out["entry"] = _opposite_rb(current_entry)

	if not str(out.get("name", "")).begins_with("CONTRÁRIA • "):
		out["name"] = "CONTRÁRIA • " + str(out.get("name", "ESTRATÉGIA"))
	return out


func _optimizer_component_signal_cache(component: Dictionary) -> PackedByteArray:
	var out := PackedByteArray()
	out.resize(history.size())
	var pv = component.get("pattern", [])
	if not (pv is Array):
		return out
	var pattern: Array = pv
	var target: String = str(component.get("entry", ""))
	var code: int = 1 if target == "R" else 2 if target == "B" else 0
	if code == 0:
		return out
	for i in range(pattern.size(), history.size()):
		if _pattern_matches(i - pattern.size(), pattern):
			out[i] = code
	return out


func _optimizer_signal_from_votes(votes_r: PackedByteArray, votes_b: PackedByteArray, consensus_pct: int) -> PackedByteArray:
	var out := PackedByteArray()
	var n: int = mini(votes_r.size(), votes_b.size())
	out.resize(n)
	var required: float = 50.0001 if consensus_pct <= 50 else float(consensus_pct)
	for i in range(n):
		var vr: int = int(votes_r[i])
		var vb: int = int(votes_b[i])
		var active: int = vr + vb
		if active <= 0 or vr == vb:
			continue
		var winner: int = maxi(vr, vb)
		var pct: float = 100.0 * float(winner) / float(active)
		if pct + 0.0001 >= required:
			out[i] = 1 if vr > vb else 2
	return out


func _optimizer_signal_hash(signal_cache: PackedByteArray) -> int:
	return hash(signal_cache)


func _optimizer_count_values(max_count: int, requested_start: int, requested_end: int, fast_mode: bool) -> Array[int]:
	var out: Array[int] = []
	if max_count <= 0:
		return out

	# Quantidade escolhida = testar normalmente de 1 até o valor selecionado.
	# Ex.: ATÉ 100 testa 1, 2, 3 ... 100, sem reduzir para uma única quantidade.
	if requested_end == requested_start + 1 and requested_start >= 1:
		var limit: int = mini(requested_start, max_count)
		for n in range(1, limit + 1):
			out.append(n)
		return out

	if not fast_mode:
		for n in range(1, max_count + 1):
			out.append(n)
		return out

	# Modo rápido: amostragem ampla + refino.
	# É APROXIMADO e pode perder alguma configuração; por isso nunca é padrão.
	var seeds: Array[int] = [
		1,2,3,4,5,6,8,10,12,15,20,25,30,40,50,60,75,100,
		125,150,200,250,300,400,500,600,750,1000
	]
	for n in seeds:
		if n <= max_count and not out.has(n):
			out.append(n)
	out.sort()
	return out


func _optimizer_yield_every(fast_mode: bool) -> int:
	# V3.58: devolve controle ao Android com frequência.
	# Isto NÃO reduz o espaço de busca nem pula configurações.
	return 50


func _optimizer_blocked_signatures() -> Array:
	# V3.89: TODA configuração que ainda existe em SALVAS é enviada ao servidor
	# como inelegível. Ao excluir de SALVAS, deixa automaticamente de ser enviada.
	var out: Array = []
	var seen: Dictionary = {}
	for item in strategies:
		if item is Dictionary:
			var sig := _strategy_logic_signature(item as Dictionary)
			if sig != "" and not seen.has(sig):
				seen[sig] = true
				out.append(sig)
	return out


func _generate_full_optimization() -> void:
	if auto_optimizing:
		return
	if http_optimizer_start == null:
		optimizer_result.text = "Otimizador remoto não inicializado."
		return
	if http_optimizer_start.get_http_client_status() != HTTPClient.STATUS_DISCONNECTED:
		return

	auto_optimizing = true
	optimizer_remote_job_id = ""
	if auto_generate_button != null:
		auto_generate_button.disabled = true
		auto_generate_button.text = "ENVIANDO PARA O SERVIDOR..."

	var gale_value: int = -1
	if auto_search_gale != null and auto_search_gale.selected > 0:
		gale_value = auto_search_gale.selected - 1

	var mode_value: int = -1
	if auto_gale_mode != null and auto_gale_mode.selected > 0:
		mode_value = auto_gale_mode.get_item_id(auto_gale_mode.selected)

	var max_count_value: int = 3000
	if auto_strategy_count != null and auto_strategy_count.selected > 0:
		max_count_value = auto_strategy_count.get_item_id(auto_strategy_count.selected)

	var consensus_value: int = -1
	if auto_consensus != null and auto_consensus.selected > 0:
		consensus_value = auto_consensus.get_item_id(auto_consensus.selected)

	var payload := {
		"gale": gale_value,
		"gale_mode": mode_value,
		"max_count": max_count_value,
		"consensus": consensus_value,
		"contrarian": auto_contrarian != null and auto_contrarian.button_pressed,
		"min_rate_enabled": auto_min_rate_enabled != null and auto_min_rate_enabled.button_pressed,
		"min_rate": float(auto_min_rate.value) if auto_min_rate != null else 0.0,
		"rate_mode": ("max" if auto_rate_mode != null and auto_rate_mode.get_item_id(auto_rate_mode.selected) == 1 else "min"),
		"objective": ("loss" if auto_objective_mode != null and auto_objective_mode.get_item_id(auto_objective_mode.selected) == 1 else "profit"),
		"min_entries_enabled": auto_min_entries_enabled != null and auto_min_entries_enabled.button_pressed,
		"min_entries": int(auto_min_entries.value) if auto_min_entries != null else 0,
		"min_signal_pct_enabled": auto_min_signal_pct_enabled != null and auto_min_signal_pct_enabled.button_pressed,
		"min_signal_pct": float(auto_min_signal_pct.value) if auto_min_signal_pct != null else 0.0,
		"dd_enabled": auto_dd_limit_enabled != null and auto_dd_limit_enabled.button_pressed,
		"dd_limit": float(auto_dd_limit.value) if auto_dd_limit != null else 0.0,
		"blocked_signatures": _optimizer_blocked_signatures(),
		"config": {
			"stake": float(strategy_stake.value),
			"initial_bank": float(strategy_bank.value),
			"risk_trailing_enabled": risk_trailing_enabled.button_pressed,
			"risk_trailing_pct": float(risk_trailing_pct.value),
			"risk_capital_enabled": risk_capital_enabled.button_pressed,
			"risk_capital_floor": float(risk_capital_floor.value),
			"risk_performance_enabled": risk_performance_enabled.button_pressed,
			"risk_performance_window": int(risk_performance_window.value),
			"risk_performance_min_rate": float(risk_performance_min_rate.value),
			"white_protection_enabled": (
				auto_white_protection_enabled != null
				and auto_white_protection_enabled.button_pressed
			),
			"white_protection_stake": (
				float(auto_white_protection_stake.value)
				if auto_white_protection_stake != null else 1.0
			),
			"white_protection_payout": 14.0
		}
	}

	optimizer_result.text = (
		"OTIMIZADOR NO SERVIDOR\n\n"
		+ "Enviando filtros para o Python/Railway...\n"
		+ "O celular fica livre enquanto o servidor faz a busca exata."
	)
	var headers := PackedStringArray(["Content-Type: application/json"])
	var err := http_optimizer_start.request(
		SERVER_BASE + "/optimizer/start", headers, HTTPClient.METHOD_POST, JSON.stringify(payload)
	)
	if err != OK:
		_finish_optimizer_remote_error("Falha ao iniciar otimização remota (%s)." % err)


func _on_optimizer_remote_start_completed(result: int, response_code: int, _headers: PackedStringArray, body: PackedByteArray) -> void:
	if result != HTTPRequest.RESULT_SUCCESS or response_code < 200 or response_code >= 300:
		_finish_optimizer_remote_error("Servidor não iniciou o otimizador (%d)." % response_code)
		return
	var parsed = JSON.parse_string(body.get_string_from_utf8())
	if not (parsed is Dictionary):
		_finish_optimizer_remote_error("Resposta inválida ao iniciar otimização.")
		return
	optimizer_remote_job_id = str((parsed as Dictionary).get("job_id", ""))
	if optimizer_remote_job_id == "":
		_finish_optimizer_remote_error("Servidor não retornou o ID da otimização.")
		return
	optimizer_result.text = "OTIMIZADOR NO SERVIDOR\n\nJob iniciado: %s\nAguardando progresso..." % optimizer_remote_job_id
	optimizer_poll_timer.start()
	_poll_optimizer_remote()


func _poll_optimizer_remote() -> void:
	if optimizer_remote_job_id == "" or http_optimizer_status == null:
		return
	if http_optimizer_status.get_http_client_status() != HTTPClient.STATUS_DISCONNECTED:
		return
	http_optimizer_status.request(SERVER_BASE + "/optimizer/status?job_id=" + optimizer_remote_job_id)


func _on_optimizer_remote_status_completed(result: int, response_code: int, _headers: PackedStringArray, body: PackedByteArray) -> void:
	if result != HTTPRequest.RESULT_SUCCESS or response_code < 200 or response_code >= 300:
		return # mantém polling; uma falha de rede temporária não cancela o job
	var parsed = JSON.parse_string(body.get_string_from_utf8())
	if not (parsed is Dictionary):
		return
	var d: Dictionary = parsed
	var status: String = str(d.get("status", ""))
	var phase: String = str(d.get("phase", "PROCESSANDO"))
	var tested: int = int(d.get("tested", 0))
	var total: int = int(d.get("total", 0))
	var best_profit: float = float(d.get("best_profit", 0.0))
	var objective_loss: bool = auto_objective_mode != null and auto_objective_mode.get_item_id(auto_objective_mode.selected) == 1

	if status == "error":
		_finish_optimizer_remote_error("Erro no servidor: " + str(d.get("error", "desconhecido")))
		return

	if status != "done":
		optimizer_result.text = (
			"OTIMIZADOR NO SERVIDOR • BUSCA EXATA\n\n"
			+ "FASE: %s\n" % phase
			+ ("CONFIGURAÇÕES: %d / %d\n" % [tested, total] if total > 0 else "Preparando...\n")
			+ ("%s ATÉ AGORA: R$ %+.2f\n" % [("MAIOR PREJUÍZO" if objective_loss else "MELHOR"), best_profit])
			+ "O cálculo está rodando no Python/Railway, não no celular."
		)
		return

	# V3.75: nunca apresenta uma busca como completa se o servidor
	# ainda não contabilizou todas as configurações previstas.
	if total > 0 and tested < total:
		optimizer_result.text = (
			"OTIMIZADOR • RESULTADO AINDA INCOMPLETO\n\n"
			+ "CONFIGURAÇÕES: %d / %d\n" % [tested, total]
			+ "Aguardando o servidor finalizar 100%% da busca..."
		)
		return

	optimizer_poll_timer.stop()
	var result_value = d.get("result", {})
	if not (result_value is Dictionary):
		_finish_optimizer_remote_error("Servidor concluiu sem resultado válido.")
		return
	var rr: Dictionary = result_value
	if not bool(rr.get("ok", false)):
		_finish_optimizer_remote_error(str(rr.get("message", "Nenhuma configuração válida.")))
		return

	var strategy_value = rr.get("strategy", {})
	var stats_value = rr.get("result", {})
	if not (strategy_value is Dictionary) or not (stats_value is Dictionary):
		_finish_optimizer_remote_error("Resultado remoto incompleto.")
		return

	var remote_candidate: Dictionary = (strategy_value as Dictionary).duplicate(true)
	if _strategy_already_saved(remote_candidate):
		generated_strategy.clear()
		auto_optimizing = false
		optimizer_remote_job_id = ""
		if optimizer_poll_timer != null:
			optimizer_poll_timer.stop()
		if auto_generate_button != null:
			auto_generate_button.disabled = false
			auto_generate_button.text = "ENCONTRAR A MELHOR"
		optimizer_result.text = (
			"CONFIGURAÇÃO REPETIDA BLOQUEADA\n\n"
			+ "Esta configuração já está em SALVAS e foi recusada pelo app. "
			+ "Na V58.20 o servidor deve pular as salvas e retornar a próxima melhor.\n\n"
			+ "Se isso aparecer após atualizar o servidor, me envie o print."
		)
		return

	generated_strategy = remote_candidate
	var stats: Dictionary = (stats_value as Dictionary).duplicate(true)
	auto_optimizing = false
	optimizer_remote_job_id = ""
	if auto_generate_button != null:
		auto_generate_button.disabled = false
		auto_generate_button.text = "ENCONTRAR A MELHOR"

	optimizer_result.text = (
		"OTIMIZAÇÃO REMOTA CONCLUÍDA\n\n"
		+ "CONFIGURAÇÕES TESTADAS: %d / %d\n" % [int(rr.get("tested", 0)), int(rr.get("total", 0))]
		+ "HISTÓRICO: %d rodadas\n" % int(rr.get("history_count", 0))
		+ (
			"PROTEÇÃO BRANCO: ATIVA • R$ %.2f por entrada • pagamento 14x\n"
			% float(generated_strategy.get("white_protection_stake", 1.0))
			if bool(generated_strategy.get("white_protection_enabled", false))
			else "PROTEÇÃO BRANCO: DESATIVADA\n"
		)
		+ "TEMPO NO SERVIDOR: %.1f s\n" % float(rr.get("elapsed", 0.0))
		+ ("CACHE: RESULTADO REUTILIZADO\n" if bool(rr.get("cached", false)) else "CACHE: RESULTADO SALVO PARA REPETIÇÕES\n")
		+ "\n" + _result_text(generated_strategy, stats)
	)


func _finish_optimizer_remote_error(message: String) -> void:
	if optimizer_poll_timer != null:
		optimizer_poll_timer.stop()
	auto_optimizing = false
	optimizer_remote_job_id = ""
	if auto_generate_button != null:
		auto_generate_button.disabled = false
		auto_generate_button.text = "ENCONTRAR A MELHOR"
	optimizer_result.text = "OTIMIZADOR REMOTO\n\n" + message


func _generate_full_optimization_local() -> void:
	if auto_optimizing:
		return

	auto_optimizing = true
	if auto_generate_button != null:
		auto_generate_button.disabled = true
		auto_generate_button.text = "OTIMIZANDO... AGUARDE"

	var best_strategy: Dictionary = {}
	var best_result: Dictionary = {}
	var objective_loss: bool = auto_objective_mode != null and auto_objective_mode.get_item_id(auto_objective_mode.selected) == 1
	var best_profit: float = INF if objective_loss else -INF
	var tested: int = 0
	var gale_start: int = 0
	var gale_end: int = 12
	if auto_search_gale != null and auto_search_gale.selected > 0:
		gale_start = auto_search_gale.selected - 1
		gale_end = gale_start + 1

	var mode_values: Array[int] = []
	if auto_gale_mode != null and auto_gale_mode.selected > 0:
		mode_values.append(auto_gale_mode.get_item_id(auto_gale_mode.selected))
	else:
		for m in range(0, 20):
			mode_values.append(m)

	var count_start: int = 1
	var count_end: int = 3001
	if auto_strategy_count != null and auto_strategy_count.selected > 0:
		# Seleção significa limite máximo: testa todas de 1 até N.
		count_start = auto_strategy_count.get_item_id(auto_strategy_count.selected)
		count_end = count_start + 1

	var consensus_values: Array[int] = []
	if auto_consensus != null and auto_consensus.selected > 0:
		consensus_values.append(auto_consensus.get_item_id(auto_consensus.selected))
	else:
		for c in [50, 60, 70, 80, 90, 100]:
			consensus_values.append(c)

	var fast_mode: bool = false # V3.53: busca exata obrigatória; nenhuma amostragem
	var theoretical_count: int = count_start if (auto_strategy_count != null and auto_strategy_count.selected > 0) else 3000
	var total_configs: int = (gale_end - gale_start) * mode_values.size() * theoretical_count * consensus_values.size()
	var started_ms: int = Time.get_ticks_msec()
	var min_rate_active: bool = auto_min_rate_enabled != null and auto_min_rate_enabled.button_pressed
	var min_rate_value: float = float(auto_min_rate.value) if auto_min_rate != null else 0.0
	var rate_mode_max: bool = auto_rate_mode != null and auto_rate_mode.get_item_id(auto_rate_mode.selected) == 1

	optimizer_result.text = (
		"OTIMIZAÇÃO EXATA TOTAL INICIADA\n\n"
		+ "Serão avaliadas até %d configurações.\n" % total_configs
		+ ((("ACERTO MÁXIMO: %.1f%%\n" if rate_mode_max else "ACERTO MÍNIMO: %.1f%%\n") % min_rate_value) if min_rate_active else "FILTRO DE ACERTO: DESATIVADO\n")
		+ "MODO: EXATO TOTAL • SEM AMOSTRAGEM\n"
		+ "Todas as configurações válidas do espaço selecionado são percorridas. Cache só evita repetir cálculo idêntico."
	)
	await get_tree().process_frame

	for gale in range(gale_start, gale_end):
		for gale_mode in mode_values:
			if not is_instance_valid(self):
				return

			var candidates: Array = await _base_candidate_library_async(gale, gale_mode)
			if candidates.is_empty():
				continue

			var max_count: int = mini(3000, candidates.size())

			# V3.39: cada padrão é lido UMA vez. A partir daí, as combinações usam
			# contadores de votos pré-calculados em vez de revarrer todos os padrões.
			var component_signal_caches: Array[PackedByteArray] = []
			for candidate in candidates.slice(0, max_count):
				if candidate is Dictionary:
					var cd: Dictionary = candidate
					var cached_signal = cd.get("_signal_cache", null)
					if cached_signal is PackedByteArray:
						component_signal_caches.append(cached_signal)
					else:
						component_signal_caches.append(_optimizer_component_signal_cache(cd))
				else:
					var empty_cache := PackedByteArray()
					empty_cache.resize(history.size())
					component_signal_caches.append(empty_cache)

			var votes_r := PackedByteArray()
			var votes_b := PackedByteArray()
			votes_r.resize(history.size())
			votes_b.resize(history.size())

			# Resultados idênticos de consenso são reaproveitados dentro do mesmo
			# Gale/modo/quantidade. Continua sendo busca exata: só evita recalcular
			# quando o vetor de sinais é exatamente o mesmo.
			var count_values: Array[int] = _optimizer_count_values(max_count, count_start, count_end, fast_mode)
			var count_lookup: Dictionary = {}
			for n in count_values:
				count_lookup[int(n)] = true

			var exact_result_cache: Dictionary = {}

			for count in range(1, max_count + 1):
				var comp_cache: PackedByteArray = component_signal_caches[count - 1]
				for hi in range(history.size()):
					var code: int = int(comp_cache[hi])
					if code == 1:
						votes_r[hi] = mini(255, int(votes_r[hi]) + 1)
					elif code == 2:
						votes_b[hi] = mini(255, int(votes_b[hi]) + 1)

				# Esta soma percorre todo o histórico. Atualiza a UI mesmo antes
				# de chegar ao primeiro marco de configurações testadas.
				# V3.58: no Android, não deixe dezenas de combinações pesadas
				# monopolizarem a thread principal. A enumeração continua EXATA.
				if count % 2 == 0 or count == max_count:
					optimizer_result.text = (
						"VARREDURA EXATA EM ANDAMENTO\n\n"
						+ "COMBINAÇÕES PREPARADAS: %d / %d\n" % [count, max_count]
						+ "CONFIGURAÇÕES TESTADAS: %d / %d\n" % [tested, total_configs]
						+ "MELHOR ATÉ AGORA: R$ %+.2f\n" % (best_profit if best_profit > -INF else 0.0)
						+ "BUSCA EXATA • nenhuma configuração descartada"
					)
					await get_tree().process_frame

				if not count_lookup.has(count):
					continue

				for consensus_pct in consensus_values:
					var candidate_strategy: Dictionary = _build_ensemble_from_ranked(
						candidates, count, gale, gale_mode, consensus_pct
					)
					if candidate_strategy.is_empty():
						continue
					var contrary_enabled: bool = auto_contrarian != null and auto_contrarian.button_pressed
					candidate_strategy = _materialize_contrarian_strategy(candidate_strategy, contrary_enabled)
					if _strategy_is_blocked_for_generation(candidate_strategy):
						tested += 1
						continue

					var signal_cache: PackedByteArray = _optimizer_signal_from_votes(
						votes_r, votes_b, consensus_pct
					)
					if contrary_enabled:
						signal_cache = _invert_signal_cache_rb(signal_cache)
					candidate_strategy["_optimizer_signal_cache"] = signal_cache

					var cache_key: String = "%d:%d" % [
						_optimizer_signal_hash(signal_cache),
						signal_cache.size()
					]
					var result: Dictionary
					if exact_result_cache.has(cache_key):
						result = (exact_result_cache[cache_key] as Dictionary).duplicate(true)
					else:
						result = _simulate_strategy(candidate_strategy)
						exact_result_cache[cache_key] = result.duplicate(true)

					tested += 1
					var profit: float = float(result.get("profit", -INF))
					var candidate_rate: float = float(result.get("rate", 0.0))
					var candidate_entries: int = int(result.get("entries", 0))
					var candidate_dd: float = float(result.get("max_dd", INF))
					var dd_limit_active: bool = auto_dd_limit_enabled != null and auto_dd_limit_enabled.button_pressed

					# V3.78: 0 entradas não é uma estratégia válida.
					# Evita 0% / R$0 vencer uma estratégia real negativa
					# quando ACERTO MÁXIMO estiver ativo.
					if candidate_entries <= 0:
						continue

					if auto_min_entries_enabled != null and auto_min_entries_enabled.button_pressed:
						if candidate_entries < int(auto_min_entries.value):
							continue

					if auto_min_signal_pct_enabled != null and auto_min_signal_pct_enabled.button_pressed:
						var signal_frequency_pct: float = (
							100.0 * float(candidate_entries) / float(maxi(1, history.size()))
						)
						if signal_frequency_pct + 0.0001 < float(auto_min_signal_pct.value):
							continue

					var dd_limit_value: float = float(auto_dd_limit.value) if auto_dd_limit != null else 0.0

					var rate_rejected: bool = false
					if min_rate_active:
						if rate_mode_max:
							rate_rejected = candidate_rate - 0.0001 > min_rate_value
						else:
							rate_rejected = candidate_rate + 0.0001 < min_rate_value
					if rate_rejected:
						if tested % _optimizer_yield_every(fast_mode) == 0:
							optimizer_result.text = (
								"OTIMIZANDO • ULTRA EXATO\n\n"
								+ "TESTADAS: %d / %d\n" % [tested, total_configs]
								+ ("%s: %.1f%% • ATUAL: %.1f%%\n" % [("ACERTO MÁXIMO" if rate_mode_max else "ACERTO MÍNIMO"), min_rate_value, candidate_rate])
								+ "DESCARTADA POR TAXA DE ACERTO"
							)
							await get_tree().process_frame
						continue

					if dd_limit_active and candidate_dd > dd_limit_value:
						if tested % _optimizer_yield_every(fast_mode) == 0:
							optimizer_result.text = (
								"OTIMIZANDO • ULTRA EXATO\n\n"
								+ "TESTADAS: %d / %d\n" % [tested, total_configs]
								+ "GALE: %s • %s\n" % ["G0" if gale == 0 else "G%d" % gale, _gale_mode_name(gale_mode)]
								+ "COMBINAÇÃO: %d • CONSENSO %d%%" % [count, consensus_pct]
							)
							await get_tree().process_frame
						continue

					var better_financial: bool = profit < best_profit if objective_loss else profit > best_profit
					if better_financial:
						best_profit = profit
						best_strategy = candidate_strategy.duplicate(true)
						best_strategy.erase("_optimizer_signal_cache")
						best_result = result
					elif is_equal_approx(profit, best_profit) and not best_strategy.is_empty():
						if candidate_dd < float(best_result.get("max_dd", INF)):
							best_strategy = candidate_strategy.duplicate(true)
							best_strategy.erase("_optimizer_signal_cache")
							best_result = result

					if tested % _optimizer_yield_every(fast_mode) == 0 or tested == total_configs:
						optimizer_result.text = (
							"OTIMIZANDO • ULTRA EXATO\n\n"
							+ "TESTADAS: %d / %d\n" % [tested, total_configs]
							+ "GALE: %s • %s\n" % ["G0" if gale == 0 else "G%d" % gale, _gale_mode_name(gale_mode)]
							+ "COMBINAÇÃO: %d • CONSENSO %d%%\n" % [count, consensus_pct]
							+ ("%s ATÉ AGORA: R$ %+.2f" % [("MAIOR PREJUÍZO" if objective_loss else "MELHOR"), (best_profit if (objective_loss and best_profit < INF) or (not objective_loss and best_profit > -INF) else 0.0)])
						)
						await get_tree().process_frame

	auto_optimizing = false
	if auto_generate_button != null:
		auto_generate_button.disabled = false
		auto_generate_button.text = "ENCONTRAR A MELHOR"

	if best_strategy.is_empty():
		generated_strategy.clear()
		optimizer_result.text = "Nenhuma estratégia COM ENTRADAS passou pelos filtros escolhidos. Ajuste o limite de acerto e/ou o drawdown."
		return

	generated_strategy = best_strategy.duplicate(true)
	generated_strategy["optimizer_min_rate_enabled"] = min_rate_active
	generated_strategy["optimizer_min_rate"] = min_rate_value if min_rate_active else 0.0
	generated_strategy["optimizer_rate_mode"] = "max" if rate_mode_max else "min"

	if auto_gale != null:
		auto_gale.select(int(generated_strategy.get("gale", 0)))
	if auto_gale_mode != null:
		for idx in range(auto_gale_mode.item_count):
			if auto_gale_mode.get_item_id(idx) == int(generated_strategy.get("gale_mode", 0)):
				auto_gale_mode.select(idx)
				break
	# V3.52: NÃO alterar a escolha do usuário após a otimização.
	# Se estava em MELHOR QUANTIDADE AUTOMATICAMENTE, continua automático;
	# assim a próxima busca exata continua avaliando 1..1000 quantidades
	# (120.000 configurações quando Gale está fixo, modo automático e consenso automático).
	if auto_consensus != null:
		var cp: int = int(generated_strategy.get("consensus_pct", 50))
		for idx in range(auto_consensus.item_count):
			if auto_consensus.get_item_id(idx) == cp:
				auto_consensus.select(idx)
				break

	var elapsed_s: float = float(Time.get_ticks_msec() - started_ms) / 1000.0
	optimizer_result.text = (
		"OTIMIZAÇÃO CONCLUÍDA\n\n"
		+ "CONFIGURAÇÕES TESTADAS: %d\n" % tested
		+ "TEMPO: %.1f s\n" % elapsed_s
		+ ((("%s EXIGIDO: %.1f%%\n" % [("ACERTO MÁXIMO" if rate_mode_max else "ACERTO MÍNIMO"), min_rate_value])) if min_rate_active else "FILTRO DE ACERTO: DESATIVADO\n")
		+ "CONSENSO ESCOLHIDO: %d%%\n\n" % int(generated_strategy.get("consensus_pct", 50))
		+ _result_text(generated_strategy, best_result)
		+ "\n\nMelhor resultado encontrado dentro dos filtros testados; não garante resultado futuro."
	)


func _generate_best_strategy() -> void:
	if history.size() < 20:
		optimizer_result.text = "Histórico insuficiente para gerar estratégia."
		return

	if auto_optimize_all != null and auto_optimize_all.button_pressed:
		await _generate_full_optimization()
		return

	var selected_gale: int = 0
	if auto_gale != null:
		selected_gale = auto_gale.selected

	var wanted_count: int = 1
	if auto_strategy_count != null:
		wanted_count = auto_strategy_count.selected + 1

	var candidates: Array = []
	var symbols: Array[String] = ["R", "B"]

	# Cria a biblioteca de candidatas individuais.
	for plen in range(1, 13):
		var total_patterns: int = int(pow(2, plen))
		for mask in range(total_patterns):
			var pattern: Array = []
			for pos in range(plen):
				pattern.append(symbols[(mask >> pos) & 1])

			for target in symbols:
				var candidate: Dictionary = {
					"type": "single",
					"name": "AUTO • %s → %s" % [",".join(pattern), target],
					"pattern": pattern.duplicate(),
					"entry": target,
					"gale": selected_gale,
					"gale_mode": auto_gale_mode.selected,
					"stake": float(strategy_stake.value),
					"initial_bank": float(strategy_bank.value)
				}
				_apply_current_risk_to_strategy(candidate)
				if _strategy_already_saved(candidate):
					continue
				var result: Dictionary = _simulate_strategy(candidate)
				var entries: int = int(result.get("entries", 0))
				if entries < 5:
					continue

				candidate["_profit"] = float(result.get("profit", -INF))
				candidate["_rate"] = float(result.get("rate", 0.0))
				candidate["_entries"] = entries
				candidates.append(candidate)

	if candidates.is_empty():
		generated_strategy.clear()
		optimizer_result.text = "Nenhuma estratégia automática válida foi encontrada."
		return

	candidates.sort_custom(func(a: Dictionary, b: Dictionary) -> bool:
		var pa: float = float(a.get("_profit", -INF))
		var pb: float = float(b.get("_profit", -INF))
		if is_equal_approx(pa, pb):
			return float(a.get("_rate", 0.0)) > float(b.get("_rate", 0.0))
		return pa > pb
	)

	var take: int = mini(wanted_count, candidates.size())
	var selected: Array = []
	for i in range(take):
		var clean: Dictionary = (candidates[i] as Dictionary).duplicate(true)
		clean.erase("_profit")
		clean.erase("_rate")
		clean.erase("_entries")
		selected.append(clean)

	if take == 1:
		generated_strategy = (selected[0] as Dictionary).duplicate(true)
		generated_strategy["name"] = (
			"AUTO 1 • %s • %s"
			% [
				str(generated_strategy.get("name", "")),
				"SEM GALE" if selected_gale == 0 else "G%d" % selected_gale
			]
		)
	else:
		generated_strategy = {
			"type": "ensemble",
			"name": "AUTO COMBINADA • %d ESTRATÉGIAS • %s" % [
				take,
				"SEM GALE" if selected_gale == 0 else "G%d" % selected_gale
			],
			"components": selected,
			"gale": selected_gale,
			"gale_mode": auto_gale_mode.selected,
			"consensus_pct": (auto_consensus.get_item_id(auto_consensus.selected) if auto_consensus != null and auto_consensus.selected > 0 else 50),
			"stake": float(strategy_stake.value),
			"initial_bank": float(strategy_bank.value)
		}

	_apply_current_risk_to_strategy(generated_strategy)
	var best_result: Dictionary = _simulate_strategy(generated_strategy)

	# Só preenche o editor convencional quando for uma estratégia simples.
	if str(generated_strategy.get("type", "single")) != "ensemble":
		strategy_name.text = str(generated_strategy.get("name", ""))
		strategy_pattern.text = ",".join(generated_strategy.get("pattern", []))
		strategy_entry.select(0 if str(generated_strategy.get("entry", "R")) == "R" else 1)
		strategy_gale.select(selected_gale)
		strategy_gale_mode.select(int(generated_strategy.get("gale_mode", 0)))

	optimizer_result.text = (
		"ESTRATÉGIA AUTOMÁTICA GERADA\n\n"
		+ _result_text(generated_strategy, best_result)
		+ "\n\nUse SALVAR ESTRATÉGIA GERADA para guardar exatamente esta combinação."
		+ "\n\nAtenção: otimização retrospectiva pode sofrer overfitting; não garante desempenho futuro."
	)


func _save_generated_strategy() -> void:
	if generated_strategy.is_empty():
		sim_result.text = "Gere uma estratégia automática antes de salvar."
		return

	if _strategy_already_saved(generated_strategy):
		sim_result.text = (
			"ESSA CONFIGURAÇÃO JÁ ESTÁ SALVA.\n\n"
			+ "Ela não será criada novamente enquanto continuar em SALVAS. "
			+ "Se você EXCLUIR a configuração, ela volta a poder ser gerada."
		)
		return

	var copy: Dictionary = generated_strategy.duplicate(true)
	copy["id"] = "%d_%d" % [Time.get_unix_time_from_system(), randi_range(1000, 9999)]
	copy["created_at"] = Time.get_datetime_string_from_system()
	strategies.append(copy)
	_save_strategies()
	_render_saved_strategies()
	sim_result.text = "ESTRATÉGIA GERADA SALVA COM SUCESSO"

func _simulate_current() -> void:
	var strategy := _strategy_from_form(false)
	if strategy.is_empty():
		return
	var result := _simulate_strategy(strategy)
	sim_result.text = _result_text(strategy, result)


func _save_current_strategy() -> void:
	var strategy := _strategy_from_form(true)
	if strategy.is_empty():
		return
	if _strategy_already_saved(strategy):
		sim_result.text = (
			"ESSA CONFIGURAÇÃO JÁ ESTÁ SALVA.\n"
			+ "Exclua a existente em SALVAS se quiser criá-la novamente."
		)
		return

	strategy["id"] = "%d_%d" % [Time.get_unix_time_from_system(), randi_range(1000, 9999)]
	strategy["created_at"] = Time.get_datetime_string_from_system()
	strategies.append(strategy)
	_save_strategies()

	var result := _simulate_strategy(strategy)
	sim_result.text = "SALVA COM SUCESSO\n\n" + _result_text(strategy, result)
	_render_saved_strategies()


func _strategy_from_form(require_name: bool) -> Dictionary:
	var name: String = strategy_name.text.strip_edges()
	if require_name and name == "":
		sim_result.text = "Dê um nome para a estratégia antes de salvar."
		return {}

	var pattern := _parse_pattern(strategy_pattern.text)
	if pattern.is_empty():
		sim_result.text = "Padrão inválido. Use V, P ou B separados por vírgula. Ex.: V,P,V"
		return {}

	var entry: String = str(["R", "B", "W"][strategy_entry.selected])
	var gale: int = strategy_gale.selected

	var strategy := {
		"name": name if name != "" else "Estratégia sem nome",
		"type": "single",
		"pattern": pattern,
		"entry": entry,
		"gale": gale,
		"gale_mode": strategy_gale_mode.selected,
		"stake": float(strategy_stake.value),
		"initial_bank": float(strategy_bank.value),
		"risk_trailing_enabled": risk_trailing_enabled.button_pressed,
		"risk_trailing_pct": float(risk_trailing_pct.value),
		"risk_capital_enabled": risk_capital_enabled.button_pressed,
		"risk_capital_floor": float(risk_capital_floor.value),
		"risk_performance_enabled": risk_performance_enabled.button_pressed,
		"risk_performance_window": int(risk_performance_window.value),
		"risk_performance_min_rate": float(risk_performance_min_rate.value),
		"white_protection_enabled": (
			strategy_white_protection_enabled != null
			and strategy_white_protection_enabled.button_pressed
		),
		"white_protection_stake": (
			float(strategy_white_protection_stake.value)
			if strategy_white_protection_stake != null else 1.0
		),
		"white_protection_payout": 14.0
	}
	return _materialize_contrarian_strategy(
		strategy,
		strategy_contrarian != null and strategy_contrarian.button_pressed
	)


func _parse_pattern(raw: String) -> Array:
	var normalized: String = raw.to_upper().replace(" ", "")
	var tokens := normalized.split(",", false)
	var out: Array = []

	if tokens.size() < 1 or tokens.size() > 8:
		return []

	for token in tokens:
		var s := str(token)
		if s == "V" or s == "R" or s == "VERMELHO":
			out.append("R")
		elif s == "P" or s == "PRETO":
			out.append("B")
		elif s == "B" or s == "BRANCO":
			out.append("W")
		else:
			return []
	return out


func _risk_config(strategy: Dictionary) -> Dictionary:
	return {
		"trailing_enabled": bool(strategy.get("risk_trailing_enabled", false)),
		"trailing_pct": float(strategy.get("risk_trailing_pct", 15.0)),
		"capital_enabled": bool(strategy.get("risk_capital_enabled", false)),
		"capital_floor": float(strategy.get("risk_capital_floor", strategy.get("initial_bank", 1000.0))),
		"performance_enabled": bool(strategy.get("risk_performance_enabled", false)),
		"performance_window": int(strategy.get("risk_performance_window", 20)),
		"performance_min_rate": float(strategy.get("risk_performance_min_rate", 50.0))
	}


func _risk_stop_reason(strategy: Dictionary, bank: float, peak: float, recent: Array) -> String:
	var cfg := _risk_config(strategy)
	if bool(cfg["trailing_enabled"]) and peak > 0.0:
		var drop_pct: float = 100.0 * (peak - bank) / peak
		if drop_pct >= float(cfg["trailing_pct"]):
			return "TRAILING STOP %.2f%%" % drop_pct
	if bool(cfg["capital_enabled"]) and bank <= float(cfg["capital_floor"]):
		return "PROTEÇÃO DE CAPITAL"
	if bool(cfg["performance_enabled"]):
		var window: int = maxi(1, int(cfg["performance_window"]))
		if recent.size() >= window:
			var wins_recent: int = 0
			for x in recent.slice(recent.size() - window, recent.size()):
				if bool(x): wins_recent += 1
			var rate_recent: float = 100.0 * float(wins_recent) / float(window)
			if rate_recent < float(cfg["performance_min_rate"]):
				return "STOP POR DESEMPENHO %.2f%%" % rate_recent
	return ""



func _gale_mode_name(mode: int) -> String:
	if mode == 0: return "TRADICIONAL"
	if mode == 1: return "PRÓXIMO SINAL"
	if mode >= 2 and mode <= 10: return "PULAR %d RODADA%s" % [mode - 1, "" if mode == 2 else "S"]
	if mode >= 11 and mode <= 19: return "PULAR %d SINAL%s" % [mode - 10, "" if mode == 11 else "IS"]
	return "TRADICIONAL"

func _simulate_strategy(strategy: Dictionary) -> Dictionary:
	var mode: int = int(strategy.get("gale_mode", 0))
	if mode == 1:
		if str(strategy.get("type", "single")) == "ensemble":
			return _simulate_ensemble_next_signal(strategy)
		return _simulate_single_next_signal(strategy)
	if mode >= 2 and mode <= 10:
		return _simulate_skip_rounds(strategy, mode - 1)
	if mode >= 11 and mode <= 19:
		return _simulate_skip_signals(strategy, mode - 10)
	if str(strategy.get("type", "single")) == "ensemble":
		return _simulate_ensemble_strategy(strategy)
	return _simulate_single_strategy(strategy)


func _optimizer_cached_signal(strategy: Dictionary, index: int) -> String:
	var cache = strategy.get("_optimizer_signal_cache", null)
	if cache is PackedByteArray:
		var packed: PackedByteArray = cache
		if index >= 0 and index < packed.size():
			var code: int = int(packed[index])
			if code == 1:
				return "R"
			if code == 2:
				return "B"
	return ""


func _ensemble_signal_at(index: int, components: Array, consensus_pct: int = 50) -> String:
	var votes_r: int = 0
	var votes_b: int = 0
	for item in components:
		if not (item is Dictionary):
			continue
		var comp: Dictionary = item
		var pv = comp.get("pattern", [])
		if not (pv is Array):
			continue
		var pattern: Array = pv
		if index < pattern.size():
			continue
		if _pattern_matches(index - pattern.size(), pattern):
			var target: String = str(comp.get("entry", ""))
			if target == "R": votes_r += 1
			elif target == "B": votes_b += 1
	var active: int = votes_r + votes_b
	if active <= 0 or votes_r == votes_b:
		return ""
	var winner_votes: int = maxi(votes_r, votes_b)
	var pct: float = 100.0 * float(winner_votes) / float(active)
	var required: float = 50.0001 if consensus_pct <= 50 else float(consensus_pct)
	if pct + 0.0001 < required:
		return ""
	return "R" if votes_r > votes_b else "B"


func _simulate_single_next_signal(strategy: Dictionary) -> Dictionary:
	var pattern: Array = strategy.get("pattern", [])
	var target: String = str(strategy.get("entry", "R"))
	var signal_callable: Callable = func(index: int) -> String:
		if index >= pattern.size() and _pattern_matches(index - pattern.size(), pattern):
			return target
		return ""
	return _simulate_next_signal_core(strategy, signal_callable, 0)


func _simulate_ensemble_next_signal(strategy: Dictionary) -> Dictionary:
	var cv = strategy.get("components", [])
	if not (cv is Array):
		return {}
	var components: Array = cv
	var has_cache: bool = strategy.get("_optimizer_signal_cache", null) is PackedByteArray
	var signal_callable: Callable = func(index: int) -> String:
		if has_cache:
			return _optimizer_cached_signal(strategy, index)
		return _ensemble_signal_at(index, components, int(strategy.get("consensus_pct", 50)))
	return _simulate_next_signal_core(strategy, signal_callable, 0)


func _simulate_skip_signals(strategy: Dictionary, skip_signals: int) -> Dictionary:
	var is_ensemble: bool = str(strategy.get("type", "single")) == "ensemble"
	if is_ensemble:
		var cv = strategy.get("components", [])
		if not (cv is Array):
			return {}
		var components: Array = cv
		var has_cache: bool = strategy.get("_optimizer_signal_cache", null) is PackedByteArray
		var ensemble_callable: Callable = func(index: int) -> String:
			if has_cache:
				return _optimizer_cached_signal(strategy, index)
			return _ensemble_signal_at(index, components, int(strategy.get("consensus_pct", 50)))
		return _simulate_next_signal_core(strategy, ensemble_callable, skip_signals)
	var pattern: Array = strategy.get("pattern", [])
	var target: String = str(strategy.get("entry", "R"))
	var single_callable: Callable = func(index: int) -> String:
		if index >= pattern.size() and _pattern_matches(index - pattern.size(), pattern):
			return target
		return ""
	return _simulate_next_signal_core(strategy, single_callable, skip_signals)


func _simulate_next_signal_core(strategy: Dictionary, signal_callable: Callable, skip_signals: int = 0) -> Dictionary:
	var gale_max: int = int(strategy.get("gale", 0))
	var stake_base: float = float(strategy.get("stake", 10.0))
	var initial_bank: float = float(strategy.get("initial_bank", 1000.0))
	var gale_wins: Array = []
	for _g in range(gale_max + 1): gale_wins.append(0)

	var bank: float = initial_bank
	var peak: float = bank
	var min_bank: float = bank
	var max_dd: float = 0.0
	var bank_at_max_dd: float = bank
	var peak_at_max_dd: float = bank
	var entries: int = 0
	var wins: int = 0
	var losses: int = 0
	var max_gale_reached: int = 0
	var largest_stake: float = 0.0
	var max_cycle_exposure: float = 0.0
	var bankrupt_stops: int = 0
	var recent_results: Array = []
	var risk_stop: String = ""
	var cycle_active: bool = false
	var gale_level: int = 0
	var cycle_exposure: float = 0.0
	var signal_skip_remaining: int = 0

	for i in range(history.size()):
		var target: String = str(signal_callable.call(i))
		if target == "":
			continue

		if cycle_active and signal_skip_remaining > 0:
			signal_skip_remaining -= 1
			continue

		# No modo próximo sinal, uma derrota NÃO aposta na rodada seguinte.
		# O próximo nível só é executado quando surgir um novo sinal válido.
		if not cycle_active:
			entries += 1
			gale_level = 0
			cycle_exposure = 0.0
			cycle_active = true

		var stake: float = stake_base * pow(2.0, gale_level)
		if bank < stake:
			bankrupt_stops += 1
			losses += 1
			cycle_active = false
			continue

		max_gale_reached = maxi(max_gale_reached, gale_level)
		largest_stake = maxf(largest_stake, stake)
		cycle_exposure += stake
		max_cycle_exposure = maxf(max_cycle_exposure, cycle_exposure)

		bank -= stake
		min_bank = minf(min_bank, bank)
		var dd: float = peak - bank
		if dd > max_dd:
			max_dd = dd
			bank_at_max_dd = bank
			peak_at_max_dd = peak

		if _round_color(history[i]) == target:
			bank += stake * 2.0
			wins += 1
			gale_wins[gale_level] += 1
			peak = maxf(peak, bank)
			cycle_active = false
			signal_skip_remaining = 0
			recent_results.append(true)
			risk_stop = _risk_stop_reason(strategy, bank, peak, recent_results)
			if risk_stop != "":
				break
		else:
			if gale_level >= gale_max:
				losses += 1
				cycle_active = false
				signal_skip_remaining = 0
				recent_results.append(false)
				risk_stop = _risk_stop_reason(strategy, bank, peak, recent_results)
				if risk_stop != "":
					break
			else:
				gale_level += 1
				signal_skip_remaining = maxi(0, skip_signals)

	var rate: float = 100.0 * float(wins) / float(entries) if entries > 0 else 0.0
	var dd_pct: float = 100.0 * max_dd / peak_at_max_dd if peak_at_max_dd > 0 else 0.0
	return {
		"entries":entries, "wins":wins, "losses":losses, "gale_wins":gale_wins,
		"profit":bank-initial_bank, "rate":rate, "bank":bank, "max_dd":max_dd,
		"max_gale_reached":max_gale_reached, "largest_stake":largest_stake,
		"max_cycle_exposure":max_cycle_exposure, "min_bank":min_bank,
		"bankrupt_stops":bankrupt_stops, "peak_bank":peak,
		"bank_at_max_dd":bank_at_max_dd, "peak_at_max_dd":peak_at_max_dd,
		"max_dd_pct":dd_pct, "broke_bank":bankrupt_stops > 0,
		"risk_stop_triggered":risk_stop != "", "risk_stop_reason":risk_stop
	}


func _simulate_skip_rounds(strategy: Dictionary, skip_rounds: int) -> Dictionary:
	var is_ensemble: bool = str(strategy.get("type", "single")) == "ensemble"
	var pattern: Array = strategy.get("pattern", [])
	var target_fixed: String = str(strategy.get("entry", "R"))
	var components: Array = strategy.get("components", []) if is_ensemble else []
	var gale_max: int = int(strategy.get("gale", 0))
	var stake_base: float = float(strategy.get("stake", 10.0))
	var initial_bank: float = float(strategy.get("initial_bank", 1000.0))
	var gale_wins: Array = []
	for _g in range(gale_max + 1): gale_wins.append(0)

	var bank: float = initial_bank
	var peak: float = bank
	var min_bank: float = bank
	var max_dd: float = 0.0
	var bank_at_max_dd: float = bank
	var peak_at_max_dd: float = bank
	var entries: int = 0
	var wins: int = 0
	var losses: int = 0
	var max_gale_reached: int = 0
	var largest_stake: float = 0.0
	var max_cycle_exposure: float = 0.0
	var bankrupt_stops: int = 0
	var recent_results: Array = []
	var risk_stop: String = ""
	var cycle_active: bool = false
	var gale_level: int = 0
	var cycle_target: String = ""
	var skip_remaining: int = 0
	var cycle_exposure: float = 0.0

	for i in range(history.size()):
		if cycle_active and skip_remaining > 0:
			skip_remaining -= 1
			continue

		var sinal_atual: String = ""
		if is_ensemble:
			if strategy.get("_optimizer_signal_cache", null) is PackedByteArray:
				sinal_atual = _optimizer_cached_signal(strategy, i)
			else:
				sinal_atual = _ensemble_signal_at(i, components, int(strategy.get("consensus_pct", 50)))
		elif i >= pattern.size() and _pattern_matches(i - pattern.size(), pattern):
			sinal_atual = target_fixed

		if not cycle_active:
			if sinal_atual == "":
				continue
			entries += 1
			gale_level = 0
			cycle_target = sinal_atual
			cycle_exposure = 0.0
			cycle_active = true

		var stake: float = stake_base * pow(2.0, gale_level)
		if bank < stake:
			bankrupt_stops += 1
			losses += 1
			cycle_active = false
			continue

		max_gale_reached = maxi(max_gale_reached, gale_level)
		largest_stake = maxf(largest_stake, stake)
		cycle_exposure += stake
		max_cycle_exposure = maxf(max_cycle_exposure, cycle_exposure)
		bank -= stake
		min_bank = minf(min_bank, bank)
		var dd: float = peak - bank
		if dd > max_dd:
			max_dd = dd
			bank_at_max_dd = bank
			peak_at_max_dd = peak

		if _round_color(history[i]) == cycle_target:
			bank += stake * 2.0
			wins += 1
			gale_wins[gale_level] += 1
			peak = maxf(peak, bank)
			cycle_active = false
			gale_level = 0
			cycle_target = ""
			skip_remaining = 0
			recent_results.append(true)
			risk_stop = _risk_stop_reason(strategy, bank, peak, recent_results)
			if risk_stop != "": break
		else:
			if gale_level >= gale_max:
				losses += 1
				cycle_active = false
				gale_level = 0
				cycle_target = ""
				skip_remaining = 0
				recent_results.append(false)
				risk_stop = _risk_stop_reason(strategy, bank, peak, recent_results)
				if risk_stop != "": break
			else:
				gale_level += 1
				skip_remaining = maxi(1, skip_rounds)

	var rate: float = 100.0 * float(wins) / float(entries) if entries > 0 else 0.0
	var dd_pct: float = 100.0 * max_dd / peak_at_max_dd if peak_at_max_dd > 0 else 0.0
	return {
		"entries":entries, "wins":wins, "losses":losses, "gale_wins":gale_wins,
		"profit":bank-initial_bank, "rate":rate, "bank":bank, "max_dd":max_dd,
		"max_gale_reached":max_gale_reached, "largest_stake":largest_stake,
		"max_cycle_exposure":max_cycle_exposure, "min_bank":min_bank,
		"bankrupt_stops":bankrupt_stops, "peak_bank":peak,
		"bank_at_max_dd":bank_at_max_dd, "peak_at_max_dd":peak_at_max_dd,
		"max_dd_pct":dd_pct, "broke_bank":bankrupt_stops > 0,
		"risk_stop_triggered":risk_stop != "", "risk_stop_reason":risk_stop,
		"skip_rounds":skip_rounds
	}


func _simulate_ensemble_strategy(strategy: Dictionary) -> Dictionary:
	var components_value = strategy.get("components", [])
	var initial_bank: float = float(strategy.get("initial_bank", 1000.0))
	if not (components_value is Array):
		return {
			"entries":0, "wins":0, "losses":0, "gale_wins":[],
			"profit":0.0, "rate":0.0, "bank":initial_bank, "max_dd":0.0,
			"max_gale_reached":0, "largest_stake":0.0, "max_cycle_exposure":0.0,
			"min_bank":initial_bank, "bankrupt_stops":0, "peak_bank":initial_bank, "bank_at_max_dd":initial_bank, "peak_at_max_dd":initial_bank, "max_dd_pct":0.0, "broke_bank":false
		}

	var components: Array = components_value
	var gale_max: int = int(strategy.get("gale", 0))
	var stake_base: float = float(strategy.get("stake", 10.0))
	var max_pattern: int = 1

	for item in components:
		if item is Dictionary:
			var comp_pattern = (item as Dictionary).get("pattern", [])
			if comp_pattern is Array:
				max_pattern = maxi(max_pattern, comp_pattern.size())

	if history.size() <= max_pattern:
		return {
			"entries":0, "wins":0, "losses":0, "gale_wins":[],
			"profit":0.0, "rate":0.0, "bank":initial_bank, "max_dd":0.0,
			"max_gale_reached":0, "largest_stake":0.0, "max_cycle_exposure":0.0,
			"min_bank":initial_bank, "bankrupt_stops":0, "peak_bank":initial_bank, "bank_at_max_dd":initial_bank, "peak_at_max_dd":initial_bank, "max_dd_pct":0.0, "broke_bank":false
		}

	var entries: int = 0
	var wins: int = 0
	var losses: int = 0
	var gale_wins: Array = []
	for _g in range(gale_max + 1):
		gale_wins.append(0)

	var bank: float = initial_bank
	var peak: float = bank
	var max_dd: float = 0.0
	var bank_at_max_dd: float = bank
	var peak_at_max_dd: float = bank
	var min_bank: float = bank
	var max_gale_reached: int = 0
	var largest_stake: float = 0.0
	var max_cycle_exposure: float = 0.0
	var bankrupt_stops: int = 0
	var recent_results: Array = []
	var risk_stop: String = ""
	var i: int = max_pattern

	while i < history.size():
		var target_color: String = ""
		if strategy.get("_optimizer_signal_cache", null) is PackedByteArray:
			target_color = _optimizer_cached_signal(strategy, i)
		else:
			var votes_r: int = 0
			var votes_b: int = 0

			for item in components:
				if not (item is Dictionary):
					continue
				var comp: Dictionary = item
				var pattern_value = comp.get("pattern", [])
				if not (pattern_value is Array):
					continue
				var pattern: Array = pattern_value
				var start: int = i - pattern.size()

				if _pattern_matches(start, pattern):
					var target: String = str(comp.get("entry", ""))
					if target == "R":
						votes_r += 1
					elif target == "B":
						votes_b += 1

			var active_votes: int = votes_r + votes_b
			if active_votes > 0 and votes_r != votes_b:
				var winner_votes: int = maxi(votes_r, votes_b)
				var pct_votes: float = 100.0 * float(winner_votes) / float(active_votes)
				var consensus_required: float = float(int(strategy.get("consensus_pct", 50)))
				if consensus_required <= 50:
					consensus_required = 50.0001
				if pct_votes + 0.0001 >= consensus_required:
					target_color = "R" if votes_r > votes_b else "B"

		if target_color == "":
			i += 1
			continue

		entries += 1
		var won: bool = false
		var stake: float = stake_base
		var consumed: int = i
		var cycle_exposure: float = 0.0

		for g in range(gale_max + 1):
			var k: int = i + g
			if k >= history.size():
				break

			if bank < stake:
				bankrupt_stops += 1
				break

			consumed = k
			max_gale_reached = maxi(max_gale_reached, g)
			largest_stake = maxf(largest_stake, stake)
			cycle_exposure += stake
			max_cycle_exposure = maxf(max_cycle_exposure, cycle_exposure)

			bank -= stake
			min_bank = minf(min_bank, bank)
			var current_dd: float = peak - bank
			if current_dd > max_dd:
				max_dd = current_dd
				bank_at_max_dd = bank
				peak_at_max_dd = peak

			if _round_color(history[k]) == target_color:
				bank += stake * 2.0
				wins += 1
				if g < gale_wins.size():
					gale_wins[g] += 1
				won = true
				peak = maxf(peak, bank)
				min_bank = minf(min_bank, bank)
				break

			stake *= 2.0

		if not won:
			losses += 1
		recent_results.append(won)
		risk_stop = _risk_stop_reason(strategy, bank, peak, recent_results)
		if risk_stop != "":
			break

		i = maxi(i + 1, consumed + 1)
		peak = maxf(peak, bank)
		var end_cycle_dd: float = peak - bank
		if end_cycle_dd > max_dd:
			max_dd = end_cycle_dd
			bank_at_max_dd = bank
			peak_at_max_dd = peak

	var rate: float = 100.0 * float(wins) / float(entries) if entries > 0 else 0.0
	var max_dd_pct: float = 100.0 * max_dd / peak_at_max_dd if peak_at_max_dd > 0.0 else 0.0
	var broke_bank: bool = bank <= 0.0 or bankrupt_stops > 0
	return {
		"entries": entries,
		"wins": wins,
		"losses": losses,
		"gale_wins": gale_wins,
		"profit": bank - initial_bank,
		"rate": rate,
		"bank": bank,
		"max_dd": max_dd,
		"max_gale_reached": max_gale_reached,
		"largest_stake": largest_stake,
		"max_cycle_exposure": max_cycle_exposure,
		"min_bank": min_bank,
		"bankrupt_stops": bankrupt_stops,
		"peak_bank": peak,
		"bank_at_max_dd": bank_at_max_dd,
		"peak_at_max_dd": peak_at_max_dd,
		"max_dd_pct": max_dd_pct,
		"broke_bank": broke_bank,
		"risk_stop_triggered": risk_stop != "",
		"risk_stop_reason": risk_stop
	}

func _simulate_single_strategy(strategy: Dictionary) -> Dictionary:
	var pattern: Array = strategy.get("pattern", [])
	var target: String = str(strategy.get("entry", "R"))
	var gale_max: int = int(strategy.get("gale", 0))
	var stake_base: float = float(strategy.get("stake", 10.0))
	var initial_bank: float = float(strategy.get("initial_bank", 1000.0))

	var empty_result := {
		"entries":0, "wins":0, "losses":0, "gale_wins":[],
		"profit":0.0, "rate":0.0, "bank":initial_bank, "max_dd":0.0,
		"max_gale_reached":0, "largest_stake":0.0, "max_cycle_exposure":0.0,
		"min_bank":initial_bank, "bankrupt_stops":0, "peak_bank":initial_bank, "bank_at_max_dd":initial_bank, "peak_at_max_dd":initial_bank, "max_dd_pct":0.0, "broke_bank":false
	}

	if history.size() <= pattern.size():
		return empty_result

	var entries: int = 0
	var wins: int = 0
	var losses: int = 0
	var gale_wins: Array = []
	for _g in range(gale_max + 1):
		gale_wins.append(0)

	var bank: float = initial_bank
	var peak: float = bank
	var max_dd: float = 0.0
	var bank_at_max_dd: float = bank
	var peak_at_max_dd: float = bank
	var min_bank: float = bank
	var max_gale_reached: int = 0
	var largest_stake: float = 0.0
	var max_cycle_exposure: float = 0.0
	var bankrupt_stops: int = 0
	var recent_results: Array = []
	var risk_stop: String = ""
	var i: int = pattern.size()

	while i < history.size():
		if not _pattern_matches(i - pattern.size(), pattern):
			i += 1
			continue

		entries += 1
		var won: bool = false
		var stake: float = stake_base
		var consumed: int = i
		var cycle_exposure: float = 0.0
		var cycle_aborted: bool = false

		for g in range(gale_max + 1):
			var k: int = i + g
			if k >= history.size():
				break

			# Não permite aposta impossível: se a banca não cobre a stake,
			# o ciclo é encerrado como perda por banca insuficiente.
			if bank < stake:
				bankrupt_stops += 1
				cycle_aborted = true
				break

			consumed = k
			max_gale_reached = maxi(max_gale_reached, g)
			largest_stake = maxf(largest_stake, stake)
			cycle_exposure += stake
			max_cycle_exposure = maxf(max_cycle_exposure, cycle_exposure)

			bank -= stake
			min_bank = minf(min_bank, bank)

			# Drawdown é atualizado IMEDIATAMENTE após cada débito de aposta,
			# não apenas no fim do ciclo.
			var current_dd: float = peak - bank
			if current_dd > max_dd:
				max_dd = current_dd
				bank_at_max_dd = bank
				peak_at_max_dd = peak

			var actual: String = _round_color(history[k])
			if actual == target:
				bank += stake * 2.0
				wins += 1
				if g < gale_wins.size():
					gale_wins[g] += 1
				won = true

				# Atualiza novo pico após o pagamento.
				peak = maxf(peak, bank)
				min_bank = minf(min_bank, bank)
				break

			stake *= 2.0

		if not won:
			losses += 1
		recent_results.append(won)
		risk_stop = _risk_stop_reason(strategy, bank, peak, recent_results)
		if risk_stop != "":
			break

		# Se abortou por banca insuficiente, não tenta criar dinheiro negativo.
		if cycle_aborted:
			i = maxi(i + 1, consumed + 1)
		else:
			i = maxi(i + 1, consumed + 1)

		peak = maxf(peak, bank)
		var end_cycle_dd: float = peak - bank
		if end_cycle_dd > max_dd:
			max_dd = end_cycle_dd
			bank_at_max_dd = bank
			peak_at_max_dd = peak

	var rate: float = 100.0 * float(wins) / float(entries) if entries > 0 else 0.0
	var max_dd_pct: float = 100.0 * max_dd / peak_at_max_dd if peak_at_max_dd > 0.0 else 0.0
	var broke_bank: bool = bank <= 0.0 or bankrupt_stops > 0
	return {
		"entries": entries,
		"wins": wins,
		"losses": losses,
		"gale_wins": gale_wins,
		"profit": bank - initial_bank,
		"rate": rate,
		"bank": bank,
		"max_dd": max_dd,
		"max_gale_reached": max_gale_reached,
		"largest_stake": largest_stake,
		"max_cycle_exposure": max_cycle_exposure,
		"min_bank": min_bank,
		"bankrupt_stops": bankrupt_stops,
		"peak_bank": peak,
		"bank_at_max_dd": bank_at_max_dd,
		"peak_at_max_dd": peak_at_max_dd,
		"max_dd_pct": max_dd_pct,
		"broke_bank": broke_bank,
		"risk_stop_triggered": risk_stop != "",
		"risk_stop_reason": risk_stop
	}

func _pattern_matches(start: int, pattern: Array) -> bool:
	if start < 0 or start + pattern.size() > history.size():
		return false
	for j in range(pattern.size()):
		if _round_color(history[start + j]) != str(pattern[j]):
			return false
	return true


func _round_color(item) -> String:
	if item is Dictionary:
		return str((item as Dictionary).get("cor", ""))
	return ""


func _gale_stats_text(strategy: Dictionary, result: Dictionary) -> String:
	var gale_max: int = int(strategy.get("gale", 0))
	var wins_value = result.get("gale_wins", [])
	if not (wins_value is Array):
		return "WIN por Gale: sem dados"

	var wins_by_gale: Array = wins_value
	var lines := PackedStringArray()
	for g in range(gale_max + 1):
		var count: int = 0
		if g < wins_by_gale.size():
			count = int(wins_by_gale[g])
		var label_text := "SEM GALE (G0)" if g == 0 else "GALE %d (G%d)" % [g, g]
		lines.append("%s: %d WIN" % [label_text, count])

	return "\n".join(lines)


func _precision_stats_text(strategy: Dictionary, result: Dictionary) -> String:
	var requested_gale: int = int(strategy.get("gale", 0))
	var initial_bank: float = float(strategy.get("initial_bank", 1000.0))
	var reached_gale: int = int(result.get("max_gale_reached", 0))
	var largest_stake: float = float(result.get("largest_stake", 0.0))
	var max_exposure: float = float(result.get("max_cycle_exposure", 0.0))
	var min_bank: float = float(result.get("min_bank", 1000.0))
	var peak_bank: float = float(result.get("peak_bank", 1000.0))
	var bank_at_dd: float = float(result.get("bank_at_max_dd", 1000.0))
	var peak_at_dd: float = float(result.get("peak_at_max_dd", 1000.0))
	var dd_pct: float = float(result.get("max_dd_pct", 0.0))
	var bankroll_stops: int = int(result.get("bankrupt_stops", 0))
	var broke: bool = bool(result.get("broke_bank", false))

	var broke_text := "SIM" if broke else "NÃO"
	var risk_triggered: bool = bool(result.get("risk_stop_triggered", false))
	var risk_reason: String = str(result.get("risk_stop_reason", ""))
	var risk_text: String = ("SIM • " + risk_reason) if risk_triggered else "NÃO"

	return (
		"BANCA INICIAL: R$ %.2f\n"
		+ "MAIOR BANCA ATINGIDA: R$ %.2f\n"
		+ "MENOR BANCA DURANTE A SIMULAÇÃO: R$ %.2f\n"
		+ "PICO ANTES DO MAIOR DRAWDOWN: R$ %.2f\n"
		+ "BANCA NO FUNDO DO MAIOR DRAWDOWN: R$ %.2f\n"
		+ "DRAWDOWN SOBRE ESSE PICO: %.2f%%\n"
		+ "QUEBRA / BANCA INSUFICIENTE: %s\n"
		+ "STOP DE RISCO ACIONADO: %s\n\n"
		+ "GALE CONFIGURADO: G%d\n"
		+ "MAIOR GALE REALMENTE ATINGIDO: G%d\n"
		+ "MAIOR APOSTA INDIVIDUAL: R$ %.2f\n"
		+ "MAIOR EXPOSIÇÃO EM UM CICLO: R$ %.2f\n"
		+ "CICLOS INTERROMPIDOS POR BANCA INSUFICIENTE: %d"
	) % [
		initial_bank,
		peak_bank,
		min_bank,
		peak_at_dd,
		bank_at_dd,
		dd_pct,
		broke_text,
		risk_text,
		requested_gale,
		reached_gale,
		largest_stake,
		max_exposure,
		bankroll_stops
	]

func _result_text(strategy: Dictionary, result: Dictionary) -> String:
	var contrary_prefix: String = "APOSTA CONTRÁRIA: ATIVADA\n" if bool(strategy.get("contrarian", false)) else ""
	var gale: int = int(strategy.get("gale", 0))
	var gale_text: String = "SEM GALE" if gale == 0 else "MÁXIMO G%d" % gale
	var gale_mode_text: String = _gale_mode_name(int(strategy.get("gale_mode", 0)))
	var description: String = ""

	# V3.79: sempre exibe o resultado financeiro real, inclusive negativo.
	# Prejuízo NÃO invalida estratégia; o filtro de acerto decide se ela concorre.
	var result_entries: int = int(result.get("entries", 0))
	var result_wins: int = int(result.get("wins", 0))
	var result_losses: int = int(result.get("losses", 0))
	var result_profit: float = float(result.get("profit", 0.0))
	var financial_label: String = "PREJUÍZO" if result_profit < 0.0 else "LUCRO"

	if str(strategy.get("type", "single")) == "ensemble":
		var components_value = strategy.get("components", [])
		var names := PackedStringArray()
		if components_value is Array:
			for item in components_value:
				if item is Dictionary:
					var comp: Dictionary = item
					var pn := PackedStringArray()
					var pv = comp.get("pattern", [])
					if pv is Array:
						for code in pv:
							pn.append(_short_name(str(code)))
					names.append("%s→%s" % [",".join(pn), _short_name(str(comp.get("entry", "R")))])
		var cp: int = int(strategy.get("consensus_pct", 50))
		var consensus_text: String = "MAIORIA SIMPLES (>50%)" if cp <= 50 else "MÍNIMO %d%%" % cp
		description = "COMBINAÇÃO DE %d ESTRATÉGIAS\n%s\nCONSENSO: %s • empate = sem entrada" % [
			names.size(),
			" | ".join(names),
			consensus_text
		]
	else:
		var pattern_names := PackedStringArray()
		var pattern_value = strategy.get("pattern", [])
		if pattern_value is Array:
			for code in pattern_value:
				pattern_names.append(_short_name(str(code)))
		description = "Padrão: %s → entrar %s" % [
			",".join(pattern_names),
			_color_name(str(strategy.get("entry", "R")))
		]

	return contrary_prefix + (
		"%s\n"
		+ "%s\n"
		+ "%s • %s • Entrada R$ %.2f\n\n"
		+ "ENTRADAS TOTAIS: %d\n"
		+ "FREQUÊNCIA DE SINAIS: %.2f%%\n"
		+ "WIN: %d • LOSS: %d\n"
		+ "WIN + LOSS: %d\n"
		+ "ACERTO DO CICLO: %.2f%%\n\n"
		+ "%s\n\n"
		+ "%s: R$ %+.2f\n"
		+ "RESULTADO FINANCEIRO LÍQUIDO: R$ %+.2f\n"
		+ "BANCA FINAL: R$ %.2f\n"
		+ "DRAWDOWN MÁX. REAL: R$ %.2f\n\n"
		+ "%s\n\n"
		+ "Simulação histórica não garante resultado futuro."
	) % [
		str(strategy.get("name", "-")),
		description,
		gale_text,
		gale_mode_text,
		float(strategy.get("stake", 10.0)),
		result_entries,
		float(result.get("signal_frequency_pct", 0.0)) if result.has("signal_frequency_pct") else (100.0 * float(result_entries) / float(maxi(1, history.size()))),
		result_wins,
		result_losses,
		result_wins + result_losses,
		float(result.get("rate", 0.0)),
		_gale_stats_text(strategy, result),
		financial_label,
		result_profit,
		result_profit,
		float(result.get("bank", 1000.0)),
		float(result.get("max_dd", 0.0)),
		_precision_stats_text(strategy, result)
	]


func _strategy_logic_signature(strategy: Dictionary) -> String:
	var stype: String = str(strategy.get("type", "single"))
	if stype == "white":
		return "white|%s|%d|%d|%d" % [
			",".join(strategy.get("pattern", [])),
			int(strategy.get("min_gap", 0)),
			int(strategy.get("max_gap", 999999)),
			int(strategy.get("attempts", 6))
		]

	if stype == "ensemble":
		var parts := PackedStringArray()
		var comps = strategy.get("components", [])
		if comps is Array:
			for comp in comps:
				if comp is Dictionary:
					parts.append(_strategy_logic_signature(comp as Dictionary))
		return "ensemble|%s|g%d|m%d|c%d|inv%s" % [
			";".join(parts),
			int(strategy.get("gale", 0)),
			int(strategy.get("gale_mode", 0)),
			int(strategy.get("consensus_pct", 50)),
			str(bool(strategy.get("contrarian", false)))
		]

	return "single|%s|%s|g%d|m%d|inv%s|wp%s|w%.2f" % [
		",".join(strategy.get("pattern", [])),
		str(strategy.get("entry", "")),
		int(strategy.get("gale", 0)),
		int(strategy.get("gale_mode", 0)),
		str(bool(strategy.get("contrarian", false))),
		str(bool(strategy.get("white_protection_enabled", false))),
		float(strategy.get("white_protection_stake", 0.0))
	]


func _strategy_is_blocked_for_generation(candidate: Dictionary) -> bool:
	# V3.88:
	# Enquanto uma configuração existir em SALVAS, ela não pode ser gerada novamente.
	# Ao EXCLUIR de SALVAS, automaticamente volta a ficar elegível.
	var sig: String = _strategy_logic_signature(candidate)
	for item in strategies:
		if item is Dictionary:
			var saved: Dictionary = item
			if _strategy_logic_signature(saved) == sig:
				return true
	return false


func _strategy_already_saved(candidate: Dictionary) -> bool:
	return _strategy_is_blocked_for_generation(candidate)


func _set_strategy_blocked(idx: int, blocked: bool) -> void:
	if idx < 0 or idx >= strategies.size():
		return
	var item = strategies[idx]
	if not (item is Dictionary):
		return
	var strategy: Dictionary = item
	strategy["blocked"] = blocked
	strategies[idx] = strategy
	_save_strategies()
	_render_saved_strategies()
	_refresh_demo_strategy_select()


func _render_saved_strategies() -> void:
	if saved_list == null:
		return

	for child in saved_list.get_children():
		child.queue_free()

	var total := strategies.size()
	if total == 0:
		var empty := Label.new()
		empty.text = "Nenhuma estratégia salva."
		empty.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
		saved_list.add_child(empty)
		return

	# V3.68: abrir SALVAS não executa backtest pesado em cada estratégia.
	for i in range(total - 1, -1, -1):
		var st = strategies[i]
		if not (st is Dictionary):
			continue

		var row := VBoxContainer.new()

		var title := Label.new()
		var name_text := str(st.get("name", st.get("nome", "Estratégia salva")))
		if name_text.strip_edges() == "":
			name_text = "Estratégia salva"
		title.text = name_text
		title.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
		row.add_child(title)

		var info := Label.new()
		var parts: Array[String] = []
		if st.has("gale"):
			parts.append("G" + str(st.get("gale", 0)))
		if st.has("gale_mode"):
			parts.append("MODO " + str(st.get("gale_mode", 0)))
		if st.has("consensus"):
			parts.append("CONSENSO " + str(st.get("consensus", 0)) + "%")
		if st.has("created_at"):
			parts.append(str(st.get("created_at", "")))
		info.text = " • ".join(parts)
		info.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
		row.add_child(info)

		var buttons := HBoxContainer.new()

		var use_btn := Button.new()
		use_btn.text = "USAR"
		var saved_copy: Dictionary = (st as Dictionary).duplicate(true)
		use_btn.pressed.connect(func():
			generated_strategy = saved_copy.duplicate(true)
			sim_result.text = "ESTRATÉGIA SALVA CARREGADA"
		)
		buttons.add_child(use_btn)

		var del_btn := Button.new()
		del_btn.text = "EXCLUIR"
		var remove_index := i
		del_btn.pressed.connect(func():
			if remove_index >= 0 and remove_index < strategies.size():
				strategies.remove_at(remove_index)
				_save_strategies()
				_render_saved_strategies()
		)
		buttons.add_child(del_btn)

		row.add_child(buttons)
		saved_list.add_child(row)

func _simulate_saved(idx: int) -> void:
	if idx < 0 or idx >= strategies.size():
		return
	var strategy: Dictionary = strategies[idx]
	if str(strategy.get("type", "single")) == "white":
		white_best_strategy = strategy.duplicate(true)
		if white_stake_input != null: white_stake_input.value = float(strategy.get("stake", 10.0))
		if white_bank_input != null: white_bank_input.value = float(strategy.get("initial_bank", 1000.0))
		if white_payout_input != null: white_payout_input.value = float(strategy.get("payout", 14.0))
		if white_attempts_input != null: white_attempts_input.value = float(strategy.get("attempts", 6))
		_show_page("white")
		_refresh_white_page()
		return
	var result := _simulate_strategy(strategy)
	_show_page("simulator")
	sim_result.text = _result_text(strategy, result)


func _edit_saved(idx: int) -> void:
	if idx < 0 or idx >= strategies.size():
		return
	var strategy: Dictionary = strategies[idx]
	if str(strategy.get("type", "single")) == "white":
		white_best_strategy = strategy.duplicate(true)
		if white_stake_input != null: white_stake_input.value = float(strategy.get("stake", 10.0))
		if white_bank_input != null: white_bank_input.value = float(strategy.get("initial_bank", 1000.0))
		if white_payout_input != null: white_payout_input.value = float(strategy.get("payout", 14.0))
		if white_attempts_input != null: white_attempts_input.value = float(strategy.get("attempts", 6))
		_show_page("white")
		_refresh_white_page()
		return
	_show_page("simulator")

	if str(strategy.get("type", "single")) == "ensemble":
		generated_strategy = strategy.duplicate(true)
		if auto_gale != null:
			auto_gale.select(int(strategy.get("gale", 0)))
		if auto_gale_mode != null:
			auto_gale_mode.select(int(strategy.get("gale_mode", 0)))
		var comps_value = strategy.get("components", [])
		if auto_strategy_count != null and comps_value is Array:
			var wanted_components := int(comps_value.size())
			for idx_count in range(auto_strategy_count.item_count):
				if auto_strategy_count.get_item_id(idx_count) == wanted_components:
					auto_strategy_count.select(idx_count)
					break
		sim_result.text = "Estratégia combinada carregada. Use SALVAR ESTRATÉGIA GERADA para criar outra cópia."
		return

	strategy_name.text = str(strategy.get("name", ""))
	strategy_pattern.text = _pattern_to_form(strategy.get("pattern", []))
	var entry: String = str(strategy.get("source_entry", strategy.get("entry", "R")))
	strategy_entry.select(0 if entry == "R" else 1 if entry == "B" else 2)
	if strategy_contrarian != null:
		strategy_contrarian.set_pressed_no_signal(bool(strategy.get("contrarian", false)))
	strategy_gale.select(int(strategy.get("gale", 0)))
	strategy_gale_mode.select(int(strategy.get("gale_mode", 0)))
	strategy_stake.value = float(strategy.get("stake", 10.0))
	if strategy_white_protection_enabled != null:
		strategy_white_protection_enabled.set_pressed_no_signal(
			bool(strategy.get("white_protection_enabled", false))
		)
	if strategy_white_protection_stake != null:
		strategy_white_protection_stake.value = float(
			strategy.get("white_protection_stake", 1.0)
		)
	strategy_bank.value = float(strategy.get("initial_bank", 1000.0))
	sim_result.text = "Estratégia carregada no editor. Ao salvar, será criada uma nova cópia."


func _delete_saved(idx: int) -> void:
	if idx < 0 or idx >= strategies.size():
		return
	strategies.remove_at(idx)
	_save_strategies()
	_render_saved_strategies()


func _pattern_to_form(pattern: Array) -> String:
	var out := PackedStringArray()
	for code in pattern:
		out.append(_short_name(str(code)))
	return ",".join(out)


func _short_name(code: String) -> String:
	match code:
		"R": return "V"
		"B": return "P"
		"W": return "B"
	return "?"


func _round_key(item) -> String:
	if not (item is Dictionary):
		return ""
	var d: Dictionary = item
	for key in ["id", "round_id", "uuid", "created_at", "data_hora", "timestamp"]:
		var value := str(d.get(key, ""))
		if value != "":
			return "%s:%s" % [key, value]
	return "%s|%s" % [str(d.get("numero", "")), str(d.get("cor", ""))]


func _demo_strategy_option_selected(option_idx: int) -> void:
	if demo_strategy_select == null:
		return
	if option_idx < 0 or option_idx >= demo_strategy_select.item_count:
		return
	var meta = demo_strategy_select.get_item_metadata(option_idx)
	var idx: int = int(meta) if meta != null else -1
	if idx < 0 or idx >= strategies.size():
		return
	var item = strategies[idx]
	if item is Dictionary:
		demo_pending_strategy_id = str((item as Dictionary).get("id", ""))


func _refresh_demo_strategy_select() -> void:
	if demo_strategy_select == null:
		return
	var current_id := str(demo_strategy.get("id", ""))
	# Enquanto o usuário escolhe uma nova estratégia, preserve essa escolha
	# mesmo que /demo/status seja atualizado a cada 2 segundos.
	var desired_id := demo_pending_strategy_id if demo_pending_strategy_id != "" else current_id
	demo_strategy_select.clear()
	if strategies.is_empty():
		demo_strategy_select.add_item("NENHUMA ESTRATÉGIA SALVA")
		demo_strategy_select.disabled = true
		return
	demo_strategy_select.disabled = false
	var select_idx := 0
	var visible_pos: int = 0
	for i in range(strategies.size()):
		var item = strategies[i]
		if item is Dictionary:
			var d: Dictionary = item
			if bool(d.get("blocked", false)):
				continue
			var display_name := str(d.get("name", "Estratégia %d" % (i + 1)))
			if str(d.get("type", "single")) == "white" and not display_name.begins_with("⚪"):
				display_name = "⚪ " + display_name
			demo_strategy_select.add_item(display_name)
			var option_idx: int = demo_strategy_select.item_count - 1
			demo_strategy_select.set_item_metadata(option_idx, i)
			if desired_id != "" and str(d.get("id", "")) == desired_id:
				select_idx = visible_pos
			visible_pos += 1

	if demo_strategy_select.item_count == 0:
		demo_strategy_select.add_item("NENHUMA ESTRATÉGIA ATIVA")
		demo_strategy_select.disabled = true
		return
	demo_strategy_select.select(clampi(select_idx, 0, maxi(0, demo_strategy_select.item_count - 1)))


func _demo_selected_strategy() -> Dictionary:
	if strategies.is_empty() or demo_strategy_select == null:
		return {}
	var option_idx: int = demo_strategy_select.selected
	if option_idx < 0 or option_idx >= demo_strategy_select.item_count:
		return {}
	var meta = demo_strategy_select.get_item_metadata(option_idx)
	var idx: int = int(meta) if meta != null else -1
	if idx < 0 or idx >= strategies.size():
		return {}
	var item = strategies[idx]
	if item is Dictionary and bool((item as Dictionary).get("blocked", false)):
		return {}
	return (item as Dictionary).duplicate(true) if item is Dictionary else {}


func _demo_account_changed(index: int) -> void:
	demo_current_id = "demo%d" % (index + 1)
	demo_pending_strategy_id = ""
	demo_active = false
	_demo_clear_local_view()
	_request_demo_status()


func _demo_start() -> void:
	var selected := _demo_selected_strategy()
	if selected.is_empty():
		demo_status_label.text = "Salve uma estratégia antes de iniciar a Demo."
		return
	if demo_command_busy:
		return

	demo_pending_strategy_id = str(selected.get("id", ""))
	var payload := {
		"demo_id": demo_current_id,
		"strategy": selected,
		"initial_bank": float(demo_initial_bank_input.value),
		"entry_value": float(demo_entry_input.value),
		"white_enabled": bool(demo_white_enabled_toggle.button_pressed) if demo_white_enabled_toggle != null else false,
		"contrary_signal": bool(demo_contrary_signal_toggle.button_pressed) if demo_contrary_signal_toggle != null else false,
		"white_protection_enabled": bool(demo_white_protection_toggle.button_pressed) if demo_white_protection_toggle != null else false,
		"white_protection_stake": float(demo_white_protection_stake.value) if demo_white_protection_stake != null else 1.0,
		"white_protection_payout": 14.0,
		"mirror_enabled": bool(demo_mirror_toggle.button_pressed) if demo_mirror_toggle != null else false
	}
	_demo_post("/demo/iniciar", payload)
	if demo_status_label != null:
		demo_status_label.text = "INICIANDO CONTA DEMO NO SERVIDOR 24H..."



func _demo_change_strategy() -> void:
	var selected := _demo_selected_strategy()
	if selected.is_empty():
		demo_status_label.text = "Selecione uma estratégia salva."
		return
	if not demo_active:
		demo_status_label.text = "Inicie a Demo primeiro ou use INICIAR com a estratégia escolhida."
		return
	demo_pending_strategy_id = str(selected.get("id", ""))
	_demo_post("/demo/alterar-estrategia", {
		"demo_id": demo_current_id,
		"strategy": selected
	})


func _demo_toggle_white(enabled: bool) -> void:
	if demo_command_busy or not demo_active:
		return
	_demo_post("/demo/branco-ativo", {"demo_id": demo_current_id, "enabled": enabled})

func _demo_white_protection_changed(enabled: bool) -> void:
	if demo_command_busy or not demo_active:
		return
	_demo_post("/demo/protecao-branco", {
		"demo_id": demo_current_id,
		"enabled": enabled,
		"stake": float(demo_white_protection_stake.value) if demo_white_protection_stake != null else 1.0
	})


func _demo_toggle_contrary_signal(enabled: bool) -> void:
	if demo_command_busy:
		return
	if not demo_active:
		return
	_demo_post("/demo/sinal-contrario", {
		"demo_id": demo_current_id,
		"enabled": enabled
	})


func _demo_stop() -> void:
	if demo_command_busy:
		return
	_demo_post("/demo/parar", {"demo_id": demo_current_id})


func _demo_reset() -> void:
	if demo_command_busy:
		return
	_demo_post("/demo/resetar", {"demo_id": demo_current_id})


func _demo_toggle_mirror(enabled: bool) -> void:
	if not demo_active:
		if demo_mirror_label != null:
			demo_mirror_label.text = "ESPELHO SERÁ ATIVADO AO INICIAR A DEMO" if enabled else "ESPELHO DESLIGADO\nA = sinal original • B = sinal contrário"
		return
	_demo_post("/demo/espelho", {
		"demo_id": demo_current_id,
		"enabled": enabled
	})


func _demo_post(path: String, payload: Dictionary) -> void:
	if http_demo_command == null or demo_command_busy:
		return
	demo_command_busy = true
	var headers := PackedStringArray(["Content-Type: application/json"])
	var err := http_demo_command.request(
		SERVER_BASE + path,
		headers,
		HTTPClient.METHOD_POST,
		JSON.stringify(payload)
	)
	if err != OK:
		demo_command_busy = false
		if demo_status_label != null:
			demo_status_label.text = "Falha ao enviar comando Demo ao servidor."


func _request_demo_status() -> void:
	if http_demo_status == null:
		return
	if http_demo_status.get_http_client_status() != HTTPClient.STATUS_DISCONNECTED:
		return
	http_demo_status.request(SERVER_BASE + "/demo/status?demo_id=" + demo_current_id + "&compact=1")


func _on_demo_command_completed(result: int, response_code: int, _headers: PackedStringArray, body: PackedByteArray) -> void:
	demo_command_busy = false
	if result != HTTPRequest.RESULT_SUCCESS or response_code < 200 or response_code >= 300:
		if demo_status_label != null:
			demo_status_label.text = "Servidor Demo respondeu com erro (%d)." % response_code
		return
	var parsed = JSON.parse_string(body.get_string_from_utf8())
	if parsed is Dictionary:
		var d: Dictionary = parsed
		if d.has("sessao") and d["sessao"] is Dictionary:
			_apply_demo_server_status(d["sessao"] as Dictionary)
		elif bool(d.get("resetada", false)):
			_demo_clear_local_view()
		else:
			_apply_demo_server_status(d)
	_request_demo_status()


func _on_demo_status_completed(result: int, response_code: int, _headers: PackedStringArray, body: PackedByteArray) -> void:
	if result != HTTPRequest.RESULT_SUCCESS or response_code < 200 or response_code >= 300:
		return
	var parsed = JSON.parse_string(body.get_string_from_utf8())
	if parsed is Dictionary:
		_apply_demo_server_status(parsed as Dictionary)


func _apply_demo_server_status(d: Dictionary) -> void:
	if not bool(d.get("existe", false)):
		_demo_clear_local_view()
		return
	demo_active = bool(d.get("active", false))
	var st = d.get("strategy", {})
	if st is Dictionary:
		demo_strategy = (st as Dictionary).duplicate(true)
		var server_strategy_id := str(demo_strategy.get("id", ""))
		if demo_pending_strategy_id != "" and server_strategy_id == demo_pending_strategy_id:
			demo_pending_strategy_id = ""
	demo_bank = float(d.get("bank", 1000.0))
	demo_initial_bank = float(d.get("initial_bank", 1000.0))
	demo_entry_value = float(d.get("entry_value", 10.0))
	demo_peak_bank = float(d.get("peak_bank", demo_bank))
	demo_min_bank = float(d.get("min_bank", demo_bank))
	demo_max_dd = float(d.get("max_dd", 0.0))
	demo_wins = int(d.get("wins", 0))
	demo_losses = int(d.get("losses", 0))
	var gw = d.get("gale_wins", [])
	if gw is Array:
		demo_gale_wins = gw.duplicate()
	demo_current_gale = int(d.get("current_gale", 0))
	demo_cycle_active = bool(d.get("cycle_active", false))
	demo_cycle_target = str(d.get("cycle_target", ""))
	var ops = d.get("operations", [])
	if ops is Array:
		demo_operations = ops.duplicate(true)
	demo_stop_reason = str(d.get("stop_reason", ""))
	demo_processed_rounds = int(d.get("processed_rounds", 0))
	demo_started_at = str(d.get("started_at", ""))
	demo_processed_rounds = int(d.get("processed_rounds", 0))
	demo_server_updated_at = str(d.get("server_updated_at", "-"))
	demo_server_last_round = str(d.get("server_last_round", "-"))
	demo_server_last_round_time = str(d.get("server_last_round_time", "-"))
	demo_server_updated_at = str(d.get("updated_at", "-"))
	demo_server_last_round = str(d.get("last_round_id", "-"))
	demo_server_last_round_time = str(d.get("last_round_data_hora", "-"))
	demo_server_latest_round_id = str(d.get("server_latest_round_id", "-"))
	demo_server_latest_round_time = str(d.get("server_latest_round_time", "-"))
	demo_pending_rounds = int(d.get("pending_rounds", 0))
	demo_server_synced = bool(d.get("demo_synced", false))
	demo_last_sync_text = "SERVIDOR 24H • " + demo_server_updated_at
	if demo_white_enabled_toggle != null:
		demo_white_enabled_toggle.set_pressed_no_signal(bool(d.get("white_enabled", false)))
	if demo_contrary_signal_toggle != null:
		demo_contrary_signal_toggle.set_pressed_no_signal(bool(d.get("contrary_signal", false)))
	if demo_white_protection_toggle != null:
		demo_white_protection_toggle.set_pressed_no_signal(bool(d.get("white_protection_enabled", false)))
	if demo_white_protection_stake != null:
		demo_white_protection_stake.set_value_no_signal(float(d.get("white_protection_stake", 1.0)))
	if demo_mirror_toggle != null:
		demo_mirror_toggle.set_pressed_no_signal(bool(d.get("mirror_enabled", false)))
	if demo_mirror_label != null:
		var mirror_on := bool(d.get("mirror_enabled", false))
		if mirror_on:
			var mi := float(d.get("mirror_initial_bank", demo_initial_bank))
			var ba := float(d.get("mirror_bank_a", mi))
			var bb := float(d.get("mirror_bank_b", mi))
			var ea := int(d.get("mirror_entries", 0))
			var wa := int(d.get("mirror_wins_a", 0))
			var la := int(d.get("mirror_losses_a", 0))
			var wb := int(d.get("mirror_wins_b", 0))
			var lb := int(d.get("mirror_losses_b", 0))
			var whites := int(d.get("mirror_whites", 0))
			demo_mirror_label.text = (
				"MODO ESPELHO • MESMAS ENTRADAS G0\n"
				+ "A ORIGINAL: R$ %.2f • RESULTADO %+.2f • %dW/%dL\n"
				+ "B CONTRÁRIO: R$ %.2f • RESULTADO %+.2f • %dW/%dL\n"
				+ "ENTRADAS: %d • BRANCOS: %d"
			) % [ba, ba - mi, wa, la, bb, bb - mi, wb, lb, ea, whites]
		else:
			demo_mirror_label.text = "ESPELHO DESLIGADO\nA = sinal original • B = sinal contrário"
	if demo_initial_bank_input != null and not demo_active:
		demo_initial_bank_input.value = demo_initial_bank
	if demo_entry_input != null and not demo_active:
		demo_entry_input.value = demo_entry_value
	if demo_audit_label != null:
		var original_target := str(d.get("last_original_target", ""))
		var executed_target := str(d.get("last_executed_target", ""))
		var contrary_applied := bool(d.get("last_contrary_applied", false))
		var bet_gale := int(d.get("last_bet_gale", 0))
		if original_target != "" and executed_target != "":
			var original_name := "VERMELHO" if original_target == "R" else ("PRETO" if original_target == "B" else "BRANCO")
			var executed_name := "VERMELHO" if executed_target == "R" else ("PRETO" if executed_target == "B" else "BRANCO")
			demo_audit_label.text = "SINAL ORIGINAL: %s\nSINAL CONTRÁRIO: %s\nAPOSTA EXECUTADA: %s • G%d" % [original_name, "ATIVO" if contrary_applied else "DESATIVADO", executed_name, bet_gale]
		else:
			demo_audit_label.text = (
				"AUDITORIA DO SINAL\n"
				+ "SINAL CONTRÁRIO: %s\n"
				+ "Aguardando a próxima aposta..."
			) % ("ATIVO • VERMELHO ↔ PRETO" if bool(d.get("contrary_signal", false)) else "DESATIVADO")
	_refresh_demo_strategy_select()
	_refresh_demo_ui()


func _demo_clear_local_view() -> void:
	demo_active = false
	demo_strategy.clear()
	demo_bank = float(demo_initial_bank_input.value) if demo_initial_bank_input != null else 1000.0
	demo_initial_bank = demo_bank
	demo_entry_value = float(demo_entry_input.value) if demo_entry_input != null else 10.0
	demo_peak_bank = demo_bank
	demo_min_bank = demo_bank
	demo_max_dd = 0.0
	demo_wins = 0
	demo_losses = 0
	demo_gale_wins.clear()
	demo_current_gale = 0
	demo_cycle_active = false
	demo_cycle_target = ""
	demo_operations.clear()
	demo_stop_reason = ""
	demo_processed_rounds = 0
	demo_started_at = ""
	demo_server_updated_at = "-"
	demo_server_last_round = "-"
	demo_server_last_round_time = "-"
	demo_server_latest_round_id = "-"
	demo_server_latest_round_time = "-"
	demo_pending_rounds = 0
	demo_server_synced = false
	demo_last_sync_text = "SEM SESSÃO NO SERVIDOR"
	_refresh_demo_strategy_select()
	_refresh_demo_ui()


func _demo_signal_at(index: int) -> String:
	if demo_strategy.is_empty() or index < 0 or index >= history.size():
		return ""
	var strategy_type := str(demo_strategy.get("type", "single"))
	if strategy_type == "white":
		return "W" if _white_match(index, demo_strategy) else ""
	if strategy_type == "ensemble":
		var cv = demo_strategy.get("components", [])
		if cv is Array:
			return _ensemble_signal_at(index, cv, int(demo_strategy.get("consensus_pct", 50)))
		return ""
	var pv = demo_strategy.get("pattern", [])
	if not (pv is Array):
		return ""
	var pattern: Array = pv
	if index < pattern.size():
		return ""
	if _pattern_matches(index - pattern.size(), pattern):
		return str(demo_strategy.get("entry", ""))
	return ""


func _demo_process_new_rounds() -> void:
	if not demo_active or demo_strategy.is_empty() or history.is_empty():
		return

	var start_idx: int = 0
	var catchup_count: int = 0

	if demo_last_round_key != "":
		var found := -1
		for i in range(history.size() - 1, -1, -1):
			if _round_key(history[i]) == demo_last_round_key:
				found = i
				break

		if found >= 0:
			start_idx = found + 1
		else:
			# Segurança: se a rodada-base já saiu da janela de 30000,
			# não inventa operações. Retoma da rodada atual e informa a lacuna.
			demo_last_sync_count = 0
			demo_last_sync_text = "LACUNA: rodada-base saiu do histórico disponível"
			demo_last_round_key = _round_key(history[history.size() - 1])
			_save_demo_state()
			_refresh_demo_ui()
			return

	catchup_count = maxi(0, history.size() - start_idx)

	for i in range(start_idx, history.size()):
		_demo_process_round(i)
		demo_last_round_key = _round_key(history[i])
		if not demo_active:
			break

	demo_last_sync_count = catchup_count
	if catchup_count > 0:
		demo_last_sync_text = "Sincronizadas %d rodada(s) pendente(s)" % catchup_count
	else:
		demo_last_sync_text = "Sem rodadas pendentes"

	_save_demo_state()
	_refresh_demo_ui()


func _demo_process_round(index: int) -> void:
	if not demo_active:
		return

	var is_white: bool = str(demo_strategy.get("type", "single")) == "white"
	var gale_max: int = (maxi(1, int(demo_strategy.get("attempts", 6))) - 1) if is_white else int(demo_strategy.get("gale", 0))
	var gale_mode: int = 0 if is_white else int(demo_strategy.get("gale_mode", 0))
	var demo_signal: String = _demo_signal_at(index)
	var should_bet: bool = false
	var target: String = ""

	if not demo_cycle_active:
		if demo_signal != "":
			demo_cycle_active = true
			demo_current_gale = 0
			demo_cycle_target = demo_signal
			should_bet = true
			target = demo_signal
	else:
		if gale_mode == 0:
			# Tradicional: após loss, aposta na rodada imediatamente seguinte.
			should_bet = true
			target = demo_cycle_target
		else:
			# Próximo sinal: só continua o Gale quando surgir outro sinal válido.
			if demo_signal != "":
				should_bet = true
				target = demo_signal
				demo_cycle_target = demo_signal

	if not should_bet:
		return

	# V3.80: fallback local segue exatamente a regra do servidor:
	# enquanto ativo, inverte TODA aposta R/B, inclusive G0/G1/G2...
	if demo_contrary_signal_toggle != null and demo_contrary_signal_toggle.button_pressed and target in ["R", "B"]:
		target = "B" if target == "R" else "R"

	var stake_base: float = demo_entry_value
	# Estratégia de branco usa valor FIXO em todas as tentativas.
	# Estratégias normais mantêm Gale dobrando a entrada.
	var stake: float = stake_base if is_white else stake_base * pow(2.0, demo_current_gale)

	if demo_bank < stake:
		demo_stop_reason = "BANCA INSUFICIENTE PARA G%d • precisava R$ %.2f" % [demo_current_gale, stake]
		demo_active = false
		demo_losses += 1
		demo_cycle_active = false
		_demo_add_operation(index, "STOP", target, stake, demo_current_gale, demo_stop_reason)
		return

	demo_bank -= stake
	demo_min_bank = minf(demo_min_bank, demo_bank)
	demo_max_dd = maxf(demo_max_dd, demo_peak_bank - demo_bank)

	var actual: String = _round_color(history[index])
	if actual == target:
		var payout: float = float(demo_strategy.get("payout", 14.0)) if is_white else 2.0
		demo_bank += stake * payout
		demo_peak_bank = maxf(demo_peak_bank, demo_bank)
		demo_wins += 1
		if demo_current_gale < demo_gale_wins.size():
			demo_gale_wins[demo_current_gale] += 1
		demo_recent_results.append(true)
		_demo_add_operation(index, "WIN", target, stake, demo_current_gale, "")
		demo_cycle_active = false
		demo_current_gale = 0
		demo_cycle_target = ""
	else:
		_demo_add_operation(index, "LOSS TENTATIVA", target, stake, demo_current_gale, "")
		if demo_current_gale >= gale_max:
			demo_losses += 1
			demo_recent_results.append(false)
			demo_cycle_active = false
			demo_current_gale = 0
			demo_cycle_target = ""
		else:
			demo_current_gale += 1

	# Gestão de risco salva na estratégia.
	var risk_reason := _risk_stop_reason(demo_strategy, demo_bank, demo_peak_bank, demo_recent_results)
	if risk_reason != "":
		demo_stop_reason = risk_reason
		demo_active = false
		_demo_add_operation(index, "STOP", target, 0.0, demo_current_gale, risk_reason)


func _demo_add_operation(index: int, kind: String, target: String, stake: float, gale: int, reason: String) -> void:
	var d: Dictionary = history[index] if index >= 0 and index < history.size() and history[index] is Dictionary else {}
	demo_operations.push_front({
		"time": str(d.get("data_hora", d.get("created_at", d.get("timestamp", "-")))),
		"kind": kind,
		"target": target,
		"official": str(d.get("cor", "")),
		"stake": stake,
		"gale": gale,
		"bank": demo_bank,
		"reason": reason
	})
	while demo_operations.size() > 200:
		demo_operations.pop_back()


func _demo_gale_stats() -> String:
	var out := PackedStringArray()
	for g in range(demo_gale_wins.size()):
		out.append("%s: %d WIN" % ["G0" if g == 0 else "G%d" % g, int(demo_gale_wins[g])])
	return " • ".join(out)


func _refresh_demo_ui() -> void:
	if demo_status_label == null:
		return

	var name := str(demo_strategy.get("name", "Nenhuma"))
	var is_white: bool = str(demo_strategy.get("type", "single")) == "white"
	var mode := "BRANCO • TENTATIVAS FIXAS" if is_white else _gale_mode_name(int(demo_strategy.get("gale_mode", 0)))
	var gale_max: int = (maxi(1, int(demo_strategy.get("attempts", 6))) - 1) if is_white else int(demo_strategy.get("gale", 0))
	var result_value: float = demo_bank - demo_initial_bank
	var total: int = demo_wins + demo_losses
	var rate: float = 100.0 * float(demo_wins) / float(total) if total > 0 else 0.0

	# Cabeçalho financeiro
	if demo_profit_label != null:
		demo_profit_label.text = (
			"BANCA R$ %.2f  •  RESULTADO R$ %+.2f"
			% [demo_bank, result_value]
		)
		demo_profit_label.add_theme_color_override(
			"font_color",
			green if result_value >= 0.0 else red
		)

	if demo_server_info_label != null:
		demo_server_info_label.text = (
			"STATUS: %s\n"
			+ "Início: %s\n"
			+ "Última atualização da Demo: %s\n"
			+ "Última rodada processada: %s • %s\n"
			+ "Última rodada no servidor: %s • %s\n"
			+ "SINCRONIA: %s"
		) % [
			"RODANDO 24H" if demo_active else "PARADA",
			demo_started_at if demo_started_at != "" else "-",
			demo_server_updated_at,
			demo_server_last_round_time,
			demo_server_last_round,
			demo_server_latest_round_time,
			demo_server_latest_round_id,
			"OK • 0 PENDENTES" if demo_server_synced else ("%d PENDENTE(S)" % demo_pending_rounds)
		]

	# Status da estratégia
	var mode_detail := (
		"%s • %d tentativas • retorno %.1fx" % [mode, gale_max + 1, float(demo_strategy.get("payout", 14.0))]
		if is_white else "%s • Máximo G%d" % [mode, gale_max]
	)
	demo_status_label.text = (
		"%s\n"
		+ "Estratégia: %s\n"
		+ "Modo: %s\n"
		+ "Entrada base: R$ %.2f\n"
		+ "Branco: %s\n"
		+ "Sinal contrário: %s"
	) % [
		"● SERVIDOR 24H ATIVO" if demo_active else "○ SESSÃO PARADA",
		name,
		mode_detail,
		demo_entry_value,
		"LIGADO" if (demo_white_enabled_toggle == null or demo_white_enabled_toggle.button_pressed) else "DESLIGADO",
		"ATIVO • R ↔ P EM G0/G1/G2..." if (demo_contrary_signal_toggle != null and demo_contrary_signal_toggle.button_pressed) else "DESATIVADO"
	]
	demo_status_label.add_theme_color_override(
		"font_color",
		green if demo_active else muted
	)

	# Próxima ação
	var next_stake: float = demo_entry_value if is_white else demo_entry_value * pow(2.0, demo_current_gale)
	if demo_cycle_active:
		var target_name := _color_name(demo_cycle_target) if demo_cycle_target != "" else "AGUARDANDO NOVO SINAL"
		demo_signal_label.text = "PRÓXIMA AÇÃO • G%d • %s" % [
			demo_current_gale,
			target_name
		]
		if demo_current_operation_label != null:
			demo_current_operation_label.text = (
				"Valor previsto: R$ %.2f\n"
				+ "Ciclo ativo: SIM\n"
				+ "Se o modo for PRÓXIMO SINAL, o servidor espera outro sinal válido antes do próximo Gale."
			) % next_stake
	else:
		demo_signal_label.text = "AGUARDANDO NOVO SINAL"
		if demo_current_operation_label != null:
			demo_current_operation_label.text = (
				"Ciclo ativo: NÃO\n"
				+ "Próxima entrada base: R$ %.2f"
			) % demo_entry_value

	# Placar
	demo_stats_label.text = (
		"WIN %d  •  LOSS %d  •  ACERTO %.2f%%\n"
		+ "BANCA INICIAL: R$ %.2f\n"
		+ "BANCA ATUAL: R$ %.2f\n"
		+ "LUCRO/PREJUÍZO: R$ %+.2f\n"
		+ "MAIOR BANCA: R$ %.2f\n"
		+ "MENOR BANCA: R$ %.2f\n"
		+ "DRAWDOWN MÁX.: R$ %.2f\n"
		+ "GALE ATUAL: G%d / G%d\n"
		+ "%s\n"
		+ "STOP: %s"
	) % [
		demo_wins,
		demo_losses,
		rate,
		demo_initial_bank,
		demo_bank,
		result_value,
		demo_peak_bank,
		demo_min_bank,
		demo_max_dd,
		demo_current_gale,
		gale_max,
		_demo_gale_stats(),
		demo_stop_reason if demo_stop_reason != "" else "NÃO"
	]

	if demo_rounds_label != null:
		demo_rounds_label.text = (
			"RODADAS PROCESSADAS PELO SERVIDOR: %d"
			% demo_processed_rounds
		)

	# Histórico vindo do backend
	var lines := PackedStringArray()
	for i in range(mini(50, demo_operations.size())):
		var op = demo_operations[i]
		if not (op is Dictionary):
			continue
		var d: Dictionary = op

		var kind := str(d.get("kind", d.get("tipo", "-")))
		var target := str(d.get("target", d.get("alvo", "")))
		var official := str(d.get("official", d.get("resultado", "")))
		var stake := float(d.get("stake", 0.0))
		var gale := int(d.get("gale", 0))
		var bank := float(d.get("bank", d.get("banca", demo_bank)))
		var when := str(d.get("time", d.get("data_hora", "-")))
		var reason := str(d.get("reason", d.get("motivo", "")))
		var original := str(d.get("sinal_original", ""))
		var executed := str(d.get("sinal_executado", target))
		var contrary_used := bool(d.get("sinal_contrario_ativo", false))

		var icon := "✅" if kind.contains("WIN") else ("⛔" if kind.contains("STOP") else "❌")
		var audit_line := ""
		if original != "" and executed != "":
			audit_line = (
				"Sinal original: %s → Executado: %s • Contrário: %s\n"
				% [_color_name(original), _color_name(executed), "SIM" if contrary_used else "NÃO"]
			)
		var op_text := (
			"%s %s • %s\n"
			+ audit_line
			+ "Entrada: %s • G%d • R$ %.2f\n"
			+ "Resultado: %s • Banca R$ %.2f%s"
		) % [
			icon,
			kind,
			when,
			_color_name(target),
			gale,
			stake,
			_color_name(official),
			bank,
			("\nMotivo: " + reason) if reason != "" else ""
		]
		lines.append(op_text)

	demo_history_label.text = (
		"\n\n".join(lines)
		if lines.size() > 0
		else "Nenhuma operação registrada pelo servidor."
	)


func _save_demo_state() -> void:
	var file := FileAccess.open(DEMO_FILE, FileAccess.WRITE)
	if file == null:
		return
	file.store_string(JSON.stringify({
		"active": demo_active,
		"strategy": demo_strategy,
		"bank": demo_bank,
		"initial_bank": demo_initial_bank,
		"entry_value": demo_entry_value,
		"peak_bank": demo_peak_bank,
		"min_bank": demo_min_bank,
		"max_dd": demo_max_dd,
		"wins": demo_wins,
		"losses": demo_losses,
		"gale_wins": demo_gale_wins,
		"current_gale": demo_current_gale,
		"cycle_active": demo_cycle_active,
		"cycle_target": demo_cycle_target,
		"last_round_key": demo_last_round_key,
		"operations": demo_operations,
		"recent_results": demo_recent_results,
		"stop_reason": demo_stop_reason,
		"last_sync_count": demo_last_sync_count,
		"last_sync_text": demo_last_sync_text,
		"started_at": demo_started_at,
		"processed_rounds": demo_processed_rounds,
		"server_updated_at": demo_server_updated_at,
		"server_last_round": demo_server_last_round,
		"server_last_round_time": demo_server_last_round_time
	}))
	file.close()


func _load_demo_state() -> void:
	if not FileAccess.file_exists(DEMO_FILE):
		return
	var file := FileAccess.open(DEMO_FILE, FileAccess.READ)
	if file == null:
		return
	var parsed = JSON.parse_string(file.get_as_text())
	file.close()
	if not (parsed is Dictionary):
		return
	var d: Dictionary = parsed
	demo_active = bool(d.get("active", false))
	var st = d.get("strategy", {})
	if st is Dictionary:
		demo_strategy = st.duplicate(true)
	demo_bank = float(d.get("bank", 1000.0))
	demo_initial_bank = float(d.get("initial_bank", 1000.0))
	demo_entry_value = float(d.get("entry_value", 10.0))
	demo_peak_bank = float(d.get("peak_bank", demo_bank))
	demo_min_bank = float(d.get("min_bank", demo_bank))
	demo_max_dd = float(d.get("max_dd", 0.0))
	demo_wins = int(d.get("wins", 0))
	demo_losses = int(d.get("losses", 0))
	var gw = d.get("gale_wins", [])
	if gw is Array: demo_gale_wins = gw.duplicate()
	demo_current_gale = int(d.get("current_gale", 0))
	demo_cycle_active = bool(d.get("cycle_active", false))
	demo_cycle_target = str(d.get("cycle_target", ""))
	demo_last_round_key = str(d.get("last_round_key", ""))
	var ops = d.get("operations", [])
	if ops is Array: demo_operations = ops.duplicate(true)
	var rr = d.get("recent_results", [])
	if rr is Array: demo_recent_results = rr.duplicate()
	demo_stop_reason = str(d.get("stop_reason", ""))
	demo_last_sync_count = int(d.get("last_sync_count", 0))
	demo_last_sync_text = str(d.get("last_sync_text", "-"))
	demo_started_at = str(d.get("started_at", ""))


func _save_strategies() -> void:
	var file := FileAccess.open(STRATEGY_FILE, FileAccess.WRITE)
	if file == null:
		return
	file.store_string(JSON.stringify({"strategies": strategies}))
	file.flush()
	file.close()
	_refresh_demo_strategy_select()


func _load_strategies() -> void:
	strategies.clear()
	if not FileAccess.file_exists(STRATEGY_FILE):
		return
	var file := FileAccess.open(STRATEGY_FILE, FileAccess.READ)
	if file == null:
		return
	var parsed = JSON.parse_string(file.get_as_text())
	file.close()
	if parsed is Dictionary:
		var rows = (parsed as Dictionary).get("strategies", [])
		if rows is Array:
			strategies = rows.duplicate(true)
			for i in range(strategies.size()):
				if strategies[i] is Dictionary:
					var s: Dictionary = strategies[i]
					if not s.has("blocked"):
						s["blocked"] = false
					strategies[i] = s


func _render_history() -> void:
	for child in list_box.get_children():
		child.queue_free()

	if history.is_empty():
		var empty := _label("Nenhuma rodada recebida.", 22, false)
		empty.add_theme_color_override("font_color", muted)
		list_box.add_child(empty)
		load_more_button.visible = false
		return

	var total := history.size()
	var start := maxi(0, total - visible_count)

	for i in range(total - 1, start - 1, -1):
		var item = history[i]
		if item is Dictionary:
			_add_round_row(item as Dictionary, i + 1)

	load_more_button.visible = visible_count < total
	load_more_button.text = "CARREGAR MAIS • %d DE %d" % [mini(visible_count, total), total]


func _add_round_row(d: Dictionary, position: int) -> void:
	var code := str(d.get("cor", ""))
	var number := str(d.get("numero", "-"))
	var dt := str(d.get("data_hora", d.get("created_at", d.get("timestamp", "-"))))
	var accent := _color_for(code)

	var panel := PanelContainer.new()
	panel.add_theme_stylebox_override("panel", _panel_style(surface, accent, 12))
	list_box.add_child(panel)

	var margin := MarginContainer.new()
	margin.add_theme_constant_override("margin_left", 14)
	margin.add_theme_constant_override("margin_right", 14)
	margin.add_theme_constant_override("margin_top", 9)
	margin.add_theme_constant_override("margin_bottom", 9)
	panel.add_child(margin)

	var row := HBoxContainer.new()
	row.add_theme_constant_override("separation", 12)
	margin.add_child(row)

	var ball := Label.new()
	ball.text = number
	ball.custom_minimum_size = Vector2(62, 50)
	ball.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	ball.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	ball.add_theme_font_size_override("font_size", 23)
	ball.add_theme_color_override("font_color", Color("#06080C") if code == "W" else Color.WHITE)
	ball.add_theme_stylebox_override("normal", _pill_style(accent))
	row.add_child(ball)

	var info := VBoxContainer.new()
	info.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	row.add_child(info)

	var color_name := _label(_color_name(code), 20, true)
	color_name.add_theme_color_override("font_color", accent)
	info.add_child(color_name)

	var time_label := _label(dt, 16, false)
	time_label.add_theme_color_override("font_color", muted)
	info.add_child(time_label)

	var index_label := _label("#%d" % position, 15, false)
	index_label.add_theme_color_override("font_color", muted)
	row.add_child(index_label)


func _load_more() -> void:
	visible_count = mini(history.size(), visible_count + PAGE_SIZE)
	var old_scroll := history_scroll.scroll_vertical
	_render_history()
	await get_tree().process_frame
	history_scroll.scroll_vertical = old_scroll


func _set_offline(message: String) -> void:
	status_label.text = message
	status_label.add_theme_color_override("font_color", red)


func _mini_card(parent: HBoxContainer, caption: String) -> VBoxContainer:
	var panel := PanelContainer.new()
	panel.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	panel.add_theme_stylebox_override("panel", _panel_style(surface, border, 14))
	parent.add_child(panel)

	var margin := MarginContainer.new()
	margin.add_theme_constant_override("margin_left", 13)
	margin.add_theme_constant_override("margin_right", 13)
	margin.add_theme_constant_override("margin_top", 11)
	margin.add_theme_constant_override("margin_bottom", 11)
	panel.add_child(margin)

	var box := VBoxContainer.new()
	margin.add_child(box)

	var cap := _label(caption, 14, false)
	cap.add_theme_color_override("font_color", muted)
	box.add_child(cap)
	return box


func _card(parent: VBoxContainer, caption: String, accent: Color) -> VBoxContainer:
	var panel := PanelContainer.new()
	panel.add_theme_stylebox_override("panel", _panel_style(surface, accent, 14))
	parent.add_child(panel)

	var margin := MarginContainer.new()
	margin.add_theme_constant_override("margin_left", 14)
	margin.add_theme_constant_override("margin_right", 14)
	margin.add_theme_constant_override("margin_top", 12)
	margin.add_theme_constant_override("margin_bottom", 12)
	panel.add_child(margin)

	var box := VBoxContainer.new()
	box.add_theme_constant_override("separation", 8)
	margin.add_child(box)

	var cap := _label(caption, 16, true)
	cap.add_theme_color_override("font_color", accent)
	box.add_child(cap)
	return box


func _label(value: String, size: int, bold: bool) -> Label:
	var l := Label.new()
	l.text = value
	l.add_theme_font_size_override("font_size", size)
	l.add_theme_color_override("font_color", text if bold else muted)
	return l


func _button(caption: String) -> Button:
	var b := Button.new()
	b.text = caption
	b.custom_minimum_size.y = 58
	b.add_theme_font_size_override("font_size", 19)
	b.add_theme_stylebox_override("normal", _button_style(surface_2, border))
	return b


func stake_styling(spin: SpinBox) -> void:
	spin.add_theme_font_size_override("font_size", 20)


func _color_name(code: String) -> String:
	match code:
		"R": return "VERMELHO"
		"B": return "PRETO"
		"W": return "BRANCO"
	return "DESCONHECIDO"


func _color_for(code: String) -> Color:
	match code:
		"R": return red
		"B": return black_color
		"W": return white_color
	return muted


func _panel_style(fill: Color, outline: Color, radius: int) -> StyleBoxFlat:
	var s := StyleBoxFlat.new()
	s.bg_color = fill
	s.border_color = outline
	s.set_border_width_all(1)
	s.corner_radius_top_left = radius
	s.corner_radius_top_right = radius
	s.corner_radius_bottom_left = radius
	s.corner_radius_bottom_right = radius
	return s


func _button_style(fill: Color, outline: Color) -> StyleBoxFlat:
	var s := _panel_style(fill, outline, 12)
	s.content_margin_left = 14
	s.content_margin_right = 14
	s.content_margin_top = 10
	s.content_margin_bottom = 10
	return s


func _pill_style(fill: Color) -> StyleBoxFlat:
	var s := StyleBoxFlat.new()
	s.bg_color = fill
	s.corner_radius_top_left = 25
	s.corner_radius_top_right = 25
	s.corner_radius_bottom_left = 25
	s.corner_radius_bottom_right = 25
	return s
