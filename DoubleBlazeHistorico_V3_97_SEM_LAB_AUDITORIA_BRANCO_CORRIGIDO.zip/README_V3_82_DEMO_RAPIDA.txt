V3.82 — DEMO RÁPIDA

- Atualização da Demo a cada 2 segundos quando a aba Demo estiver aberta.
- Não consulta a Demo em segundo plano quando outra aba está ativa.
- Usa /demo/status?compact=1 para reduzir drasticamente o JSON.
- O servidor não reordena até 30.000 rodadas a cada consulta da Demo.
- Operações retornadas no status rápido: últimas 40.
- Campos internos grandes não são enviados no polling.
- Histórico, coleta, PostgreSQL, otimizador, objetivo lucro/prejuízo e lógica da Demo permanecem iguais.
Backend correspondente: V58.14.
