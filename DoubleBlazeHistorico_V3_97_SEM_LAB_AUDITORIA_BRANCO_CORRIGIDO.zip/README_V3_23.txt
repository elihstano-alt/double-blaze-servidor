V3.23 - DEMO: TROCA DE ESTRATEGIA + LIGA/DESLIGA BRANCO

- O seletor de estrategia permanece liberado com a Demo rodando.
- Novo botao APLICAR / TROCAR ESTRATEGIA: muda a estrategia sem resetar banca, WIN/LOSS, lucro ou historico.
- Ao trocar, um Gale/tentativa pendente da estrategia anterior e cancelado para nao misturar regras.
- Novo controle ESTRATEGIA DO BRANCO ATIVADA.
- Ao desligar, uma sequencia branca pendente e cancelada sem registrar LOSS e nao abre novas entradas de branco.
- Ao ligar novamente, a estrategia branca selecionada volta a procurar novas condicoes.
- Requer deploy do servidor_v54_3_demo_troca_estrategia.py no Render.
