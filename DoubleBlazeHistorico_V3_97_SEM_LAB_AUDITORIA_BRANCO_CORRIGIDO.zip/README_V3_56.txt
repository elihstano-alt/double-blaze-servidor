DOUBLE BLAZE HISTÓRICO V3.56 — 2044 ESTRATÉGIAS PRÉ-GERADAS

- As 2.044 estratégias-base V/P de tamanho 1..9 já vêm prontas no projeto.
- Arquivo: res://data/strategies_base_2044.json
- O app não precisa reconstruir os 2.044 padrões toda vez.
- Ao otimizar, carrega imediatamente a biblioteca pronta.
- Depois ainda avalia as estratégias no histórico atual, porque lucro, acerto,
  drawdown e ranking mudam quando entram novas rodadas.
- A tela diferencia BASE PRÉ-GERADA de AVALIANDO NO HISTÓRICO ATUAL.
- Mantida busca exata, Aposta Contrária e demais funções.
- Servidor Python/Render NÃO alterado.
