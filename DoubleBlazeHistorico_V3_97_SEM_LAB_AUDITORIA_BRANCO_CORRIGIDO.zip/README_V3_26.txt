V3.26 — AUDITORIA VISÍVEL DE CONTINUIDADE

- Mostra CONTINUIDADE, LACUNAS e VALIDADO diretamente na aba HISTÓRICO.
- Se 0 lacunas e bruto = validado, exibe CONTINUIDADE: 100%.
- Se houver lacuna, mantém apenas o trecho contínuo mais recente para análise/backtest.
- O servidor já audita toda a base cronologicamente; esta versão torna o resultado explícito no app.
- Janela estatística continua em 5000 rodadas.
