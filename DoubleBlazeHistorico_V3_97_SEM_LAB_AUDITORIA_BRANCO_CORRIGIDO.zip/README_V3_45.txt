DOUBLE BLAZE HISTÓRICO V3.45 — EQUILÍBRIO COM GALE CONFIGURÁVEL

Na aba EQUILÍBRIO:
- Pode deixar o GALE em automático (testa G0 até G11) ou fixar exatamente G0...G11.
- Pode deixar o MODO DO GALE em automático ou escolher:
  tradicional, próximo sinal, pular 1-9 rodadas, pular 1-9 sinais.
- O algoritmo continua relacionando lucro, drawdown e efetividade pelos pesos escolhidos.
- O resultado mostra Gale e modo vencedores.
- Não altera servidor Python/Render.
