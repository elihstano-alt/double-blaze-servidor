DOUBLE BLAZE HISTÓRICO V3.44 — ABA EQUILÍBRIO

Nova aba EQUILÍBRIO:
- Separada do OTIMIZADOR tradicional.
- Relação configurável entre LUCRO, DRAWDOWN e EFETIVIDADE.
- Pesos padrão: 45% lucro / 35% drawdown / 20% acerto.
- Nota = lucro percentual ponderado + taxa de acerto ponderada - drawdown percentual ponderado.
- Busca completa em G0-G11, modos de Gale, 1-30 estratégias e consensos 50-100%.
- Desempate por menor drawdown e depois maior lucro.
- Permite salvar a estratégia de equilíbrio.
- Respeita estratégias BLOQUEADAS.
- Scroll touch incluído na nova aba.
- Nenhuma alteração no servidor Python/Render.
