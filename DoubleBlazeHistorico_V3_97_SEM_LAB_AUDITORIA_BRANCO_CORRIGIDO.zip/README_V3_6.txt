V3.6 — ESTATÍSTICAS POR GALE

Agora cada simulação mostra quantos WIN aconteceram em cada nível:
- SEM GALE / G0
- G1
- G2
- ...
- até o Gale máximo escolhido na estratégia

Exemplo:
SEM GALE (G0): 42 WIN
GALE 1 (G1): 18 WIN
GALE 2 (G2): 7 WIN
LOSS FINAL: permanece no total de LOSS

As estratégias salvas também exibem esse detalhamento.
Funciona tanto para estratégias simples quanto para estratégias combinadas.
