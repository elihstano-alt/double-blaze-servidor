V3.7 — CÁLCULO PRECISO DE GALE / DRAWDOWN

Correção crítica:
A versão anterior atualizava o drawdown principalmente no fim do ciclo.
Agora o drawdown é atualizado depois de CADA débito de aposta dentro do Gale.

Também:
- não permite stake maior que a banca disponível;
- registra maior Gale realmente atingido;
- registra maior aposta individual;
- registra maior exposição acumulada em um único ciclo;
- registra menor banca observada;
- registra ciclos interrompidos por banca insuficiente;
- mantém WIN por G0/G1/.../Gale escolhido.

Exemplo matemático com entrada base R$10:
G0 = 10
G1 = 20
G2 = 40
G3 = 80
G4 = 160
G5 = 320
G6 = 640
G7 = 1280
G8 = 2560

Com banca de R$1000, uma progressão 2x jamais consegue executar G7/G8 sem capital
adicional. Agora o simulador interrompe o ciclo quando a banca não cobre a stake.
