DOUBLE BLAZE HISTÓRICO V3.49 — EXATO MÁXIMO

Objetivo: acelerar o modo EXATO sem eliminar nenhuma configuração.

- Todas as quantidades permitidas continuam sendo avaliadas no modo EXATO.
- Nenhum pré-filtro aproximado foi adicionado ao modo EXATO.
- Sinais individuais são pré-calculados e reutilizados.
- Cache exato de resultados agora é compartilhado entre quantidades dentro do mesmo Gale/modo.
- Se duas configurações geram exatamente a mesma sequência de sinais, a simulação é reaproveitada.
- Menos atualizações visuais durante o processamento no Android.
- Modo RÁPIDO continua opcional e separado.
- Servidor Python/Render NÃO alterado.
