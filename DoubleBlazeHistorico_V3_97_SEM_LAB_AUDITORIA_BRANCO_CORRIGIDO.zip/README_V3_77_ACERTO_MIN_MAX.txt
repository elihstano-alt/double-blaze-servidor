DOUBLE BLAZE V3.77 — ACERTO MÍNIMO / MÁXIMO

OTIMIZADOR:
- ACERTO MÍNIMO: aceita taxa >= valor.
- ACERTO MÁXIMO: aceita taxa <= valor.
- Ex.: MÁXIMO 20% permite estratégias entre 0% e 20%.
- Estratégia negativa financeiramente continua concorrendo; prejuízo não a elimina sozinho.
- Entre as estratégias válidas, vence o maior lucro; empate = menor drawdown.
- Demais configurações preservadas.
- Requer backend V58.1.
