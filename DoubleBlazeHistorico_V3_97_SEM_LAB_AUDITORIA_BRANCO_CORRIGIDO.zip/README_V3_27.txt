V3.27 — PRESERVA BASE VALIDADA + CONTADOR CORRIGIDO

- Corrige o texto VALIDADO: agora mostra o número real (ex.: 1533/5000).
- Em novo deploy, o servidor restaura a base do PostgreSQL e NÃO refaz o bootstrap se ela já estiver 100% contínua e tiver >=1500 rodadas.
- Assim uma base validada não volta para 1500 a cada atualização.
- Continua crescendo até 5000 e depois mantém janela deslizante das 5000 mais recentes.
- Auditoria de continuidade e isolamento de lacunas permanecem ativos.
