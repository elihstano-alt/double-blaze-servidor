DOUBLE BLAZE HISTÓRICO V3.42 — BASE 30.000

- Base estatística do app alterada de 5.000 para 30.000.
- Tela passa a exibir crescimento progressivo: 5000/30000, 5001/30000 ... 30000/30000.
- Histórico deixa de tratar 5.000 como teto visual.
- Requisições de histórico passam a aceitar até 30.000 rodadas.
- Mantém V3.41: porcentagem mínima de acerto configurável.
- Mantém V3.40: drawdown nas salvas + scroll touch.
- Mantém V3.39: otimizador Ultra Exato.
- Servidor esperado: V55.8 janela 30.000.
