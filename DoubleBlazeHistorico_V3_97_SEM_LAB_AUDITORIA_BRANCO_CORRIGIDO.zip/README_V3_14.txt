V3.14 — CONTA DEMO AO VIVO

- Nova aba DEMO.
- Escolhe qualquer estratégia salva.
- Banca inicial Demo configurável.
- Iniciar / Parar / Resetar.
- A sessão começa nas rodadas NOVAS após apertar Iniciar.
- Usa o nosso servidor já configurado.
- Gale Tradicional e Gale no Próximo Sinal.
- G0...Gale configurado na estratégia.
- Banca, lucro, WIN/LOSS, taxa de acerto, maior/menor banca e drawdown.
- WIN por nível de Gale.
- Gestão de risco da estratégia respeitada.
- Histórico das últimas 200 operações.
- Estado persistido em user://conta_demo_v314.json.
- Não realiza aposta real.
