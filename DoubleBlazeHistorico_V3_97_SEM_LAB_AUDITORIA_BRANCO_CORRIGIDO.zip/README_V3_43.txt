DOUBLE BLAZE HISTÓRICO V3.43 — BRANCO MANUAL + BLOQUEADAS

Correções e novidades:
- Estratégia do BRANCO não liga mais sozinha.
- Toggle de branco inicia DESLIGADO.
- Ao iniciar uma Demo, o estado atual do toggle é enviado ao servidor.
- Servidor V55.9 persiste esse estado e não usa mais true como padrão.
- SALVAS ganhou duas abas: ATIVAS e BLOQUEADAS.
- Cada estratégia pode ser BLOQUEADA ou DESBLOQUEADA.
- Estratégias bloqueadas não aparecem na seleção da Demo.
- O Otimizador deixa de gerar novamente a mesma lógica exata de uma estratégia bloqueada.
- Estratégias bloqueadas continuam preservadas e podem ser desbloqueadas quando quiser.
- Mantém base 30.000, drawdown, scroll touch e porcentagem mínima de acerto.

Arquivos:
- Projeto Godot V3.43
- server_update/servidor.py = V55.9 para Render
