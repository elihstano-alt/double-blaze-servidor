V3.15 — ENTRADA DEMO + STOP WIN

CONTA DEMO
- Valor da entrada Demo agora é editável.
- A entrada Demo substitui o stake salvo da estratégia somente durante a sessão Demo.
- O valor fica salvo junto do estado da conta Demo.
- Placar mostra o valor atual da entrada Demo.

GERADOR DE ESTRATÉGIAS
- Novo ATIVAR STOP WIN NA ESTRATÉGIA GERADA.
- Stop Win definido em lucro R$ acima da banca inicial.
- Ex.: banca R$1.000 + Stop Win R$500 => encerra novas entradas ao atingir R$1.500 ou mais.
- O Stop Win participa da simulação das estratégias geradas e do otimizador.
- Pode ser ligado/desligado.
