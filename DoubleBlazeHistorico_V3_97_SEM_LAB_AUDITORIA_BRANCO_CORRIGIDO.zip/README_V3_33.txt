V3.33 — TENTATIVAS DO BRANCO NA GERAÇÃO DA ESTRATÉGIA

- O número de tentativas é escolhido na aba BRANCO, antes de GERAR MELHOR.
- A configuração de tentativas passa a fazer parte da estratégia salva.
- A DEMO não altera mais o número de tentativas do branco.
- Ao trocar de estratégia na DEMO, ela passa a usar exatamente as tentativas salvas naquela estratégia.
- A aposta por tentativa continua fixa.
- Limite disponível: 1 a 20 tentativas.
