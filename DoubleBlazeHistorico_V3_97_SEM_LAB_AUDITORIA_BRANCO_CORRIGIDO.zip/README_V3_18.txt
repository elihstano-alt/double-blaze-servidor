V3.18 — PAINEL CONTA DEMO 24H

A aba DEMO foi transformada em painel do backend 24h.

Mostra:
- status Rodando/Parada;
- banca atual e resultado;
- estratégia em execução;
- Gale tradicional ou próximo sinal;
- Gale atual e próximo valor previsto;
- WIN / LOSS / taxa de acerto;
- banca inicial, maior e menor banca;
- drawdown máximo;
- WIN por nível de Gale;
- Stop acionado;
- total de rodadas processadas no servidor;
- início da sessão;
- última atualização;
- última rodada processada;
- últimas 50 operações do backend.

A atualização continua automática pelo timer do app e há botão
"ATUALIZAR PAINEL AGORA".

O cálculo permanece no servidor Render 24h; o app é o painel de controle.
