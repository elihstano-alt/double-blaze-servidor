V3.76 - Servidor migrado para Railway
Base: V3.75 OTIMIZADOR NAO PARA NO MEIO
SERVER_BASE: https://web-production-25658.up.railway.app
Backend incluído no pacote não foi alterado.
