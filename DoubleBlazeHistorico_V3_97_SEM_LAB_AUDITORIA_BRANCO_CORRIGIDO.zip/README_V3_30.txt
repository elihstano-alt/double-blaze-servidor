V3.30 — 7 CONTAS DEMO SIMULTÂNEAS

- Seletor DEMO 1 até DEMO 7 na aba DEMO.
- Cada conta possui sessão independente no servidor 24h.
- Cada conta pode usar uma estratégia salva diferente.
- Banca, entrada, WIN/LOSS, Gale, histórico e estratégia de branco são independentes por conta.
- Trocar de DEMO no app apenas muda o painel visualizado; as outras continuam rodando no servidor.
- O backend já utiliza demo_id persistente no PostgreSQL, agora a interface usa demo1..demo7.
