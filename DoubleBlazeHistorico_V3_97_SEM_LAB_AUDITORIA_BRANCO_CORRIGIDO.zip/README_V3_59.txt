V3.59 — CORREÇÃO ESPECÍFICA DA TRAVA EM 2044/2044

Diagnóstico:
A captura mostra que a avaliação chegou a 2044/2044 e 1560 válidas.
Depois desse ponto o código fazia candidates.sort_custom() de forma síncrona,
sem nenhum await/process_frame. Portanto a interface podia ficar congelada
exatamente nessa mensagem.

Correção:
- substituída a ordenação síncrona por merge sort incremental;
- mesma prioridade: maior lucro, depois maior taxa de acerto;
- nenhuma estratégia descartada;
- progresso de ordenação aparece na tela;
- yield a cada passada da ordenação;
- depois mostra INICIANDO VARREDURA DAS CONFIGURAÇÕES;
- busca exata permanece;
- PY/Render não alterado.
