V3.20 — BRANCO COM ATÉ 6 TENTATIVAS

Correção do backtest do BRANCO:
- cada sinal é 1 entrada completa;
- por padrão cada entrada tem até 6 tentativas consecutivas;
- cada tentativa aposta o valor configurado em ENTRADA R$;
- se o branco sair, o ciclo termina em 1 WIN;
- se não sair em nenhuma das 6 tentativas, o ciclo termina em 1 LOSS;
- com entrada de R$10 e 6 tentativas, uma LOSS completa custa R$60;
- o lucro considera o número real de tentativas usadas até o WIN;
- o drawdown é atualizado após cada débito de tentativa;
- entradas não se sobrepõem às rodadas já consumidas pelo mesmo ciclo;
- adicionada configuração TENTATIVAS na aba BRANCO (padrão 6).

Exemplos com R$10 e retorno 14x:
- WIN na tentativa 1: +R$130 líquido;
- WIN na tentativa 2: +R$120 líquido;
- WIN na tentativa 6: +R$80 líquido;
- LOSS após 6 tentativas: -R$60.

Backtest histórico não garante resultado futuro.
