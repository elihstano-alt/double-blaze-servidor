V3.43.1 CORRIGIDA
- Corrigido Parser Error da variável processed no otimizador.
- Mantidas as funções da V3.43.
- Nenhuma nova alteração no servidor Python.
