DOUBLE BLAZE HISTÓRICO + SIMULADOR — V2

NOVIDADES
- Aba HISTÓRICO: mantém o histórico deslizante do nosso servidor.
- Aba SIMULADOR: você cria manualmente a estratégia.
- Aba SALVAS: várias estratégias podem ser guardadas com nome próprio.

CRIADOR
Padrão usa:
V = Vermelho
P = Preto
B = Branco

Exemplo:
Padrão V,P,V
Entrada PRETO
Máximo G1
Entrada R$ 10

O simulador procura todas as ocorrências do padrão no histórico e calcula:
- entradas
- WIN
- LOSS
- taxa de acerto do ciclo
- lucro/prejuízo
- banca final
- drawdown máximo

ESTRATÉGIAS SALVAS
Cada estratégia fica persistida em:
user://estrategias_v2.json

Você pode:
- criar várias
- dar nome
- simular novamente com o histórico atualizado
- carregar no editor
- excluir

OBSERVAÇÃO
Resultado histórico não garante lucro futuro.
